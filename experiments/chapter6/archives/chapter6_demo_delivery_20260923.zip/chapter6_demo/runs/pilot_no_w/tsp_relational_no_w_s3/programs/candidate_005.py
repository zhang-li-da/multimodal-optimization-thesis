def priority(f):
    d = f['distance']
    rd = f['return_distance']
    p = f['progress']
    w = 0.1 + 0.9 * p
    return -d + w * rd