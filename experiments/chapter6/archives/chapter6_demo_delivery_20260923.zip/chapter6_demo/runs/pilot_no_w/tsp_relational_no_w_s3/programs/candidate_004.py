def priority(f):
    d = f['distance']
    rd = f['return_distance']
    val = -d + 0.4 * rd
    return val