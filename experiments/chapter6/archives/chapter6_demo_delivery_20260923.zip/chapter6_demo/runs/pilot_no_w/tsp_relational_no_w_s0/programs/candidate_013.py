def priority(f):
    d = f['distance']
    r = f['return_distance']
    p = f['progress']
    cd = f['cluster_density']
    penalty = (1.0 - p) * 0.3 * r
    score = -d - penalty + 0.2 * cd
    return score