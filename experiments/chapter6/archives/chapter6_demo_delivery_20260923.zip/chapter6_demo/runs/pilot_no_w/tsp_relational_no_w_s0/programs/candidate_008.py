def priority(f):
    d = f['distance']
    r = f['return_distance']
    reg = f['regret']
    score = -d + 0.2 * reg - 0.1 * r
    return score