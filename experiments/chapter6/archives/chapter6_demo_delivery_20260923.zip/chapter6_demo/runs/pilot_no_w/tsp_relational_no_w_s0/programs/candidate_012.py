def priority(f):
    d = f['distance']
    r = f['return_distance']
    p = f['progress']
    penalty = (1.0 - p) * 0.3 * r
    score = -d - penalty
    return score