def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    return -d + 0.5 * rd + 0.25 * r