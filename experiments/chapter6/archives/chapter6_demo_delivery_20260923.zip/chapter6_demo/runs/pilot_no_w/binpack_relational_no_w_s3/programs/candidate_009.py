def priority(f):
    return f['fill'] - 0.1 * f['position']