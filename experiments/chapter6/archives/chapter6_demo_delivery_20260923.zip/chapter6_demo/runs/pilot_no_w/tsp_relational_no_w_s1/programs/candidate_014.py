def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = -d + 0.25 * rd + 0.15 * r
    return p