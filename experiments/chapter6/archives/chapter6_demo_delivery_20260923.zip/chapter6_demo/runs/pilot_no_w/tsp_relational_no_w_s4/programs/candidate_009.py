def priority(f):
    d = f['distance']
    r = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    p = f['progress']
    score = -d + (1.0 - cd) * reg * (1.0 - p) + r * p
    return score