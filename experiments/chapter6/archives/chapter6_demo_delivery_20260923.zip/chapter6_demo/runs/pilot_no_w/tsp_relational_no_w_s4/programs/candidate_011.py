def priority(f):
    d = f['distance']
    r = f['return_distance']
    p = f['progress']
    cd = f['cluster_density']
    score = -d + cd * (1.0 - p) * (-d) + r * p
    return score