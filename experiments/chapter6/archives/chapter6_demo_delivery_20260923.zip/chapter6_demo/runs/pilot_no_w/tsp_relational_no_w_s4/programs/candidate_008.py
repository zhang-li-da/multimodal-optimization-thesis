def priority(f):
    d = f['distance']
    r = f['return_distance']
    p = f['progress']
    score = -d + r * p
    return score