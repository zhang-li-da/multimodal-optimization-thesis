def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + 0.5 * rd * (1.0 - p) + 0.3 * r