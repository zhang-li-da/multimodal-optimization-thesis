def priority(f):
    gap = f['gap']
    remaining = f['remaining']
    item = f['item']
    safe_rem = remaining if remaining > 1e-9 else 1e-9
    fill_ratio = item / safe_rem
    return -gap - 0.5 * fill_ratio