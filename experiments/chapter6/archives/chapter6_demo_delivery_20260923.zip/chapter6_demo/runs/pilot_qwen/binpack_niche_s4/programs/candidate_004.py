def priority(f):
    return f['mean_gap']