def priority(f):
    d = f['distance']
    cd = f['cluster_density']
    r = f['regret']
    w1 = 1.0 + cd * cd
    term1 = -d * w1
    term2 = 0.25 * r
    return term1 + term2