def priority(f):
    d = f['distance']
    cd = f['cluster_density']
    r = f['regret']
    return -(d ** 2) * (1.0 + cd) + 0.1 * r