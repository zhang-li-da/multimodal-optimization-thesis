def priority(f):
    d = f['distance']
    cd = f['cluster_density']
    r = f['regret']
    w = 1.0 + cd
    return -d * w + 0.2 * r