def priority(f):
    g = f['gap']
    fr = f['fraction_fitting']
    fl = f['fill']
    w_tight = 1.0 - fr
    w_bal = fr
    return -g * w_tight - fl * w_bal