def priority(f):
    gap = f['gap']
    ff = f['fraction_fitting']
    return (2.0 * ff - 1.0) * gap