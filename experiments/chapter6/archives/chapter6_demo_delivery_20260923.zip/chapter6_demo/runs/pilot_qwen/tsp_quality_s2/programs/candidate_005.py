def priority(f):
    return -f["distance"] + 0.1 * f["return_distance"] + 0.4 * f["regret"]