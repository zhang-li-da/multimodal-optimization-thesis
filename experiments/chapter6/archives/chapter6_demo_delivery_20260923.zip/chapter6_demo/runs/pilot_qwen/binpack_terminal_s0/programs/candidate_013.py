def priority(f):
    gap = f['gap']
    item = f['item']
    penalty = 1000.0 if gap < item else 0.0
    return -gap - penalty