def priority(f):
    return -f["gap"] - 0.1 * f["position"]