def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    w_reg = 0.25 * (1.0 - cd ** 2)
    w_rd = 0.2 + 0.2 * cd
    safe_r = max(0.0, reg)
    return -d + w_rd * (rd ** 2) + w_reg * sqrt(safe_r)