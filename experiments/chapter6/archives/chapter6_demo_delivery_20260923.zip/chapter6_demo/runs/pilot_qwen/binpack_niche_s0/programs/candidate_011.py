def priority(f):
    g = f["gap"]
    p = f["position"]
    return -(g ** 2) - 0.01 * p