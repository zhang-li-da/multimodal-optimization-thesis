def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    p = f['progress']
    cd = f['cluster_density']
    safe_cd = max(0.1, cd)
    regret_weight = 0.5 * (1.0 - p) / safe_cd
    closure_weight = 0.2 * p
    return -d + regret_weight * r + closure_weight * rd