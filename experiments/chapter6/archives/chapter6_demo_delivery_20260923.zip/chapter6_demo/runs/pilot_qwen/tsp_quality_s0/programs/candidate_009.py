def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    p = f['progress']
    return -d + (1.0 - p) ** 2 * 0.5 * r + p ** 2 * 0.6 * rd