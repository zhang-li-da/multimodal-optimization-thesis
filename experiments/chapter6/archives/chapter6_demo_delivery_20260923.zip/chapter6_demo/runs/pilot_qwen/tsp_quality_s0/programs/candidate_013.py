def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    p = f['progress']
    cd = f['cluster_density']
    safe_cd = max(0.001, cd)
    regret_weight = (1.0 - p) ** 2 * 0.4 / safe_cd
    return -d + regret_weight * r + 0.3 * rd