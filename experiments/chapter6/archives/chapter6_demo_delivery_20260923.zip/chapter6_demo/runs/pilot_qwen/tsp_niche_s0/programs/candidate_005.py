def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    return -d + 0.25 * rd + 0.15 * r