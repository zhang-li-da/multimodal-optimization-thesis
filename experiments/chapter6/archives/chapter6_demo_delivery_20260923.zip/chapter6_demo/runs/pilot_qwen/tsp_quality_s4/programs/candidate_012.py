def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    eps = 1e-9
    safe_d = d + eps
    safe_rd = rd + eps
    term1 = -d
    term2 = 0.2 * rd
    weight_r = 0.15 + 0.35 * p
    term3 = weight_r * r
    score = term1 + term2 + term3
    return score