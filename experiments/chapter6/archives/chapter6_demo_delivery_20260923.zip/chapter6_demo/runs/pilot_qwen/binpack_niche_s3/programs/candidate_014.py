def priority(f):
    ff = f['fraction_fitting']
    gap = f['gap']
    mean_gap = f['mean_gap']
    num = ff ** 2
    den = num + (1 - ff) ** 2 + 1e-9
    w = num / den
    diff = gap - mean_gap
    score = -((1 - w) * gap + w * diff * diff)
    return score