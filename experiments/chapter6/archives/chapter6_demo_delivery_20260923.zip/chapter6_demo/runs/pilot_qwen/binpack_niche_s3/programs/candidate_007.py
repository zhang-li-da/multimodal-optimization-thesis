def priority(f):
    ff = f['fraction_fitting']
    gap = f['gap']
    mean_gap = f['mean_gap']
    if ff < 0.3:
        return -gap
    else:
        diff = gap - mean_gap
        return -(diff * diff + 0.1 * gap)