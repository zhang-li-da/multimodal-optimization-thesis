def priority(f):
    ff = f['fraction_fitting']
    gap = f['gap']
    mean_gap = f['mean_gap']
    diff = gap - mean_gap
    return -((1.0 - ff) * gap + ff * diff * diff)