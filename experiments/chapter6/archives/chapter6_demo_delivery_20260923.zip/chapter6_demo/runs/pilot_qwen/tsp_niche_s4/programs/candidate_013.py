def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    r = f['regret']
    p = f['progress']
    w_cd = 0.4 * (1 - p)**2
    w_r = 0.1 + 0.3 * p
    w_rd = 0.1 + 0.4 * p
    return -d + w_cd * cd + w_r * r + w_rd * rd