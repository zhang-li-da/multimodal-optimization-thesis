def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    cd = f["cluster_density"]
    r = f["regret"]
    p = f["progress"]
    w_rd = 0.1 + 0.5 * p
    w_cd = 0.3 * (1 - p) ** 2
    w_r = 0.05 + 0.2 * p
    return -d + w_rd * rd + w_cd * cd + w_r * r