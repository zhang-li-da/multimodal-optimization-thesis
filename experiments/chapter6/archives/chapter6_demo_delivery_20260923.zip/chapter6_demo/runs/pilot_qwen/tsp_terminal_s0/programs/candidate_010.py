def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    r = f['regret']
    eps = 1e-9
    safe_cd = max(0.0, min(1.0, cd))
    term1 = -d
    term2 = (1.0 - safe_cd) * rd
    term3 = safe_cd * r
    return term1 + term2 + term3