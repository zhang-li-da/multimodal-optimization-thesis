def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    r = f['regret']
    safe_cd = max(0.0, min(1.0, cd))
    w_return = 1.0 - safe_cd
    w_regret = safe_cd
    return -d + 0.5 * w_return * rd + 0.3 * w_regret * r