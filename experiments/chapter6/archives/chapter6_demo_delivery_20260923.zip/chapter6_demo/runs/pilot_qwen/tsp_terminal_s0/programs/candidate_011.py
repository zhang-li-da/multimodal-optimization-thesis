def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    r = f['regret']
    nr = f['nearest_remaining']
    safe_cd = max(0.0, min(1.0, cd))
    return -d + (1.0 - safe_cd) * rd + safe_cd * r - 0.1 * nr