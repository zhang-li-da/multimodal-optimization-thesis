def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    safe_r = max(r, 0.0)
    sqrt_r = sqrt(safe_r)
    return -d + 0.4 * sqrt_r + 0.1 * rd