def priority(f):
    d = f['distance']
    rd = f['return_distance']
    return -d + 0.5 * rd