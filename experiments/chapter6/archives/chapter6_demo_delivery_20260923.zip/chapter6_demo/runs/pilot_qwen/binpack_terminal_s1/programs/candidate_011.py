def priority(f):
    gap = f['gap']
    position = f['position']
    return -(gap + 0.1 * position)