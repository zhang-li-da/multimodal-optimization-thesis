def priority(f):
    g = f['gap']
    m = f['mean_gap']
    return -(g - m) ** 2