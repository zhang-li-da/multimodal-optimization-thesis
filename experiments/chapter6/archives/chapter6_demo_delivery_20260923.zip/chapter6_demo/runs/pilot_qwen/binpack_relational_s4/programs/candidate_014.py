def priority(f):
    g = f['gap']
    p = f['position']
    ff = f['fraction_fitting']
    w = 1.0 / (1.0 + exp(-10.0 * (ff - 0.5)))
    return -g - w * p