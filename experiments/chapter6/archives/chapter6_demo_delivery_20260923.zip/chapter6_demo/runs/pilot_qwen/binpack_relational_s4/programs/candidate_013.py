def priority(f):
    g = f['gap']
    p = f['position']
    ff = f['fraction_fitting']
    w = exp(-5.0 * (1.0 - ff))
    return -g - w * p