def priority(f):
    g = f['gap']
    p = f['position']
    ff = f['fraction_fitting']
    w = (1.0 - ff) * 0.5
    return -g - w * p