def priority(f):
    g = f['gap']
    p = f['position']
    ff = f['fraction_fitting']
    scarcity = (1.0 - ff) ** 2
    return -g - scarcity * p