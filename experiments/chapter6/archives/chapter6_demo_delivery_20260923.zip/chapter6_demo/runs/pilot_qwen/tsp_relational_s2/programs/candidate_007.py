def priority(f):
    d = f["distance"]
    cd = f["cluster_density"]
    r = f["regret"]
    base = -d * (1.0 + cd)
    bonus = 0.2 * r
    return base + bonus