def priority(f):
    p = f["progress"]
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    w_r = 0.2 + 0.1 * (1.0 - p)
    w_rd = 0.5 * p + 0.1 * (1.0 - p)
    return -d + w_r * r + w_rd * rd