def priority(f):
    p = f["progress"]
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    w_r = (1.0 - p) * 0.3
    w_rd = p * 0.4
    return -d + w_r * r + w_rd * rd