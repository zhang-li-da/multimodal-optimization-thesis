def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    s = f['spread']
    p = f['progress']
    w_rd = 0.1 + 0.3 * p
    w_r = 0.2 * (1 - p)
    w_s = 0.1 * (1 - p)
    return -d + w_rd * rd + w_r * r + w_s * s