def priority(f):
    gap = f['gap']
    mean_gap = f['mean_gap']
    return -(abs(gap - mean_gap) + 0.1 * gap)