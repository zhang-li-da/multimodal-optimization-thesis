def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    w = 0.1 + 0.4 * (p ** 2)
    return -d + w * rd + 0.15 * r