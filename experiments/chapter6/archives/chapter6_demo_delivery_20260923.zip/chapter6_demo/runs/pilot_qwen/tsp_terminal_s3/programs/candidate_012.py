def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    p = f["progress"]
    cd = f["cluster_density"]
    w = 0.2 + 0.3 * p
    return -d + w * rd + 0.1 * cd