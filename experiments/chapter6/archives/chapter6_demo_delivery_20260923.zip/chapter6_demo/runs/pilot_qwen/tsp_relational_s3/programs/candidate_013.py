def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    return -d + 0.5 * r - 0.3 * rd