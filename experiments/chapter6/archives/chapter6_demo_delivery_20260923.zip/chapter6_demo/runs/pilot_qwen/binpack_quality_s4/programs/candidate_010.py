def priority(f):
    gap = f["gap"]
    pos = f["position"]
    w = 1.0 + 0.5 * pos
    return -gap * w