def priority(f):
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom = mean_gap + 1e-9
    score = -gap - 0.1 * position - 0.05 * (std_gap / denom) + 0.02 * fill - 0.01 * fraction_fitting
    if min_gap > 0:
        score = score + 0.01 * (1.0 / (min_gap + 1e-9))
    return score