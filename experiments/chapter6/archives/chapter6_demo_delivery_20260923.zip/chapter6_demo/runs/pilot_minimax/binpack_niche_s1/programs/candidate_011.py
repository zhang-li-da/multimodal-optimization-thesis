def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    g = gap + 0.05
    inv_gap = 1.0 / g
    one_minus_ff = 1.0 - fraction_fitting
    gate = one_minus_ff * one_minus_ff * one_minus_ff
    score = -gap + inv_gap * gate * 0.5
    high_fill = 0.0
    if fill > 0.85:
        high_fill = fill * fill * fill
    item_boost = 0.5 + 0.5 * item
    kicker = high_fill * item_boost * (1.0 - gate) * 0.3
    score = score + kicker
    near_min = max(0.0, 0.05 - (gap - min_gap))
    score = score + 0.2 * near_min - 0.08 * position
    return score