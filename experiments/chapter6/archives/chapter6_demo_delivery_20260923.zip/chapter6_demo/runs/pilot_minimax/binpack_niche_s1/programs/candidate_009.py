def priority(f):
    eps = 1e-9
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    if item > remaining + eps:
        return -1.0
    tight = -gap
    inv_gap = 0.4 / (gap + 0.05)
    gate = 1.0 - fraction_fitting
    if gate < 0.0:
        gate = 0.0
    if gate > 1.0:
        gate = 1.0
    bonus = inv_gap * ( ( ( ( ( 3.0 * gate ) * 2.0 - 3.0 * gate * gate * 2.0 ) ) ) )
    fill_gate = 0.0
    if fill > 0.85:
        fill_gate = 1.0
    fill_bonus = 0.5 * ( (1.0 - remaining) ** 3 ) * fill_gate
    z = (gap - mean_gap) / (std_gap + eps)
    central = 0.08 * z * fraction_fitting
    pos_pen = -0.08 * position
    return tight + bonus + fill_bonus + central + pos_pen