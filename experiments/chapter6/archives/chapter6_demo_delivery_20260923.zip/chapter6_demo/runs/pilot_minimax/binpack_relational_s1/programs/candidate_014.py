def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-9
    base = -gap
    denom_gap = gap + min_gap + 1e-3
    diff = gap - min_gap
    ratio = diff / (denom_gap + eps)
    ratio_clamped = ratio if ratio > -1.0 else -1.0
    ratio_clamped = ratio_clamped if ratio_clamped < 1.0 else 1.0
    tanh_approx = ratio_clamped * (27.0 + ratio_clamped * ratio_clamped) / (27.0 + 9.0 * ratio_clamped * ratio_clamped)
    nonlinear = 0.3 * tanh_approx
    safe_ff = fraction_fitting if fraction_fitting > 0.0 else 0.0
    safe_ff = safe_ff if safe_ff < 1.0 else 1.0
    ff_term = 0.03 * (safe_ff / (safe_ff + 1.0))
    pos_term = -5e-4 * position
    score = base + nonlinear + ff_term + pos_term
    return score