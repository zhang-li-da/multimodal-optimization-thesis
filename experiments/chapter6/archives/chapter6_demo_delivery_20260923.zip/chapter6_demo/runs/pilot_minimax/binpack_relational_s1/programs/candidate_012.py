def priority(f):
    gap = f["gap"]
    min_gap = f["min_gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    frac = f["fraction_fitting"]
    pos = f["position"]
    fill = f["fill"]
    remaining = f["remaining"]
    ratio = (gap - min_gap) / (gap + min_gap + 1e-3)
    z = (gap - mean_gap) / (std_gap + 1e-3)
    score = -(gap) + 0.35 * ratio + 0.05 * frac - 0.0005 * pos - 0.1 * z - 0.05 * (1.0 - fill)
    return score
