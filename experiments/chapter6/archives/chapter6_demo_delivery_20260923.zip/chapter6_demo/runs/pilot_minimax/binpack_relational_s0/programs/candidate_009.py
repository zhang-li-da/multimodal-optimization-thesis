def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom_gap = mean_gap + 1e-9
    close_to_mean = 1.0 - min(1.0, abs(gap - mean_gap) / denom_gap)
    fill_cu = fill * fill * fill
    score = -gap - 0.35 * gap * gap
    score = score + 0.10 * close_to_mean
    score = score + 0.03 * fill_cu
    score = score - 0.02 * (gap - min_gap)
    score = score + 0.05 * (fraction_fitting - 0.5)
    score = score - 0.005 * std_gap
    score = score + 0.02 * (1.0 - position)
    score = score - 0.01 * item
    score = score + 0.01 * (remaining - gap)
    return score
