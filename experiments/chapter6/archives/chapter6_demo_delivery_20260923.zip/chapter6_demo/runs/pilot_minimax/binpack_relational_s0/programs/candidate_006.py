def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    score = -gap - 0.5 * gap * gap
    score = score + 0.2 * (1.0 - abs(gap - mean_gap) / (mean_gap + 1e-9))
    score = score + 0.05 * fill
    score = score - 0.01 * item
    return score
