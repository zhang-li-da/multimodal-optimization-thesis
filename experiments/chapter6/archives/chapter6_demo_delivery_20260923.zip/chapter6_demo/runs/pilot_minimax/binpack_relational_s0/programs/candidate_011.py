def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fill = f["fill"]
    item = f["item"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom_std = std_gap * std_gap + 1e-6
    diff = gap - mean_gap
    var_term = 1.0 - (diff * diff) / denom_std
    bal = var_term / (1.0 + abs(gap))
    min_term = (gap - min_gap) / (abs(mean_gap) + 1e-9)
    pos_term = -position
    score = -gap + 0.20 * bal + 0.05 * fill * fill + 0.03 * (1.0 - fraction_fitting) - 0.01 * item + 0.01 * min_term + 0.005 * pos_term
    return score