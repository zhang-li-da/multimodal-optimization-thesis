def priority(f):
    item = f["item"]
    gap = f["gap"]
    remaining = f["remaining"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    min_gap = f["min_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom = gap * gap + 1e-6
    diff = gap - mean_gap
    gauss = (diff * diff) / denom
    gauss_term = 0.10 * (1.0 - gauss) * (1.0 + item) if gauss < 1.0 else 0.0
    std_bonus = 0.02 * std_gap
    fr_bonus = 0.03 * (1.0 - fraction_fitting)
    rem_pen = 0.05 * remaining
    tight = -gap + 0.15 * min_gap
    score = tight + gauss_term + std_bonus + fr_bonus - rem_pen
    if position > 0.999:
        score = score + 0.01
    if gap < 0.05:
        score = score - 0.02
    return score
