def priority(f):
    eps = 1e-9
    g = f["gap"]
    mg = f["mean_gap"]
    diff = g - mg
    denom = mg * mg + 1e-6
    balance = (1 - diff * diff / denom) / (mg + eps)
    fill_term = f["fill"] * f["fill"]
    item_pen = f["item"]
    pos_term = 1 - f["position"]
    score = -g + 0.15 * balance + 0.04 * fill_term - 0.01 * item_pen + 0.01 * pos_term
    return score