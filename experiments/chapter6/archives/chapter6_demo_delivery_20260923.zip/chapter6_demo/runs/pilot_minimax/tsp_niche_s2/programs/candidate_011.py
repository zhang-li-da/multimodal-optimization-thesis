def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    rg_sat = (rg * 2.0) / (1.0 + abs(rg * 2.0))
    cd_eff = cd / (1.0 + cd + 1e-9)
    excess = max(0.0, sp - nr) * cd_eff
    look = max(0.0, nr - mr) / (1.0 + mr * 0.5 + 1e-9)
    score = -d + 0.25 * rd - 0.03 * pr + 0.30 * rg_sat - 0.10 * excess - 0.08 * look
    return score
