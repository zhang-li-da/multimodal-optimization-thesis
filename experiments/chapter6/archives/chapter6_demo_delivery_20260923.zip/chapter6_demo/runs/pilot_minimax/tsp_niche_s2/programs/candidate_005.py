def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    regret = f["regret"]
    progress = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    base = -d + 0.20 * rd + 0.20 * regret - 0.05 * progress
    denom = max(mr, 1e-9)
    soft = regret / (1.0 + denom)
    near = -0.05 * nr
    div = -0.05 * sp / (1.0 + cd)
    return base + soft + near + div
