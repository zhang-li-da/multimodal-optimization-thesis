def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    progress = f['progress']
    eps = 1e-9
    cd_c = cd
    if cd_c < 0.0:
        cd_c = 0.0
    elif cd_c > 1.0:
        cd_c = 1.0
    m = 1.0 + 0.35 * cd_c
    if m < 0.3:
        m = 0.3
    elif m > 1.6:
        m = 1.6
    base = -d * m
    penalty = 0.10 * rd * progress
    score = base - penalty
    denom = 1.0 + abs(base) + eps
    return score / denom
