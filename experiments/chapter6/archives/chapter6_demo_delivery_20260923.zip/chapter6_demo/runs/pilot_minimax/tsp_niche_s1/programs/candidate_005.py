def priority(f):
    d = f['distance']
    regret = f['regret']
    cd = f['cluster_density']
    eps = 1e-9
    cd_c = cd
    if cd_c < 0.0:
        cd_c = 0.0
    elif cd_c > 1.0:
        cd_c = 1.0
    m = 1.0 + 0.3 * cd_c
    if m < 0.4:
        m = 0.4
    elif m > 1.5:
        m = 1.5
    base = -d * m
    w = 0.5 + 0.5 * cd_c
    if w < 0.0:
        w = 0.0
    elif w > 1.0:
        w = 1.0
    regret_term = 0.25 * regret * w
    score = base + regret_term
    denom = 1.0 + abs(base) + abs(regret_term) + eps
    return score / denom