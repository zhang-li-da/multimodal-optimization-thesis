def priority(f):
    d=f['distance']; rt=f['return_distance']; nr=f['nearest_remaining']; mr=f['mean_remaining']; rg=f['regret']; pr=f['progress']; cd=f['cluster_density']; sp=f['spread']
    base=-d*(1+0.3*cd)
    tie=0.15*rg*(0.5+0.5*cd)
    anti_strand=-0.10*nr
    bias_ret=0.05*rt
    num=base+tie+anti_strand+bias_ret
    den=1+abs(base)+0.15*rg+0.10*nr+0.05*rt+1e-9
    s=num/den
    return s