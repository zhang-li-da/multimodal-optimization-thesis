def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    a = 0.5 * cd
    m = 1.0 + a
    if m < 0.25:
        m = 0.25
    elif m > 2.0:
        m = 2.0
    return -d * m + 0.15 * rd
