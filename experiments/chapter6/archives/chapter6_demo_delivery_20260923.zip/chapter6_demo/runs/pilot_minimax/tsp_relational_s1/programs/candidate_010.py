def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    base = -d
    if rd > d:
        base = base + 0.25 * (rd - d)
    else:
        base = base - 0.1 * d
    base = base + (0.15 * cd) / (1.0 + 2.0 * d)
    if nr > 0:
        base = base - 0.05 * (rg / (nr + 1e-9))
    else:
        base = base - 0.05 * rg
    if mr > 0:
        base = base + 0.02 * (nr / (mr + 1e-9))
    excess = (sp / (mr + 1e-9)) - 1.0
    if excess > 0:
        base = base - 0.03 * excess
    base = base + 0.05 * pr
    return base
