def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    score = -d * (1 + 0.6 * pr) + 0.20 * max(0, rd - d)
    if nr > 0:
        score = score - 0.08 * (rg / (nr + 1e-9))
    else:
        score = score - 0.08 * rg
    score = score + 0.05 * cd
    if mr > 0:
        score = score - 0.01 * (sp / (mr + 1e-9))
    return score
