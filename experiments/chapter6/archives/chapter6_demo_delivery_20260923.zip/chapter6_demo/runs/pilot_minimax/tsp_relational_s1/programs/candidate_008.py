def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    score = -d
    score = score + 0.25 * max(0, rd - d)
    score = score + 0.12 * log1p(cd)
    if mr > 1e-9:
        score = score - 0.08 * rg / (d + 0.1)
    else:
        score = score - 0.08 * rg
    score = score + 0.04 * pr
    if mr > 1e-9:
        score = score - 0.02 * sp / (mr + 1e-9)
        score = score + 0.03 * nr / (mr + 1e-9)
    return score