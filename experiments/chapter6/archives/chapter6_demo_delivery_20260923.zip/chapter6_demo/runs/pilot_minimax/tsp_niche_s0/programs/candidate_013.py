def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    pr_eff = pr - 0.5
    pr_eff = pr_eff if pr_eff > 0.0 else 0.0
    rd_w = 0.25 + 0.10 * pr_eff
    rg_w = 0.30
    nr_w = 0.02
    mr_w = 0.01
    cd_w = 0.03
    sp_w = 0.01
    base = -d + rd_w * rd + rg_w * rg
    adj = nr_w * (mr - nr) + mr_w * (mr - d) + cd_w * (cd - 0.5) + sp_w * (sp - mr)
    s = base + adj
    return s
