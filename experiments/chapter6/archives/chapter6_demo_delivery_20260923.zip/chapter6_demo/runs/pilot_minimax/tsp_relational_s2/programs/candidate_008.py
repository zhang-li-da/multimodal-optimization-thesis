def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    cd = f['cluster_density']
    sp = f['spread']
    base = -d + 0.25 * rd
    cluster = 0.10 * cd
    compact = -0.05 * sp
    tiebreak = 0.05 * rg - 0.03 * (mr - nr) / (1.0 + abs(mr - nr))
    return base + cluster + compact + tiebreak