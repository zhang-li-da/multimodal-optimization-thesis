def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    exact = 0.60 * exp(-80.0 * gap * gap)
    balance = 0.30 / (1.0 + 20.0 * abs(gap - mean_gap))
    p = -gap + exact + balance + 0.06 * fraction_fitting - 0.02 * position
    return p