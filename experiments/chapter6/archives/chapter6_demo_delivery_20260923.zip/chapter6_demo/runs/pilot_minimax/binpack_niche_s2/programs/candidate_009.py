def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    diff = gap - mean_gap
    abs_diff = abs(diff)
    if abs_diff < 1e-9:
        balance = 200.0
    else:
        balance = 20.0 / (100.0 * abs_diff + 1.0)
    sq_gap = gap * gap
    exact_bonus = 0.30 * exp(-80.0 * sq_gap)
    fraction_bonus = 0.08 * fraction_fitting
    return -gap + balance + exact_bonus + fraction_bonus