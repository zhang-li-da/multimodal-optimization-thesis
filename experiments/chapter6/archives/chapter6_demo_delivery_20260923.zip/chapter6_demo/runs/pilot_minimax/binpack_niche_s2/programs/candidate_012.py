def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    safe_mean = mean_gap if abs(mean_gap) > 1e-9 else 1e-9
    safe_std = std_gap if abs(std_gap) > 1e-9 else 1e-9
    diff = gap - safe_mean
    balance_bonus = exp(-30.0 * diff * diff)
    tight_penalty = -gap
    fit_bonus = 0.06 * fraction_fitting
    item_term = 0.08 * (1.0 - item) * gap
    min_closeness = -abs(gap - std_gap)
    loose_balance = -abs(safe_mean - safe_std) * 0.02
    priority = tight_penalty + 0.35 * balance_bonus + fit_bonus + item_term + 0.04 * min_closeness + loose_balance
    if gap < 0.12:
        priority = priority + 0.05
    elif gap > 0.55:
        priority = priority - 0.03
    if remaining > 0.95:
        priority = priority - 0.02
    if fraction_fitting > 0.65:
        priority = priority + 0.03
    if item < 0.18 and gap < 0.22:
        priority = priority + 0.04
    priority = priority + 0.01 * position
    return priority