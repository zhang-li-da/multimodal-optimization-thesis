def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    exact_bonus = 0.25 if gap < 1e-9 else 0.0
    p = -gap + 0.15 * (1.0 / (1.0 + 50.0 * abs(gap - mean_gap))) + exact_bonus - 0.05 * position + 0.10 * fraction_fitting
    return p