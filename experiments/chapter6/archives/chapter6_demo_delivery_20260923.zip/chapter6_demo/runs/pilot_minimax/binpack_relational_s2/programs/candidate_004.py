def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    fr = fraction_fitting / (1.0 + fraction_fitting)
    diff = gap - mean_gap
    penalty = 0.25 * fr * diff * diff / (std_gap + 1e-9)
    fit_bonus = 0.1 * fr * fill
    pos_bonus = 0.05 * fr * position
    return -gap - penalty + fit_bonus + pos_bonus
