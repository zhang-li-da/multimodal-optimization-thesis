def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom = (mean_gap + 1e-9)
    dev = (gap - min_gap) / denom
    tight_term = (mean_gap - gap) * (fraction_fitting - 0.5)
    scarcity_term = std_gap * (1.0 - fraction_fitting)
    scarcity_safe = scarcity_term / denom
    base_score = -gap + 0.20 * tight_term - 0.30 * scarcity_safe
    fill_penalty = -0.05 * fill * fraction_fitting
    pos_bias = -0.001 * position
    norm_dev = dev * (1.0 - fraction_fitting)
    clip_dev = -abs(norm_dev) / (1.0 + abs(norm_dev))
    extra = -0.10 * clip_dev
    score = base_score + fill_penalty + pos_bias + extra
    return score