def priority(f):
    return f["cosine"] + 0.5 * f["knn_fraction"] + 0.05 * log(f["prior"] + 1e-9)