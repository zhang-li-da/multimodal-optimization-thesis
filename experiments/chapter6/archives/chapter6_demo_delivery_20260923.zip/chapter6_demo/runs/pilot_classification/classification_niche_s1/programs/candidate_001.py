def priority(f):
    return f["knn_fraction"]
