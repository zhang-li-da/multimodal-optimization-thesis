def priority(f):
    s = 2.0 * f['cosine']
    s = s - 1.0 * f['robust_distance']
    s = s + 1.5 * f['knn_fraction']
    s = s + 0.01 * log(f['prior'] + 1e-9)
    return s