def priority(f):
    return -f["diagonal_nll"] + 0.05 * log(f["prior"] + 1e-9)
