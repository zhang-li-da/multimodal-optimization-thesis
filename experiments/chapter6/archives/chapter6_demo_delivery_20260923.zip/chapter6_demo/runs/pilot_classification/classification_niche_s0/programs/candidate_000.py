def priority(f):
    return -f["centroid"]
