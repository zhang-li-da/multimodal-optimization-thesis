def priority(f):
    c = f["cosine"]
    k = f["knn_fraction"]
    return c + k