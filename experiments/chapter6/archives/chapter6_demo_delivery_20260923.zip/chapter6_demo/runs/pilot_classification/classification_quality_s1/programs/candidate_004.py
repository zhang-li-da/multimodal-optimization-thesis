def priority(f):
    rd = f["robust_distance"]
    kf = f["knn_fraction"]
    score = -0.5 * rd + 0.5 * kf
    return score