def priority(f):
    knn = f["knn_fraction"]
    nll = f["diagonal_nll"]
    prior = f["prior"]
    score = knn - 0.2 * nll + 0.05 * log(prior + 1e-9)
    return score