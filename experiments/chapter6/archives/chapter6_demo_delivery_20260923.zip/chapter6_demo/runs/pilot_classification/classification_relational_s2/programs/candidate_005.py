def priority(f):
    c = f["cosine"]
    d = f["diagonal_nll"]
    p = f["prior"]
    s = 1.2 * c - 0.4 * d + 0.08 * log(p + 1e-9)
    return s