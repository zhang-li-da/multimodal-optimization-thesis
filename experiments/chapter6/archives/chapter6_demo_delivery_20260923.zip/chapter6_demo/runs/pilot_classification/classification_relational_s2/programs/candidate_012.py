def priority(f):
    return f['cosine'] + 1.5 * f['knn_fraction']