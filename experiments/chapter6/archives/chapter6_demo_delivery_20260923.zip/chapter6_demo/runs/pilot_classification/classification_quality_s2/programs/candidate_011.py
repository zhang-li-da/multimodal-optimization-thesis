def priority(f):
    c = f["cosine"]
    k = f["knn_fraction"]
    r = f["robust_distance"]
    p = f["prior"]
    s1 = 2.0 * c
    s2 = 2.5 * k
    s3 = 0.5 * r
    lp = log(p + 1e-9)
    s4 = 0.05 * lp
    score = s1 + s2 - s3 + s4
    return score