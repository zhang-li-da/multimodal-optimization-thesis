def priority(f):
    return -f['centroid'] + 0.1 * f['prior']