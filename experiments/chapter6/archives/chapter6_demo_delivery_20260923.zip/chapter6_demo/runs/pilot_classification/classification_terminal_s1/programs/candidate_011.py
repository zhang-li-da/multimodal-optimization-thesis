def priority(f):
    return -f['robust_distance'] + 0.1 * f['prior']