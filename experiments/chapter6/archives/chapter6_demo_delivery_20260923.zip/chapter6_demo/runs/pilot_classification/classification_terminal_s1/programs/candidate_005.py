def priority(f):
    knn = f['knn_fraction']
    nll = f['diagonal_nll']
    prior = f['prior']
    safe_prior = prior + 1e-9
    log_prior = log(safe_prior)
    score = knn - 0.2 * nll + 0.01 * log_prior
    return score