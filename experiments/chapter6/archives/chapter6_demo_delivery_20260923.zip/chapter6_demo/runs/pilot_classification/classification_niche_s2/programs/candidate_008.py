def priority(f):
    d = f["diagonal_nll"]
    c = f["cosine"]
    return -d + 0.2 * c