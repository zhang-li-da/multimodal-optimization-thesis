def priority(f):
    p = f['prior']
    c = f['centroid']
    score = -c + 0.1 * log(p + 1e-9)
    return score