def priority(f):
    rd = f["robust_distance"]
    kf = f["knn_fraction"]
    cs = f["cosine"]
    score = -0.6 * rd + 0.3 * kf + 0.4 * cs
    return score