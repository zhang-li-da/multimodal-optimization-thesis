def priority(f):
    knn = f["knn_fraction"]
    cos = f["cosine"]
    return knn + 0.5 * cos