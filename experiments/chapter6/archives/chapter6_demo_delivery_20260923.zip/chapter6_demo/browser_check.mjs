// Headless Edge / CDP check. Browser profile and screenshot stay in this demo.
import {spawn} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(root,'results');
await mkdir(out,{recursive:true});
const browser=spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',[
  '--headless=new','--disable-gpu','--no-first-run','--no-default-browser-check',
  '--remote-debugging-port=9243','--remote-allow-origins=http://localhost',
  '--user-data-dir='+path.join(root,'.browser-profile'),'about:blank'
],{stdio:'ignore',windowsHide:true});
let ws;
try{
  let pages;
  for(let i=0;i<40;i++){
    try{pages=await (await fetch('http://127.0.0.1:9243/json')).json();if(pages.length)break;}catch{}
    await new Promise(r=>setTimeout(r,200));
  }
  if(!pages?.length)throw new Error('Headless Edge did not expose CDP');
  ws=new WebSocket(pages[0].webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
  let next=0;const pending=new Map(),errors=[];
  ws.addEventListener('message',event=>{let data=JSON.parse(event.data);if(data.id){const p=pending.get(data.id);if(p){pending.delete(data.id);data.error?p.reject(data.error):p.resolve(data.result)}}else if(data.method==='Runtime.exceptionThrown')errors.push(data.params.exceptionDetails.text)});
  const send=(method,params={})=>new Promise((resolve,reject)=>{const id=++next;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}))});
  await send('Runtime.enable');await send('Page.enable');
  await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
  const navigation=await send('Page.navigate',{url:pathToFileURL(path.join(root,'dashboard.html')).href});
  for(let i=0;i<40;i++){
    const ready=await send('Runtime.evaluate',{expression:"!!document.getElementById('code') && document.readyState==='complete'",returnByValue:true});
    if(ready.result.value)break;
    await new Promise(r=>setTimeout(r,200));
  }
  let check=await send('Runtime.evaluate',{expression:"JSON.stringify({title:document.title, models:document.querySelectorAll('#model option').length,runs:document.querySelectorAll('#run option').length,rows:document.querySelectorAll('#candidates tr').length,code:document.getElementById('code').textContent,loss:document.getElementById('k-loss').textContent,overflow:document.documentElement.scrollWidth>innerWidth})",returnByValue:true});
  if(check.exceptionDetails){const doc=await send('Runtime.evaluate',{expression:"JSON.stringify({url:location.href,title:document.title,body:document.body?.innerText?.slice(0,1600)})",returnByValue:true});console.log(JSON.stringify({navigation,doc,exception:check.exceptionDetails,errors}));throw new Error('Runtime evaluation failed');}
  const initial=JSON.parse(check.result.value);
  const dataCheck=await send('Runtime.evaluate',{expression:"JSON.stringify({total_runs:DATA.runs.length,task_options:[...document.querySelectorAll('#task option')].map(o=>o.value)})",returnByValue:true});
  Object.assign(initial,JSON.parse(dataCheck.result.value));
  if(initial.rows<3||!initial.code.includes('def priority'))throw new Error('Dashboard initial rendering failed');
  if(new Set(initial.task_options).size!==initial.task_options.length)throw new Error('Duplicate task choices');
  await send('Runtime.evaluate',{expression:"document.getElementById('task').value='binpack';document.getElementById('task').dispatchEvent(new Event('change'));document.querySelectorAll('#candidates tr')[3]?.click();document.getElementById('instance').value='1';document.getElementById('instance').dispatchEvent(new Event('change'));"});
  check=await send('Runtime.evaluate',{expression:"JSON.stringify({task:document.getElementById('task').value,selected:document.getElementById('candidate-title').textContent,note:document.getElementById('solution-note').textContent,rows:document.querySelectorAll('#candidates tr').length})",returnByValue:true});
  const interaction=JSON.parse(check.result.value);
  const classCheck=await send('Runtime.evaluate',{expression:"(()=>{let models=[...document.querySelectorAll('#model option')];let q=models.find(o=>o.value.startsWith('qwen'));if(!q)return null;document.getElementById('model').value=q.value;document.getElementById('model').dispatchEvent(new Event('change'));document.getElementById('task').value='classification';document.getElementById('task').dispatchEvent(new Event('change'));return JSON.stringify({task:document.getElementById('task').value,note:document.getElementById('solution-note').textContent,code:document.getElementById('code').textContent});})()",returnByValue:true});
  const classification=classCheck.result.value?JSON.parse(classCheck.result.value):null;
  if(!classification||classification.task!=='classification'||!classification.note.includes('iris')||!classification.code.includes('def priority'))throw new Error('Classification rendering failed');
  const classShot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true});
  await writeFile(path.join(out,'classification_dashboard.png'),Buffer.from(classShot.data,'base64'));
  const fallbackCheck=await send('Runtime.evaluate',{expression:"(()=>{let model=document.getElementById('model'),m=[...model.options].find(o=>o.value==='MiniMax-M3');if(!m)return null;model.value=m.value;model.dispatchEvent(new Event('change'));return JSON.stringify({model:model.value,task:document.getElementById('task').value,rows:document.querySelectorAll('#candidates tr').length});})()",returnByValue:true});
  const fallback=fallbackCheck.result.value?JSON.parse(fallbackCheck.result.value):null;
  if(!fallback||fallback.task==='classification'||fallback.rows<3)throw new Error('Unavailable model/task fallback failed');
  await send('Runtime.evaluate',{expression:"let model=document.getElementById('model');model.value=[...model.options].find(o=>o.value.startsWith('qwen')).value;model.dispatchEvent(new Event('change'));"});
  await send('Runtime.evaluate',{expression:"document.getElementById('task').value='tsp';document.getElementById('task').dispatchEvent(new Event('change'));"});
  const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true});
  await writeFile(path.join(out,'dashboard.png'),Buffer.from(shot.data,'base64'));
  const report={initial,interaction,classification,fallback,js_errors:errors,pass:errors.length===0&&!initial.overflow};
  await writeFile(path.join(out,'browser_check.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report));
  await send('Browser.close');
  if(!report.pass)process.exitCode=1;
}finally{
  if(ws)ws.close();
  browser.kill();
}
