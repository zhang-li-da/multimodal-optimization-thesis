"""Render local research notes as standalone HTML; no remote assets needed."""
from pathlib import Path
import os
import re
import subprocess
from urllib.parse import quote, unquote

DEMO = Path(__file__).resolve().parents[1]
WORKSPACE = DEMO.parent
REPORTS = [
    DEMO / "DELIVERY.md",
    DEMO / "README.md",
    DEMO / "THESIS_LINK.md",
    DEMO / "results/measured_report.md",
    WORKSPACE / "review_results/chapter6_feasibility_20260923/review_report.md",
    WORKSPACE / "review_results/chapter6_feasibility_20260923/revision_suggestions.md",
]
STYLE = """<style>
body {max-width:1100px; padding:36px 28px; font-family:'Microsoft YaHei','Segoe UI',sans-serif;
      font-size:16px; line-height:1.8; color:#20332f; background:#fafbf8;}
h1,h2,h3 {color:#165b53; line-height:1.4;}
h1 {font-size:30px;} h2 {margin-top:2em; font-size:23px;}
a {color:#176c68;} table {font-size:14px; display:block; overflow-x:auto;}
th,td {padding:9px 12px; border-bottom:1px solid #d9e2d9;}
thead {background:#e9f0e8;} pre {background:#edf1ea; padding:16px; white-space:pre-wrap;}
code {font-family:Consolas,monospace; font-size:.88em;}
blockquote {border-left:4px solid #78a38c; padding-left:18px; color:#3b5b50;}
@media print {body {max-width:none; padding:0; background:white;} a {color:inherit;}}
</style>"""


def main():
    available = [p for p in REPORTS if p.exists()]
    rendered = {p.resolve() for p in available}
    style = DEMO / "artifacts/report_style.html"
    style.write_text(STYLE, encoding="utf-8")
    for source in available:
        text = source.read_text(encoding="utf-8")
        title = text.splitlines()[0].lstrip("# ")

        def rewrite_link(match):
            target = match.group(1)
            if re.match(r"^(https?://|mailto:|#)", target):
                return match.group(0)
            target = unquote(target)
            if re.match(r"^[A-Za-z]:/", target):
                path = Path(re.sub(r":\d+$", "", target))
            else:
                path = source.parent / target
            if path.resolve() in rendered:
                path = path.with_suffix(".html")
            relative = os.path.relpath(path, source.parent).replace(os.sep, "/")
            return "](" + quote(relative, safe="/#:") + ")"

        html_input = re.sub(r"\]\(([^)]+)\)", rewrite_link, text)
        subprocess.run(
            ["pandoc", "--from=markdown", "--standalone", "--mathml",
             "--metadata", "lang=zh-CN", "--metadata", "pagetitle=" + title,
             "--include-in-header", str(style), "--output", str(source.with_suffix(".html"))],
            input=html_input, encoding="utf-8", check=True,
        )
        print(source.with_suffix(".html").relative_to(WORKSPACE))


if __name__ == "__main__":
    main()
