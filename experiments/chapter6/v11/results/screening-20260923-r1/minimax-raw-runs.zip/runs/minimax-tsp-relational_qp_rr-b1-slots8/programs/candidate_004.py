def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    rgrt = f["regret"]
    cd = f["cluster_density"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    sp = f["spread"]
    pg = f["progress"]
    denom = 1e-9
    nr_inv = 1.0 / (nr + denom)
    mr_inv = 1.0 / (mr + denom)
    base = -d + 0.12 * rd + 0.28 * rgrt - 0.10 * cd
    cluster_term = 0.05 * (nr_inv - mr_inv)
    spread_term = -0.04 * sp
    progress_term = 0.03 * pg
    return base + cluster_term + spread_term + progress_term