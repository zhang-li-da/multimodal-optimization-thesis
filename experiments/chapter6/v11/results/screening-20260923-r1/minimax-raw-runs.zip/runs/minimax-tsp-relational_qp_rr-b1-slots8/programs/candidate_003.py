def priority(f):
    return -f["distance"] + 0.20 * f["return_distance"] + 0.20 * f["regret"]