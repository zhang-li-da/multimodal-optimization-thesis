def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr + 1e-9
    safe_sp = sp + 1e-9
    return -d - 0.04 * r + 0.05 * nr - 0.03 * mr + 0.18 * rg + 0.05 * pr + 0.20 * cd - 0.06 * safe_sp / (safe_mr * 5.0)
