def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    rgrt = f["regret"]
    sp = f["spread"]
    pg = f["progress"]
    denom = 1e-9
    safe_pg = pg / (pg + denom)
    base = -d + 0.10 * rd + 0.18 * rgrt - 0.05 * sp
    progress_term = 0.06 * safe_pg
    return base + progress_term