def priority(f):
    g = f['gap']
    p = f['position']
    r = f['remaining']
    mn = f['min_gap']
    return -g + 0.05 * (mn - g) - 0.02 * p + 0.03 * (1.0 - r)
