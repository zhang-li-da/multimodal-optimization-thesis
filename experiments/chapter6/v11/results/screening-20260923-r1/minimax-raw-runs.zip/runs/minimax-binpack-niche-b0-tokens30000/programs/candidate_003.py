def priority(f):
    g = f['gap']
    p = f['position']
    r = f['remaining']
    fl = f['fraction_fitting']
    mn = f['min_gap']
    st = f['std_gap']
    return -g - 0.1 * p + 0.05 * (1.0 - r) + 0.2 * (mn - g) - 0.1 * st - 0.05 * fl
