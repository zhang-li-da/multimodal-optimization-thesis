def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    inv_d = 1.0 / (d + 1e-9)
    inv_n = 1.0 / (n + 1e-9)
    inv_m = 1.0 / (m + 1e-9)
    base = -d - 0.10 * r - 0.05 * g + 0.20 * p * (inv_d - inv_n) + 0.05 * c * inv_d
    penalty = 0.10 * s * inv_m - 0.02 * p * r * inv_d
    return base - penalty
