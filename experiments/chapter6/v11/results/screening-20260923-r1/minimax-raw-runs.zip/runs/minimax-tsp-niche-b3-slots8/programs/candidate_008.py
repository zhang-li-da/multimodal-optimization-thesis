def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    rg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    inv_d = 1.0 / (d + 1e-9)
    inv_nr = 1.0 / (nr + 1e-9)
    base = -d + (0.25 * (0.4 + 0.6 * p)) * r
    regret_term = (0.10 * (0.3 + 0.7 * p)) * c * rg
    penalty = (0.05 + 0.10 * p) * (rg + s * inv_nr)
    nudge = 0.05 * p * (inv_d - inv_nr)
    return base + regret_term - penalty + nudge
