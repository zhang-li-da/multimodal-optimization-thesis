def priority(f):
    d = f['distance']
    r = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    p = f['progress']
    c = f['cluster_density']
    s = f['spread']
    inv_d = 1.0 / (d + 1e-9)
    inv_nr = 1.0 / (nr + 1e-9)
    safe_mr = mr if mr > 1e-9 else 1e-9
    base = -d
    close_pen = (0.30 + 0.45 * p) * r
    regret_term = (0.10 + 0.25 * p) * c * rg
    spread_pen = (0.05 + 0.10 * p) * s * nr / safe_mr
    nudge = 0.04 * p * (inv_d - inv_nr)
    return base + close_pen + regret_term - spread_pen + nudge
