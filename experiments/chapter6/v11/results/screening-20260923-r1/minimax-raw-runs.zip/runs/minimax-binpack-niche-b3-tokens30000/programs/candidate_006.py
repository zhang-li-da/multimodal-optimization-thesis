def priority(f):
    item = f['item']
    gap = f['gap']
    min_gap = f['min_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    denom = gap + min_gap + 1e-9
    harmonic = (gap - min_gap) / denom
    logistic = 1.0 / (1.0 + 4.0 * abs(gap - item))
    p = -gap + 0.08 * harmonic - 0.15 * logistic * (1.0 - fraction_fitting) + 0.001 * position
    return p