def priority(f):
    item = f['item']
    gap = f['gap']
    min_gap = f['min_gap']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    position = f['position']
    mid = 0.5 * (min_gap + mean_gap)
    drift = gap - mid
    logistic = 1.0 / (1.0 + 8.0 * abs(item - gap))
    denom = abs(mean_gap) + 1e-9
    balance = (gap - mean_gap) * std_gap / denom
    p = -gap + 0.10 * drift - 0.20 * logistic - 0.03 * balance + 0.001 * position
    return p
