def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    dev = gap - mean_gap
    p = -gap - 0.5 * gap * gap / (mean_gap + 1e-3) + 0.4 * dev * dev / (mean_gap + 1e-3) - 0.25 * std_gap / (gap + 1e-3) + 0.3 * (1 - fraction_fitting) + 0.15 * (1 - position) - 0.05 * fill * fill
    return p
