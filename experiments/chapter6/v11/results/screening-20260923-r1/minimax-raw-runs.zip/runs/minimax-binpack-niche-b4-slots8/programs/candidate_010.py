def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    fill = f["fill"]
    std_gap = f["std_gap"]
    item = f["item"]
    inv_gap = 1.0 / (gap + 1e-9)
    dev = gap - mean_gap
    p = -gap
    p = p + 0.08 * (1.0 - fill) * (gap < 0.5 * item)
    p = p - 0.15 * dev * dev / (gap + 1e-3)
    p = p - 0.03 * fill * fill
    p = p + 0.25 * (1.0 - fraction_fitting)
    p = p + 0.15 * (1.0 - position)
    p = p + 0.05 * fraction_fitting * std_gap * inv_gap
    return p
