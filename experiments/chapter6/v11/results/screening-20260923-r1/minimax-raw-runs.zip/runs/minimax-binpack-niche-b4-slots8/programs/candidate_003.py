def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fill = f["fill"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    std_gap = f["std_gap"]
    remaining = f["remaining"]
    inv_gap = 1.0 / (gap + 1e-9)
    inv_remaining = 1.0 / (remaining + 1e-9)
    p = -gap - 0.25 * mean_gap
    p = p + 1.5 * (1.0 - fraction_fitting)
    p = p + 0.5 * (1.0 - position)
    p = p + 0.1 * std_gap * inv_gap
    p = p - 0.05 * fill * fill
    p = p - 0.02 * mean_gap * inv_remaining
    return p
