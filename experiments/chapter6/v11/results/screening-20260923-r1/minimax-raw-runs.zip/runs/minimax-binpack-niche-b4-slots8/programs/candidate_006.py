def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    fill = f["fill"]
    std_gap = f["std_gap"]
    remaining = f["remaining"]
    item = f["item"]
    inv_gap = 1.0 / (gap + 1e-9)
    inv_remaining = 1.0 / (remaining + 1e-9)
    dev = gap - mean_gap
    p = -gap - 0.4 * mean_gap
    p = p + 0.3 * (1.0 - fraction_fitting)
    p = p + 0.2 * (1.0 - position)
    p = p - 0.15 * dev * dev / (gap + 1e-3)
    p = p + 0.1 * std_gap * inv_gap
    p = p - 0.05 * fill * fill
    p = p - 0.02 * mean_gap * inv_remaining
    p = p + 0.02 * item * (1.0 - fill)
    return p
