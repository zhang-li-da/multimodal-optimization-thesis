def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-3
    alpha = 0.6
    beta = 0.05
    gamma = 0.2
    delta = 0.1
    denom = mean_gap + eps
    dev = gap - mean_gap
    p = -gap - alpha * dev * dev / denom - beta * fill * fill + gamma * (1.0 - fraction_fitting) + delta * (1.0 - position)
    return p