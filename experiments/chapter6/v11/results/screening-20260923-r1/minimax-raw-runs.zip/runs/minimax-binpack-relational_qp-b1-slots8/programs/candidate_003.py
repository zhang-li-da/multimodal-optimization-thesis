def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    base = -gap
    tight = abs(remaining - item)
    near_exact = abs(gap)
    fill_bias = fill * (remaining - item)
    pos_bias = position * 0.05
    p = base - 0.25 * tight - 0.05 * near_exact + 0.1 * fill_bias - pos_bias
    denom = fraction_fitting
    safe = denom if denom >= 1e-9 else 1e-9
    p = p + 0.05 * std_gap / safe
    p = p - 0.05 * (gap - min_gap) / safe
    return p
