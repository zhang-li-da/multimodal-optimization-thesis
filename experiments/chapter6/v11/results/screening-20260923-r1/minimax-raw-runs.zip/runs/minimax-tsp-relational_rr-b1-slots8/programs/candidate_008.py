def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nd = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    guard = 1e-9
    inv_mr = 1.0 / (mr + guard)
    density_term = 0.25 * cd * (1.0 - 0.50 * pr)
    return_term = 0.20 * pr * rd * inv_mr
    regret_term = 0.15 * rg * (1.0 - cd)
    spread_penalty = 0.03 * sp
    nd_mr_diff = (nd - mr) * inv_mr
    progress_term = 0.10 - 0.20 * pr
    return -d + density_term + return_term + regret_term - spread_penalty + 0.05 * nd_mr_diff + progress_term + 0.10 * pr * rg
