def priority(f):
    d = f["distance"]
    cd = f["cluster_density"]
    rg = f["regret"]
    nd = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rd = f["return_distance"]
    pr = f["progress"]
    sp = f["spread"]
    guard = 1e-9
    inv_mr = 1.0 / (mr + guard)
    one_minus_cd = 1.0 - cd
    regret_w = 0.20 + 0.20 * one_minus_cd + 0.10 * pr
    progress_density = 0.20 * pr * rd * inv_mr
    density_bonus = 0.12 * cd * (1.0 - 0.50 * pr)
    spread_penalty = 0.03 * sp
    balance = 0.06 * (nd - mr) * inv_mr
    late_cluster = 0.05 * pr * one_minus_cd
    return -d + regret_w * rg + progress_density + density_bonus - spread_penalty + balance + late_cluster
