def priority(f):
    d = f["distance"]
    cd = f["cluster_density"]
    rg = f["regret"]
    nd = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rd = f["return_distance"]
    pr = f["progress"]
    sp = f["spread"]
    guard = 1e-9
    inv_mr = 1.0 / (mr + guard)
    inv_nd = 1.0 / (nd + guard)
    rg_weight = 0.20 + 0.15 * (1.0 - cd)
    return -d + rg_weight * rg + 0.15 * rd * inv_mr + 0.10 * cd * (1.0 - 0.60 * pr) - 0.02 * sp + 0.05 * (nd - mr) * inv_nd