def priority(f):
    d = f["distance"]
    cd = f["cluster_density"]
    rg = f["regret"]
    nd = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rd = f["return_distance"]
    pr = f["progress"]
    sp = f["spread"]
    guard = 1e-9
    inv_mr = 1.0 / (mr + guard)
    inv_nd = 1.0 / (nd + guard)
    progress_term = 0.15 - 0.30 * pr
    return -d + 0.30 * cd + 0.10 * rg + 0.05 * rd * inv_mr + 0.05 * (nd - mr) * inv_nd + progress_term - 0.02 * sp + 0.25 * pr * rg
