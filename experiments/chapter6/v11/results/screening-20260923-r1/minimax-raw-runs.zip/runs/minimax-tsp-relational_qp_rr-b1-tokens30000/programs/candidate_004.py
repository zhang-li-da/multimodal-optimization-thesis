def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    n = f["nearest_remaining"]
    cd = f["cluster_density"]
    inv_n = 1.0 / (n + 1e-9)
    inv_d = 1.0 / (d + 1e-9)
    base = -1.0 * d + 0.12 * r + 0.30 * g
    cluster_bonus = 0.10 * cd + 0.05 * inv_n + 0.02 * inv_d
    return base + cluster_bonus
