def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    return -1.0 * d + 0.20 * r + 0.15 * g
