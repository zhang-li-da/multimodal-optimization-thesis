def priority(f):
    d = f['distance']
    rd = f['return_distance']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cl = f['cluster_density']
    sd = f['spread']
    safe_sd = sd / (sd + 1e-9)
    base = -d
    return_pen = (0.10 + 0.20 * pr) * rd
    regret_term = 0.10 * (rg - 0.5 * mr)
    cluster_term = 0.05 * cl
    spread_term = 0.05 * safe_sd
    progress_pen = -0.05 * pr
    return base + return_pen + regret_term + cluster_term + spread_term + progress_pen
