def priority(f):
    d = f['distance']
    nr = f['nearest_remaining']
    cl = f['cluster_density']
    rd = f['return_distance']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    return -d + (0.15 + 0.20 * pr) * rd + 0.08 * cl + 0.08 * (rg - 0.4 * mr)
