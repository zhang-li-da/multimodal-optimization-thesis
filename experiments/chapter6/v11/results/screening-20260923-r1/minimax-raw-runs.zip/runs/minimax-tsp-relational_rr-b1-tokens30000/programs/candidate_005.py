def priority(f):
    m = f['mean_remaining']
    denom = m if m > 1e-9 else 1e-9
    cluster = f['cluster_density']
    if cluster < 1e-9:
        cluster = 1e-9
    regret_norm = f['regret'] / denom
    return_norm = f['return_distance'] / denom
    return -f['distance'] + 0.30 * cluster + 0.20 * regret_norm - 0.10 * return_norm
