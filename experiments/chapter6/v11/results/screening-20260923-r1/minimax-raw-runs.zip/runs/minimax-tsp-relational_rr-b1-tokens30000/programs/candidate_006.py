def priority(f):
    d = f["distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    rd = f["return_distance"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    norm_mr = mr if mr > 1e-9 else 1e-9
    nr_norm = nr / norm_mr
    sp_norm = sp / norm_mr
    rd_norm = rd / norm_mr
    inv_d = -d
    inv_rd = -0.10 * rd_norm
    la = 0.25 * nr_norm
    urg = 0.20 * (r / norm_mr)
    cluster_bonus = 0.05 * cd
    spread_pen = 0.05 * sp_norm
    progress_pull = 0.05 * (1.0 - pr) * inv_d
    base = inv_d + la + urg + inv_rd + cluster_bonus - spread_pen
    final = base + progress_pull
    if final != final:
        final = inv_d
    return final
