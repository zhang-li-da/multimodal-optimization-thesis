def priority(f):
    mr = f['mean_remaining']
    if mr < 1e-9:
        mr = 1e-9
    return -f['distance'] + 0.20 * f['return_distance'] / mr + 0.25 * f['regret'] / mr