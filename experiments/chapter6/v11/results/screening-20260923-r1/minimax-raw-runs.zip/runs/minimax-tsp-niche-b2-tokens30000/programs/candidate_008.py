def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = max(0.0, f["regret"])
    cap = 2.0 * (d + 1e-9)
    rg = g if g < cap else cap
    p = f["progress"]
    c = f["cluster_density"]
    logp = 0.06 * (d * d + 1.0)
    score = -(d + logp) + 0.30 * r + (1.0 - p) * 0.18 * rg + 0.08 * c
    return score