def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    rg = g if g > 0.0 else 0.0
    if rg > 4.0 * (d + 1e-9):
        rg = 4.0 * (d + 1e-9)
    return -d + 0.25 * r + 0.15 * rg
