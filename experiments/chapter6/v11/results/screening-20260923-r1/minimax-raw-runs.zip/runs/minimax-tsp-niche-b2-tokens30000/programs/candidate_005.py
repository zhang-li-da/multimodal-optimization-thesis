def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = max(0.0, f["regret"])
    cap = 2.0 * (d + 1e-9)
    rg = g if g < cap else cap
    p = f["progress"]
    log1p_d2 = 0.10 * (d * d + 1.0)
    score = -(d + 0.10 * (d * d + 1e-9)) + 0.28 * r + (1.0 - p) * 0.30 * rg
    return score