def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    sp = f["spread"]
    p = f["progress"]
    cd = f["cluster_density"]
    g = max(0.0, f["regret"])
    cap = 2.0 * (d + 1e-9)
    rg = g if g < cap else cap
    logp = 0.06 * (d * d + 1.0)
    spcap = 0.5 * d
    sps = sp if sp < spcap else spcap
    score = -(d + 0.5 * nr + logp) + 0.28 * r + (1.0 - p) * 0.18 * rg + 0.07 * cd - 0.05 * sps
    return score