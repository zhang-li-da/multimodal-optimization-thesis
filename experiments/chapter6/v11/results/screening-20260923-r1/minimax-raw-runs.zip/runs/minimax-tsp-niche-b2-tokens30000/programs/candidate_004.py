def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    rg = g if g > 0.0 else 0.0
    cap = 3.0 * (d + 1e-9)
    rg = rg if rg < cap else cap
    p = f["progress"]
    return -(d + 0.15 * (d * d - d)) + 0.25 * r + (1.0 - p) * 0.35 * rg