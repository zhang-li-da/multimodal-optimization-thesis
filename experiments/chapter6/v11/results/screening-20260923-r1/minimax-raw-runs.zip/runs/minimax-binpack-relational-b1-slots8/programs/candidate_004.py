def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    sd = std_gap + 0.05
    d = gap - mean_gap
    tight = -(d * d) / sd
    size_pen = -0.6 * item * gap
    pos_adj = -0.4 * position
    fit_adj = 0.3 * fraction_fitting
    fill_bonus = 0.0
    if remaining > 0.0:
        fill_bonus = 0.5 * (1.0 - remaining)
    return tight + size_pen + pos_adj + fit_adj + fill_bonus