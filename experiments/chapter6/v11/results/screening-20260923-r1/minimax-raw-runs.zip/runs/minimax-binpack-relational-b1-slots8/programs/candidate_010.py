def priority(f):
    item = f["item"]
    gap = f["gap"]
    frac = f["fraction_fitting"]
    std = f["std_gap"]
    pos = f["position"]
    tight = -3.2 * gap
    over = 1.6 * max(0.0, 0.5 * item - gap)
    consol = 0.7 * (1.0 - frac)
    resid = -0.4 * item * gap
    spread = 0.12 * std
    exact = 1.8 if gap < 1e-6 else 0.0
    tie = -0.1 * pos
    return tight + over + consol + resid + spread + exact + tie