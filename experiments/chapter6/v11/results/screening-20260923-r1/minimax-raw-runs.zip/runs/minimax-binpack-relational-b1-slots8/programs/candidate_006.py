def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    min_gap = f['min_gap']
    position = f['position']
    target = mean_gap - 0.5 * std_gap
    d = gap - target
    denom = std_gap + 0.05
    gauss = -(d * d) / denom
    size_pen = -0.8 * item * gap
    pos_pen = -0.2 * position
    extra = max(0.0, gap - min_gap) * 0.3
    return gauss + size_pen + pos_pen + extra
