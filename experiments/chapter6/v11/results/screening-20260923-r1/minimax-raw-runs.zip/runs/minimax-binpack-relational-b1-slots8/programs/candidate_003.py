def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    near_exact = abs(gap)
    tail_waste = max(0.0, item - near_exact - 0.5 * item)
    exact_bonus = -4.0 * tail_waste
    tight_bonus = -2.0 * gap
    fit_pressure = -0.5 * (1.0 - fraction_fitting)
    variance_penalty = -0.3 * std_gap
    rank_bonus = -0.2 * position
    fill_credit = 0.5 * fill
    return tight_bonus + exact_bonus + fit_pressure + variance_penalty + rank_bonus + fill_credit
