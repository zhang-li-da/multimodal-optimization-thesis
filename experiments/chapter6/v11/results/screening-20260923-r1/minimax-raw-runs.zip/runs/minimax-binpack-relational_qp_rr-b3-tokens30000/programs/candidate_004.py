def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    safe_std = std_gap + 1e-3
    safe_min = min(min_gap, 0.999999)
    safe_mean = max(mean_gap, 1e-6)
    z = (gap - safe_mean) / safe_std
    tight_penalty = -100.0 * gap * gap
    tight_penalty = tight_penalty - 50.0 * (gap - safe_min)
    fill_bonus = 20.0 * fill * fill
    competition = 1.0 / (1.0 + fraction_fitting)
    pos_penalty = -0.2 * position
    overfill = max(remaining - item, 0.0)
    overfill_penalty = -5.0 * overfill
    score = z + tight_penalty + fill_bonus + competition + pos_penalty + overfill_penalty
    return score
