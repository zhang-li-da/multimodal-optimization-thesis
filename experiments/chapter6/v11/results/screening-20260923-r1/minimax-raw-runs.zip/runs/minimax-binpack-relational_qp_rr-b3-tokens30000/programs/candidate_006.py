def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']

    safe_std = std_gap + 1e-3
    z = (gap - mean_gap) / safe_std
    z_score_term = -abs(z)

    exact_fill_bonus = 25.0 * fill * fill

    tight_penalty = 0.0
    safe_item = abs(item) + 1e-9
    if gap < safe_item:
        tight_penalty = 1.0

    min_gap_bonus = -0.5 * min_gap

    fit_pressure = 1.0 / (fraction_fitting + 1e-9)

    position_term = -0.1 * position

    score = (z_score_term + exact_fill_bonus - tight_penalty + min_gap_bonus + fit_pressure + position_term)

    if gap < 0.0:
        score = -1e6

    return score
