def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    s = f["spread"]
    eps = 1e-9
    safe_mr = mr + eps
    regrate = rg / safe_mr
    early = 1.0 - p
    inv_spread = 1.0 / (s + eps)
    return (-d
            + 0.30 * r
            - 0.40 * c
            - 0.10 * nr / safe_mr
            + 0.05 * regrate * early
            + 0.02 * inv_spread)
