def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    rg = f["regret"]
    cd = f["cluster_density"]
    sp = f["spread"]
    p = f["progress"]
    eps = 1e-9
    early = 1.0 - p
    safe_rg = rg / (1.0 + rg)
    return (-d + 0.25 * rd - 0.10 * p * nr + 0.10 * early * cd + 0.15 * safe_rg - 0.03 * sp + eps)
