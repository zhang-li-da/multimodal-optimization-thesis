def priority(f):
    d = f["distance"]
    c = f["cluster_density"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    eps = 1e-9
    safe_mr = mr + eps
    early = 1.0 - p
    weight = 0.25 + 0.55 * early
    return (-d + 0.5 * nr - 0.35 * c - 0.20 * mr + weight * rg)