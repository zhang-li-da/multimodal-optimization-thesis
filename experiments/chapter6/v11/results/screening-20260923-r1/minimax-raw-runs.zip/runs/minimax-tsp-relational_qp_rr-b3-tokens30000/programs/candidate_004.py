def priority(f):
    d = f["distance"]
    rt = f["return_distance"]
    rg = f["regret"]
    p = f["progress"]
    return -d + 0.22 * rt + 0.12 * rg * (1.0 - 0.5 * p)
