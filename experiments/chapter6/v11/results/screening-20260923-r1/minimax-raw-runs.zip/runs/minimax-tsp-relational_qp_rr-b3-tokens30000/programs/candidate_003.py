def priority(f):
    d = f["distance"]
    rg = f["regret"]
    rt = f["return_distance"]
    return -d + 0.20 * rg + 0.15 * rt
