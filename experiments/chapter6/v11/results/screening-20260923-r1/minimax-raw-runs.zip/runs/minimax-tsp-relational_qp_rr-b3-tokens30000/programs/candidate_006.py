def priority(f):
    d = f["distance"]
    rg = f["regret"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    p = f["progress"]
    eps = 1e-9
    return -d + 0.2 * rg * (1 - 0.6 * p) + 0.18 * rd * (1 - 0.5 * p) + 0.12 * cd * (1 - p) + 0.08 * sp / (d + eps) - 0.05 * nr / (d + eps)