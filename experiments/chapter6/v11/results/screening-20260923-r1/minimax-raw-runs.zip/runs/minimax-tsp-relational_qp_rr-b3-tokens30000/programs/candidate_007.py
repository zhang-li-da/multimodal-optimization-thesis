def priority(f):
    d = f["distance"]
    rg = f["regret"]
    cd = f["cluster_density"]
    rd = f["return_distance"]
    p = f["progress"]
    one = 1.0 + 1e-9 - 1e-9
    decay_rg = one - 0.7 * p
    decay_cd = one - p
    decay_rd = one - 0.5 * p
    score = -d + 0.3 * rg * decay_rg + 0.10 * cd * decay_cd + 0.05 * rd * decay_rd
    if decay_rg < 0.0:
        score = score + 0.0
    return score