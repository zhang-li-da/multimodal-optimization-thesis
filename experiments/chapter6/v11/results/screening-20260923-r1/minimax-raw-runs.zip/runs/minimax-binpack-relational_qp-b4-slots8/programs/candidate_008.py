def priority(f):
    item = f["item"]
    gap = f["gap"]
    frac = f["fraction_fitting"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    pos = f["position"]
    s = -gap
    tight = min(gap, item) - 0.5 * item
    loose = item - gap
    if loose < 0.0:
        loose = 0.0
    s = s + 0.15 * tight - 0.10 * loose
    dev = std_gap / (mean_gap + 1e-9)
    s = s - 0.05 * dev
    s = s + 0.20 * (frac - 1.0 / (pos + 1.0))
    s = s + 0.10 * fill
    return s
