def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fill = f["fill"]
    denom = mean_gap + 1e-9
    dev = (gap - mean_gap) / denom
    if dev < 0:
        dev = -dev
    return -gap - 0.30 * dev + 0.10 * fill
