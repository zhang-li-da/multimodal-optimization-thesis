def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    e = 1e-9
    a = 0.25 - 0.20 * pr
    return -d + a * rd - 0.10 * rg * (1.0 - pr) + 0.04 * cd * (1.0 - 0.5 * pr) + 0.01 * sp - 0.02 * mr + 0.05 * nr
