def priority(f):
    d = f["distance"]
    rr = f["return_distance"]
    nr = f["nearest_remaining"]
    rg = f["regret"]
    mr = f["mean_remaining"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    denom = mr + eps
    base = -d + 0.08 * rr - 0.08 * nr + 0.28 * (rg / denom)
    density_bonus = 0.04 * cd * (1.0 - pr) + 0.02 * (1.0 - cd) * pr
    spread_pen = 0.02 * (sp / denom)
    return base + density_bonus + spread_pen