def priority(f):
    d = f["distance"]
    rr = f["return_distance"]
    nr = f["nearest_remaining"]
    rg = f["regret"]
    mr = f["mean_remaining"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    return -d + 0.10 * rr - 0.10 * nr + 0.18 * (rg / (mr + eps)) + 0.05 * cd * (1.0 - pr) + 0.03 * (sp / (mr + eps))