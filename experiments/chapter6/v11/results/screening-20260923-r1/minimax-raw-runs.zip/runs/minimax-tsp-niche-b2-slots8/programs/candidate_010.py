def priority(f):
    d = f["distance"]
    rr = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    return -d + 0.12 * rr + 0.22 * rg / (mr + eps) + 0.05 * cd * (1 - pr) + 0.03 * (1 - cd) * pr + 0.03 * ((sp / (mr + eps) - 1) * 1.5 + (mr / (mr + eps) - 1) * (-1.5))