def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    fill = f["fill"]
    remaining = f["remaining"]
    eps = 1e-9
    score = 0.0
    score = score - gap
    score = score + 0.01 * (gap - item)
    cond1 = gap < (item + 0.05)
    if cond1:
        score = score + 0.5 * (item - gap)
    cond2 = gap <= (item + 0.1)
    if cond2:
        score = score + 0.2 * (1.0 - fraction_fitting)
    if std_gap > eps:
        score = score - 0.05 * std_gap
    if (mean_gap - min_gap) > eps:
        score = score - 0.02 * (mean_gap - min_gap)
    score = score - 0.01 * position
    return score