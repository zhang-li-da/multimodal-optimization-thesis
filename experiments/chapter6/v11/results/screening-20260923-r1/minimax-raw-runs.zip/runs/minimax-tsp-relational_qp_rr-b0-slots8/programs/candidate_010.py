def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    s = nr + mr - 2 * rd
    clip = s
    if clip > 0.3:
        clip = 0.3
    if clip < -0.3:
        clip = -0.3
    penalty = pr * pr * clip
    late = pr - 0.3
    if late < 0:
        late = 0
    regret_term = 0.10 * late * rg
    return -d + 0.25 * rd - penalty + regret_term
