def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    mean_gap = f['mean_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    exact = 1.0 if gap <= eps else 0.0
    denom = mean_gap if mean_gap > eps else eps
    deviation = (gap - mean_gap) / denom
    dev_pen = deviation * deviation
    spread_pen = item * fraction_fitting
    loose_bonus = max(0.0, remaining - item - mean_gap)
    score = -gap + 2.0 * exact - 0.5 * dev_pen - 0.3 * spread_pen + 0.2 * loose_bonus - 0.05 * position
    return score
