def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    position = f['position']
    eps = 1e-9
    exact = 1.0 if gap <= eps else 0.0
    denom = mean_gap + eps
    diff = (gap - mean_gap) / denom
    penalty = 1.2 * max(0.0, diff) if diff > 0.0 else 0.0
    score = -gap + 3.0 * exact - penalty - 0.05 * position
    return score
