def priority(f):
    item = f['item']
    gap = f['gap']
    remaining = f['remaining']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fill = f['fill']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    alpha = 0.3
    beta = -0.1
    gamma = 0.05
    delta = 0.15
    eps = 1e-3
    score = -gap
    score = score + alpha * max(0.0, 2.0 * item - remaining)
    score = score + beta * (1.0 if gap < item else 0.0)
    score = score + gamma * max(0.0, 0.5 - fraction_fitting)
    score = score + delta * max(0.0, min_gap - gap)
    score = score - eps * position
    return score