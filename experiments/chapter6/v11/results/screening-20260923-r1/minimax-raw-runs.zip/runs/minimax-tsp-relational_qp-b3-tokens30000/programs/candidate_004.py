def priority(f):
    p = f['progress']
    rd = f['return_distance']
    rg = f['regret']
    d = f['distance']
    sp = f['spread']
    return -d + (0.35 * (p * p)) * rd + (0.35 - 0.30 * p) * rg + 0.05 * p * (1.0 - p) * sp
