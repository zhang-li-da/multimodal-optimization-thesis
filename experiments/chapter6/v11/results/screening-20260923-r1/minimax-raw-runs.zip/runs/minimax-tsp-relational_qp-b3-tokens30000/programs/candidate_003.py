def priority(f):
    p = f['progress']
    rd = f['return_distance']
    rg = f['regret']
    d = f['distance']
    return -d + (0.15 + 0.30 * p) * rd + (0.30 - 0.25 * p) * rg