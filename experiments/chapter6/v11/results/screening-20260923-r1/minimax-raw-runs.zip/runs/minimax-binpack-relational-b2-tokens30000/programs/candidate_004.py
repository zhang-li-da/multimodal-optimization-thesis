def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    safe_item = item if abs(item) > eps else eps
    a = -0.5 * gap
    b = -0.3 * (gap - mean_gap)
    c = 0.2 * (min_gap - gap) / max(safe_item, eps)
    d = -0.1 * std_gap
    e = -0.05 * position
    fr = fraction_fitting / (fraction_fitting + 1.0)
    g = 0.4 * fr
    return a + b + c + d + e + g
