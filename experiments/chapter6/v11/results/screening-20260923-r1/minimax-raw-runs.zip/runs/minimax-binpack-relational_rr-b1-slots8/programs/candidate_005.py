def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    position = f['position']
    score = -gap + 0.3 * item * (gap - item) + 0.05 * (gap - mean_gap) - 0.02 * position
    return score