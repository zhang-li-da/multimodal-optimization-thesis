def priority(f):
    item = f['item']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    position = f['position']
    diff = gap - mean_gap
    score = -(gap * item) - 0.5 * (diff * diff) / (abs(std_gap) + 0.001) + 0.001 * fill + 0.0001 * position
    return score
