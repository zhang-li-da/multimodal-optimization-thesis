def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    fill = f["fill"]
    position = f["position"]
    sq = gap * gap
    diff = gap - mean_gap
    denom = std_gap + 1e-3
    deviation = (diff * diff) / denom
    tight = -sq - 0.5 * deviation
    bonus = 0.001 * fill + 0.0001 * position
    score = tight + bonus
    return score
