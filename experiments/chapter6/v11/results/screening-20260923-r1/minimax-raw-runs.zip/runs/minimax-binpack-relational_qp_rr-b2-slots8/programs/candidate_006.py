def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fill = f['fill']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    remaining = f['remaining']
    threshold = 2 * item * (1 - item)
    safe_mean = mean_gap + 1e-9
    safe_pos = position + 1e-9
    if gap >= threshold:
        score = -gap
        score = score + 0.05 * (gap - safe_mean) ** 2
        score = score + 0.02 * (fraction_fitting - 0.5)
        score = score - 0.001 * safe_pos
        score = score + 0.01 * std_gap
        score = score - 0.02 * min_gap
        score = score - 0.005 * fill
    else:
        score = gap
        score = score - 0.1 * (safe_mean - gap)
        score = score + 0.02 * (fraction_fitting - 0.5)
        score = score - 0.001 * safe_pos
        score = score - 0.01 * std_gap
        score = score - 0.02 * min_gap
        score = score - 0.005 * fill
    return score
