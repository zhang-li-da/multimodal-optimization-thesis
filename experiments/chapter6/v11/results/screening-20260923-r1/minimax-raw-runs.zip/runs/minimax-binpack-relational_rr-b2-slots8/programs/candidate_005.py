def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    position = f["position"]
    alpha = 1.0 / (1.0 + ((0.25 * item - gap) / 0.1) ** 2) ** 0.5
    score = -gap * (1.0 - alpha) + gap * alpha
    exact = -50.0 if gap < 1e-9 else 0.0
    return score + exact - 0.2 * fill - 0.05 * position
