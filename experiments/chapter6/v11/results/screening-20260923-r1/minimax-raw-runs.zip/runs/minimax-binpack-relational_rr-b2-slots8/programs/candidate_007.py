def priority(f):
    item = f['item']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    diff = item - gap
    sig = 1 / (1 + exp(10 * diff))
    base = -gap * (1 - sig) + gap * sig
    exact = -40 if gap < 1e-9 else 0
    scarcity = 1 - fraction_fitting
    scarcity = max(0, min(1, scarcity))
    score = base + exact - 0.1 * fill - 0.03 * position + 0.04 * std_gap * scarcity
    tight = gap / (item + 1e-9)
    tight = max(0, min(1, tight))
    score = score - 0.5 * tight * fraction_fitting
    if fill < 0.25:
        score = score + 0.3 * gap
    if min_gap < 1e-9:
        score = score - 5
    return score
