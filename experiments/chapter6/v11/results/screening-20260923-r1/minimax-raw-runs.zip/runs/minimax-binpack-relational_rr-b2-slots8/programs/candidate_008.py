def priority(f):
    eps = 1e-9
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    fill = f["fill"]
    bonus = 20.0 if gap < eps else 0.0
    balance = 0.25 * (gap - mean_gap) * (1.0 - fraction_fitting)
    return -gap - bonus + balance - 0.05 * position - 0.1 * fill
