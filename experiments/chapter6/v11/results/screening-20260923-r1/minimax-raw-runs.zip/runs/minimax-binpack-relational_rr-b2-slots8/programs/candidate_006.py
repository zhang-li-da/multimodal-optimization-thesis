def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-9
    diff = item - gap
    k = 12.0
    sig_pos = 1.0 / (1.0 + (k * diff)**0.5 if False else 1.0)
    if diff > 0:
        sig = 1.0 / (1.0 + (k * diff))
    else:
        sd = -diff * k
        if sd > 50.0:
            sd = 50.0
        sig = 1.0 / (1.0 + sd)
    tight = -gap
    loose = gap
    base = tight * (1.0 - sig) + loose * sig
    exact_bonus = 25.0 if gap < eps else 0.0
    fill_w = 0.15 * fill
    pos_w = 0.02 * position
    score = base + exact_bonus - fill_w - pos_w
    if fraction_fitting < 1.0 - eps:
        score = score + 0.05 * std_gap
    return score
