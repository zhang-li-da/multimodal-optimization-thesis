def priority(f):
    eps = 1e-9
    gap = f["gap"]
    item = f["item"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    fill = f["fill"]
    excess = gap - 0.5 * item
    waste_pen = 1.5 * excess if excess > 0.0 else 0.0
    bonus = -18.0 if gap < eps else 0.0
    scarcity = 1.0 - fraction_fitting
    if scarcity < 0.0:
        scarcity = 0.0
    balance = 0.3 * (gap - mean_gap) * scarcity
    pos_pen = -0.04 * position
    fill_pen = -0.08 * fill
    return -gap + waste_pen + bonus + balance + pos_pen + fill_pen
