def priority(f):
    d = f['distance']
    r = f['return_distance']
    p = f['progress']
    return -d + 0.25 * p * r
