def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    score = 0.0
    if gap < eps:
        score = score + 1000000.0
    elif gap < 0.05:
        score = score + 100.0
    diff = gap - mean_gap
    score = score - 1.0 * abs(diff)
    score = score - 0.3 * gap / (item + eps)
    score = score - 0.15 * abs(fill - 0.5)
    score = score + 0.05 * (position - 0.5)
    score = score - 0.02 * std_gap
    if fraction_fitting > 0.5:
        score = score + 0.02
    return score