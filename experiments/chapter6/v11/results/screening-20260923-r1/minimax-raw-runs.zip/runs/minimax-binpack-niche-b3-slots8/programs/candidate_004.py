def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    bonus = 0.0
    if gap < eps:
        bonus = 1.0
    elif gap < 0.05:
        bonus = 0.5
    alpha = 0.5
    beta = 0.2
    gamma = 0.1
    loose_term = -gap + alpha * gap * fill
    balance_term = -beta * fill * (1.0 - fill)
    spread_term = gamma * (position - 0.5)
    score = loose_term + balance_term + spread_term + bonus
    if fill < 0.5:
        score = score + 0.05
    elif fill > 0.9:
        score = score - 0.05
    if std_gap > 0.1:
        score = score - 0.02 * std_gap
    if fraction_fitting > 0.5:
        score = score + 0.02
    return score
