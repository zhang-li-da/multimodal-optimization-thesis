def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    score = 0.0
    if gap < eps:
        score = score + 1000000.0
    elif gap < 0.03:
        score = score + 200.0
    elif gap < 0.10:
        score = score + 30.0
    elif gap < 0.25:
        score = score + 50.0
    rratio = remaining + eps
    score = score - (gap / (item + eps)) * (1.0 + 2.0 * item / rratio)
    mdiff = gap - mean_gap
    score = score - 1.5 * (mdiff if mdiff > 0.0 else 0.0)
    score = score - 0.2 * abs(fill - 0.6)
    score = score + 0.05 * position
    score = score - 0.03 * std_gap
    if fill > 0.3 and fill < 0.7:
        score = score + 0.05
    return score