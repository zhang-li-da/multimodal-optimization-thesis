def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr if mr > 1e-9 else 1e-9
    ratio = nr / safe_mr
    one_minus_ratio = 1.0 - ratio
    cluster_signal = one_minus_ratio if one_minus_ratio < 1.0 else 1.0
    cluster_signal = -cluster_signal if cluster_signal < 0.0 else cluster_signal
    spread_term = sp if sp > 1e-9 else 1e-9
    log_spread = log(spread_term)
    inv_spread = 1.0 / spread_term
    regret_term = rg if rg > 0.0 else 0.0
    progress_term = pr if pr < 1.0 else 1.0
    progress_term = -progress_term if progress_term < 0.0 else progress_term
    density_term = cd if cd < 1.0 else 1.0
    density_term = -density_term if density_term < 0.0 else density_term
    base = -d + 0.15 * r + 0.15 * rg + 0.20 * cluster_signal - 0.05 * log_spread - 0.05 * density_term + 0.05 * pr
    penalty = inv_spread * regret_term
    return base - 0.05 * penalty + 0.02 * progress_term * regret_term