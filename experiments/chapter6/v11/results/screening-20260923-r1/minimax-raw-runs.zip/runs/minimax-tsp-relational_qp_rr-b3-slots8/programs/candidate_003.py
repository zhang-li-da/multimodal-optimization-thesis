def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    pr = f["progress"]
    safe_mr = mr if mr > 1e-9 else 1e-9
    ratio = nr / safe_mr
    return -d + 0.20 * r + 0.25 * g - 0.10 * sp + 0.15 * (1.0 - ratio) - 0.05 * cd + 0.05 * pr