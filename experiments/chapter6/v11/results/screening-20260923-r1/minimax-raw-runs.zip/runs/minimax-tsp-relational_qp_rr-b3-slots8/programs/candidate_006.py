def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    lookahead = mr - nr
    score = -d + 0.20 * lookahead - 0.15 * rd + 0.30 * rg + 0.05 * pr
    eps = 1e-9
    guard = 1.0 / (d + eps)
    score = score * (1.0 + 0.01 * guard)
    return score
