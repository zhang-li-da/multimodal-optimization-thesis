def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]

    inv_frac = 1.0 - fraction_fitting
    inv_pos = 1.0 - position

    score = -gap
    score = score + 0.05 * inv_frac * inv_pos
    score = score - 0.001 * position
    score = score - 0.02 * std_gap
    score = score + 0.01 * fill * inv_frac
    score = score - 0.03 * (gap - min_gap)
    score = score - 0.5 * abs(mean_gap - gap)

    denom = remaining + 1e-9
    norm_fill = fill + 0.001 * (1.0 / denom)
    score = score + 0.001 * norm_fill * inv_pos

    return score
