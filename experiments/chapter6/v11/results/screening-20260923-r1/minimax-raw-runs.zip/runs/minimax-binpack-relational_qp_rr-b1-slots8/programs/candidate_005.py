def priority(f):
    item = f['item']
    gap = f['gap']
    position = f['position']
    diff = gap - item
    abs_diff = abs(diff)
    return -abs_diff - 0.1 * gap - 1e-3 * position
