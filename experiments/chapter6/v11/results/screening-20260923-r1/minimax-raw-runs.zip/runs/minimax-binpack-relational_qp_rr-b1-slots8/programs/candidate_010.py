def priority(f):
    eps = 1e-9
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    frac = f["fraction_fitting"]
    pos = f["position"]
    a = abs(gap - mean_gap) / (mean_gap + eps)
    b = abs(gap - min_gap) / (min_gap + eps)
    c = abs(gap - 1.5 * item) / (item + eps)
    score = -a - 0.05 * b - 0.05 * std_gap + 0.05 * fill - 0.02 * max(gap - 1.5 * item, 0) / (item + eps) + 0.02 * (1 - frac) - 1e-3 * pos
    return score