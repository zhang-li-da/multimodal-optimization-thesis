def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-6
    diff = gap - mean_gap
    denom = std_gap + eps
    quad = (diff * diff) / denom
    score = -quad - 0.5 * gap + 0.3 * fill - 0.01 * position
    score = score + 0.05 * fraction_fitting - 0.02 * min_gap
    score = score + 0.1 * (1.0 - abs(item - gap) / (item + eps))
    if remaining < 2.0 * item:
        score = score + 0.2 * fill
    return score