def priority(f):
    item = f['item']
    gap = f['gap']
    min_gap = f['min_gap']
    fraction_fitting = f['fraction_fitting']
    std_gap = f['std_gap']
    mean_gap = f['mean_gap']
    position = f['position']
    target_offset = (item / 2.0) * (2.0 * fraction_fitting - 1.0)
    dev = (gap - min_gap) - target_offset
    sign = 1.0 if fraction_fitting < 0.5 else -0.5
    quad_pen = sign * 0.25 * dev * dev / (item * item + 1e-9)
    log_pen = 0.02 * std_gap / (abs(mean_gap) + 1e-9)
    score = -gap + quad_pen + log_pen + 0.001 * position
    return score
