def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    denom_gap = gap + 1e-9
    dist = abs(gap - mean_gap)
    score = -dist / denom_gap
    score = score - 0.001 * std_gap
    score = score + 0.0005 * fraction_fitting
    if gap == 0:
        score = score + 1000.0
    score = score - 1e-18 * position
    return score
