def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    dn = 1.0 - 0.4 * p
    rn = 0.1 + 0.2 * p
    base = -dn * d + 0.3 * r + rn * (1.0 - 0.4 * p) * rd
    second = 0.12 * cd + 0.1 * (nr / (mr + 1e-9) - 1.0) - 0.08 * sp
    late = 0.08 * p / (d + 1e-9)
    return base + second + late
