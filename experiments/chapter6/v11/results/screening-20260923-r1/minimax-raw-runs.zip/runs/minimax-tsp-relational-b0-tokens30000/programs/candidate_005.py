def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    dn = 1.0 - 0.4 * p
    rn = 0.1 + 0.2 * p
    return -dn * d + 0.3 * r + rn * rd + 0.15 * cd - 0.1 * sp
