def priority(f):
    d = f['distance']
    r = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    cd = f['cluster_density']
    eps = 1e-9
    mr_safe = mr + eps
    base = -d
    return_term = 0.20 * (r / mr_safe)
    regret_term = 0.30 * (rg / mr_safe)
    cluster_pen = 0.05 * cd
    quad = 0.01 * (min(r, 2.0) ** 2)
    score = base + return_term + regret_term - cluster_pen + quad
    if nr < d:
        score = score - 0.05
    return score
