def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    return -d + 0.30 * r - 0.05 * c + 0.02 * r * r
