def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    mean_step = (d + nr + mr) / 3.0
    safe_r = r if r > 0.0 else 1e-9
    log_r = log(safe_r)
    bounded_r = log_r if log_r < 1.5 else 1.5
    rg_term = rg / (mr + 1e-9)
    cd_term = cd * cd
    pr_term = pr * mean_step
    sp_term = sp / (mr + 1e-9)
    return -d + 0.15 * bounded_r + 0.25 * rg_term - 0.04 * cd_term + 0.01 * r * r + 0.05 * pr_term - 0.02 * sp_term