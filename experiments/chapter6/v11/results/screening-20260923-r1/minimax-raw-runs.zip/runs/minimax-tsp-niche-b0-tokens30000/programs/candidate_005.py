def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    rg = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.20 * r + 0.15 * rg - 0.08 * cd
