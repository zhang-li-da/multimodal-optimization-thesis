def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    eps = 1e-9
    safe_mr = mr if mr > 0.0 else eps
    safe_r = r if r > 0.0 else eps
    capped_r = safe_r / safe_mr
    bounded_r = capped_r if capped_r < 1.5 else 1.5
    rg_term = rg / safe_mr
    nr_term = nr / safe_mr
    cd_pen = (0.08 + 0.05 * pr) * cd
    pr_bonus = (0.04 * pr) * nr_term
    score = -d + 0.18 * bounded_r + 0.20 * rg_term - cd_pen + pr_bonus
    return score