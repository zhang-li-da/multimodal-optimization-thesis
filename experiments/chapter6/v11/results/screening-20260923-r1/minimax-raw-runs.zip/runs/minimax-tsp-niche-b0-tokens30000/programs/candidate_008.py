def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    eps = 1e-9
    safe_r = r if r > 0.0 else eps
    tanh_r = (exp(safe_r) - exp(-safe_r)) / (exp(safe_r) + exp(-safe_r) + eps)
    safe_mr = mr if mr > 0.0 else eps
    rg_term = rg / safe_mr
    nr_term = nr / safe_mr
    cd_term = cd * cd
    pr_step = pr * nr_term
    cap_r = min(safe_r, 2.0)
    quad_r = cap_r * cap_r
    score = -d + 0.10 * tanh_r + 0.25 * rg_term - 0.12 * cd_term + 0.05 * pr_step + 0.005 * quad_r
    return score