def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    return -d + 0.20 * r - 0.10 * c
