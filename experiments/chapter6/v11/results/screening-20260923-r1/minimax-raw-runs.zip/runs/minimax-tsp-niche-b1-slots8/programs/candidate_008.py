def priority(f):
    d = f["distance"]
    g = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    s = f["spread"]
    inv_d = 1.0 / (d + 1e-9)
    inv_n = 1.0 / (n + 1e-9)
    inv_m = 1.0 / (m + 1e-9)
    inv_s = 1.0 / (s + 1e-9)
    sp = sqrt(c)
    lp = log1p(p)
    early = 1.0 - p
    score = -d + (0.05 + 0.20 * p) * r + 0.30 * g + 0.05 * p + 0.10 * sp
    score = score + 0.15 * early * (inv_n - inv_m)
    score = score + 0.10 * early * inv_s
    score = score + 0.05 * lp * inv_d
    return score
