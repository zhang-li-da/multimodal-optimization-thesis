def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_nr = nr + 1e-9
    norm_r = r / safe_nr
    norm_sp = sp / safe_nr
    sq_cd = (cd + 1e-9) ** 0.5
    a = -d
    b = 0.15 * (1.0 - p) * norm_r
    c = (0.05 + 0.20 * p) * rd
    e = 0.12 * sq_cd
    g = 0.05 * p * norm_r
    penalty = 0.02 * norm_sp * p
    return a + b + c + e + g - penalty
