def priority(f):
    d=f["distance"]
    rd=f["return_distance"]
    r=f["regret"]
    p=f["progress"]
    cd=f["cluster_density"]
    return -d+0.15*(1.0-p)*r+(0.05+0.20*p)*rd+0.10*(cd/(1.0+cd))