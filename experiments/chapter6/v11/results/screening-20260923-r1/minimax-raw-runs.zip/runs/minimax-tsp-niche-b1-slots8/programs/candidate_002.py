def priority(f):
    return -f["distance"] + 0.3 * f["regret"]
