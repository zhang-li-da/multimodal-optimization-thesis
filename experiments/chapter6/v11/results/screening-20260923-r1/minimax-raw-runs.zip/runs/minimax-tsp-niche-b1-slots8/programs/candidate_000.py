def priority(f):
    return -f["distance"]
