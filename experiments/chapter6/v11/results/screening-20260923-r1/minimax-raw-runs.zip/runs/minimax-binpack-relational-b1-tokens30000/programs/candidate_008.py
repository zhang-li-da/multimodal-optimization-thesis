def priority(f):
    alpha = 0.08
    std = f["std_gap"]
    mean = f["mean_gap"]
    diff = f["gap"] - mean
    var = std * std + 1e-6
    g = abs(diff)
    gauss = -((g * g) / (2.0 * var))
    if gauss < -50.0:
        gauss = -50.0
    term = alpha * exp(gauss)
    score = -f["gap"] + 0.5 * f["fill"] + term - 0.02 * f["position"]
    return score
