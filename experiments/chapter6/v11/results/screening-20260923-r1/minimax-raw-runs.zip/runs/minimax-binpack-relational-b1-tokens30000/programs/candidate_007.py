def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fill = f['fill']
    position = f['position']
    sg = std_gap + 1e-6
    dg = gap - mean_gap
    balance = -(dg * dg) / (2.0 * sg * sg)
    tightness = -(gap - 0.5 * item) * (gap - 0.5 * item)
    pos = 1.0 - position
    pos = max(0.0, min(1.0, pos))
    score = balance - 0.2 * tightness + 0.1 * fill - 0.04 * (1.0 - pos)
    mg_term = min_gap - gap
    score = score + 0.01 * mg_term
    return score