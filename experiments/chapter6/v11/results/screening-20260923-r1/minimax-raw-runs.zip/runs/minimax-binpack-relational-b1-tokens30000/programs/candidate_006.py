def priority(f):
    g = f["gap"]
    m = f["mean_gap"]
    s = f["std_gap"] + 1e-6
    d = g - m
    return -(d * d) / (2.0 * s * s) + 0.15 * f["fill"] - 0.05 * f["position"]