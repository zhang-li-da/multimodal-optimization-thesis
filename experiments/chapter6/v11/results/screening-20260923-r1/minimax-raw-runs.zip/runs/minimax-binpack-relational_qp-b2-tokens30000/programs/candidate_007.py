def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-9
    target = min(item, 0.5 * mean_gap + 0.5 * item)
    if target < eps:
        target = eps
    dev = (gap - target) * (gap - target) / target
    loose = max(gap - mean_gap, 0.0)
    tight = max(item - gap, 0.0)
    if loose < 0.0:
        loose = 0.0
    if tight < 0.0:
        tight = 0.0
    inv_frac = 1.0 - fraction_fitting
    if inv_frac < 0.0:
        inv_frac = 0.0
    score = dev + 0.25 * loose + 0.15 * tight + 0.05 * std_gap + 0.02 * inv_frac + 1e-06 * position
    return -score
