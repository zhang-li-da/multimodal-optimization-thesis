def priority(f):
    p = f["progress"]
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    cd = f["cluster_density"]
    sp = f["spread"]
    early = (1.0 - p) * (1.0 - p)
    late = p * p
    nr_n = nr / (mr + 1e-9)
    rg_n = rg / (mr + 1e-9)
    sp_n = sp / (mr + 1e-9)
    return -d + early * (0.20 * cd - 0.15 * rd) + late * (0.05 * nr_n - 0.05 * sp_n) + 0.10 * rg_n
