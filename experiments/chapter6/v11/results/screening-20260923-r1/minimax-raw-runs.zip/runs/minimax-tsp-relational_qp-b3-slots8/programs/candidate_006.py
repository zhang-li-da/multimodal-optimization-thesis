def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    safe_mr = mr + eps
    safe_sp = sp + eps
    t = (pr - 0.6) / (1.0 - 0.6 + eps)
    t = max(0.0, min(1.0, t))
    smooth = t * t * (3.0 - 2.0 * t)
    s = -d + 0.45 * nr + 0.30 * cd * rg - 0.20 * sp / safe_mr + smooth * 0.18 * rd - 0.15 * d / safe_mr
    return s
