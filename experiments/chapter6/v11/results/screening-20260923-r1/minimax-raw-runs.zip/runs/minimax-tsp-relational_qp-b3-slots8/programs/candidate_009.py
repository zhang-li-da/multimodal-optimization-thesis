def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    safe_mr = mr + eps
    t = (pr - 0.70) / 0.25
    t = max(0.0, min(1.0, t))
    smooth = t * t * (3.0 - 2.0 * t)
    return -0.85 * d + 0.40 * cd * rg - 0.10 * nr / safe_mr + 0.06 / (1.0 + sp / safe_mr) + smooth * 0.22 * rd
