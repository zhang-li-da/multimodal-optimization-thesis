def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    rg = f["regret"]
    p = f["progress"]
    return -d + 0.15 * r + 0.2 * (1.0 - p) * rg
