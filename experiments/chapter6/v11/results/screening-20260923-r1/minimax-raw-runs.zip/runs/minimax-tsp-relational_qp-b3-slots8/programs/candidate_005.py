def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr + 1e-9
    safe_sp = sp + 1e-9
    base = -0.85 * d
    density_regret = 0.35 * cd * rg
    cluster_focus = -0.05 * nr / safe_mr
    spread_bias = -0.02 * sp / safe_sp
    late_return = (0.10 if pr > 0.75 else 0.0) * rd
    norm_d = d / safe_mr
    moderate_greedy = -0.25 * norm_d
    return base + density_regret + cluster_focus + spread_bias + late_return + moderate_greedy
