def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    fit_score = -abs(gap - mean_gap) / (std_gap + 1e-9)
    scarcity_bonus = (1.0 - fraction_fitting)
    pos_bonus = position
    tight_penalty = gap / (remaining + 1e-9)
    priority_value = 100.0 * fit_score + 5.0 * scarcity_bonus + 1.0 * pos_bonus - 2.0 * tight_penalty
    return priority_value