def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    tight_pen = ((gap - 0.2 * item) * (gap - 0.2 * item)) / (0.5 + std_gap + 1e-9)
    scarcity = 1.2 * (1.0 - fraction_fitting)
    fill_term = 0.25 * fill * fill
    pos_term = 0.15 * position
    spread_term = 0.3 * (gap - min_gap) / (mean_gap + 1e-9)
    exact_bonus = 100.0 if gap < 1e-9 else 0.0
    return -tight_pen + scarcity + fill_term - pos_term - spread_term + exact_bonus
