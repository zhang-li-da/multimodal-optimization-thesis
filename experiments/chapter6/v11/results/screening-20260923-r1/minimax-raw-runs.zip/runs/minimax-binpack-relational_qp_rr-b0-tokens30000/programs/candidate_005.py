def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    base = -abs(gap - item * 0.25) / (item + 1e-9)
    exact = 100.0 if gap < 1e-9 else 0.0
    scarcity = -0.5 * fraction_fitting
    fill_term = 0.2 * (1.0 - fill)
    std_term = -0.1 * std_gap / (mean_gap + 1e-9)
    pos_term = -0.05 * position
    return base + exact + scarcity + fill_term + std_term + pos_term