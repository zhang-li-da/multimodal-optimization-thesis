def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    denom = item if item > 1e-9 else 1e-9
    pos = f["position"]
    fr = f["fraction_fitting"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    if gap < 1e-9:
        exact = 100.0
    else:
        g = gap if gap < item else item
        exact = -g / denom
    density = 1.0 - fill
    fit_bonus = 0.0
    if fr > 1e-9:
        if min_gap < 1e-9:
            fit_bonus = -1.0
        else:
            ratio = mean_gap / (min_gap + 1e-9)
            if std_gap > mean_gap:
                ratio = ratio + (std_gap - mean_gap) / (mean_gap + 1e-9)
            fit_bonus = -0.5 * (ratio - 1.0)
    position_term = -0.01 * pos
    return exact + 0.05 * density + fit_bonus + position_term
