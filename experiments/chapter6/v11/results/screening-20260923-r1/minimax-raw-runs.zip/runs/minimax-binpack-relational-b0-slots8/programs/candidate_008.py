def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-9
    scarcity = 1.0 - fraction_fitting
    if scarcity < 0.0:
        scarcity = 0.0
    scarcity2 = scarcity * scarcity
    loose = 0.25 * gap * scarcity2
    exact_bonus = 0.5 if gap == 0.0 else 0.0
    tiny_bonus = 0.05 * scarcity
    min_norm = min_gap / (1.0 + abs(min_gap) + eps)
    mean_norm = mean_gap / (1.0 + abs(mean_gap) + eps)
    std_norm = std_gap / (1.0 + abs(std_gap) + eps)
    shape = std_norm + 0.5 * (mean_norm - min_norm)
    score = -gap + loose + exact_bonus + tiny_bonus - 0.1 * shape + 0.02 * position + 0.001 * fill
    return score