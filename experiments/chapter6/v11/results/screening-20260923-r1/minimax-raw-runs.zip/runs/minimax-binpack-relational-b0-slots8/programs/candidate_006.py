def priority(f):
    item = f["item"]
    gap = f["gap"]
    ff = f["fraction_fitting"]
    sg = f["std_gap"]
    pos = f["position"]
    tight = gap * (1.0 + 2.0 * (1.0 - ff) ** 2)
    loose = -0.5 * gap * ff ** 2
    over = max(0.0, item - 2.0 * gap)
    penalty = -4.0 * over * over / (item * item + 1.0)
    std_term = 0.05 * sg * ff
    pos_term = 0.001 * pos
    return -tight + loose + penalty + std_term + pos_term
