def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-9
    scarcity = 1.0 - fraction_fitting
    if scarcity < 0.0:
        scarcity = 0.0
    scarcity2 = scarcity * scarcity
    loose = 0.25 * gap * scarcity2
    exact_bonus = 0.5 if gap == 0.0 else 0.0
    tiny_bonus = 0.05 * scarcity
    item_safe = abs(item) + eps
    trap_thresh = item / 3.0
    trap = trap_thresh - gap
    if trap < 0.0:
        trap = 0.0
    trap_penalty = -4.0 * trap * trap / (item_safe * item_safe)
    mean_term = (mean_gap - gap) * (1.0 - scarcity) * 0.05
    std_term = -0.1 * std_gap * fraction_fitting
    score = -gap + loose + exact_bonus + tiny_bonus + trap_penalty + mean_term + std_term + 0.02 * position + 0.001 * fill
    return score