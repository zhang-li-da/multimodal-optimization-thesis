def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    alpha = 1.5
    beta = 0.3
    gamma = 0.2
    delta = 0.001
    small = eps
    ff_clamped = min(max(fraction_fitting, 0.0), 1.0)
    score = -gap * (1.0 + alpha * (1.0 - ff_clamped)) + beta * gap * ff_clamped - gamma * abs(gap - mean_gap) / (std_gap + small) + delta * position
    return score
