def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    denom = 1e-9
    ci = max(0.0, min(1.0, item))
    ramp = ci - 0.25
    cramp = max(0.0, min(0.75, ramp))
    w_best = cramp
    w_worst = max(0.0, 1.0 - 4.0 * ci) - w_best
    score = w_best * (-gap) + w_worst * gap - 0.05 * abs(gap - mean_gap) / (std_gap + denom)
    return score