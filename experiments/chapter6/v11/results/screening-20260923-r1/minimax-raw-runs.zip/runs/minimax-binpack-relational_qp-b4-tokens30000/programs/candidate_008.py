def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    denom = 1e-9
    ci = max(0.0, min(1.0, item))
    fill = max(0.0, min(1.0, fill))
    lo = max(0.0, 0.35 - fill)
    hi = max(0.0, fill - 0.75)
    band_pen = 0.02 * lo * lo + 0.02 * hi * hi
    dev_pen = 0.03 * abs(gap - mean_gap) / (std_gap + denom)
    frac_pen = 0.05 * max(0.0, 1.0 - fraction_fitting)
    ramp = ci - 0.25
    cramp = max(0.0, min(0.75, ramp))
    w_best = cramp
    w_worst = max(0.0, 1.0 - 4.0 * ci) - w_best
    score = w_best * (-gap) + w_worst * gap - band_pen - dev_pen - frac_pen
    return score