def priority(f):
    return -f["gap"]
