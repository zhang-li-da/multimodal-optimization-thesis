def priority(f):
    return -f["position"]
