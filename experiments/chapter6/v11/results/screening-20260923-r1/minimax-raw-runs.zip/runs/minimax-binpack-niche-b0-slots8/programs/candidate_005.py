def priority(f):
    item = f['item']
    gap = f['gap']
    fill = f['fill']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    score = -gap
    score = score + (-2.0 if gap < 1e-9 else 0.0)
    score = score - 0.05 * (gap / (item + 1e-9))
    score = score - 0.05 * position
    score = score + 0.1 * fraction_fitting
    score = score + 0.1 * fill
    return score
