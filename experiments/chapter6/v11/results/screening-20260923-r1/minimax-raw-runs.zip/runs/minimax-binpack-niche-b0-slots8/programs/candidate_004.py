def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    score = -gap
    score = score + (-1.0 if gap < 1e-9 else 0.0)
    score = score - 0.1 * position
    score = score + 0.2 * fill
    diff = gap - min_gap
    score = score - 0.05 * diff * fraction_fitting
    return score
