def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    mx = max(gap, eps)
    score = -gap
    score = score + (-1.0 if gap < eps else 0.0)
    score = score + 0.3 * fill
    diff = gap - mean_gap
    score = score - 0.4 * (diff / mx if diff >= 0 else -diff / mx)
    score = score - 0.1 * position
    return score
