def priority(f):
    gap = f['gap']
    fill = f['fill']
    position = f['position']
    score = -gap
    score = score + (2.0 if gap < 1e-9 else 0.0)
    score = score + 0.5 * max(0.0, fill - 0.9)
    score = score - 0.1 * max(0.0, 0.05 - gap)
    score = score - 0.1 * position
    return score
