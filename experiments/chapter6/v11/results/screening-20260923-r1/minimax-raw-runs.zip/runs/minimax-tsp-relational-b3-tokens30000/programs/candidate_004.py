def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    p = f["progress"]
    c = f["cluster_density"]
    g = f["regret"]
    return -d + 0.30 * c + 0.25 * g - 0.20 * (1.0 - p) * r