def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    s = f["spread"]
    g = f["regret"]
    p = f["progress"]
    one_minus_p = 1.0 - p
    sig = 1.0 / (1.0 + (1.0 + 2.0 * (p - 0.5) + 2.0 * (p - 0.5) ** 2 * 0.5 + (p - 0.5) ** 4 / 6.0))
    density_bonus = sig * c
    return -d + 0.30 * g + 0.30 * density_bonus - 0.20 * one_minus_p * r - 0.08 * s
