def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    s = f["spread"]
    g = f["regret"]
    p = f["progress"]
    one_minus_p = 1.0 - p
    return -d + 0.35 * c - 0.15 * s + 0.25 * g - 0.25 * one_minus_p * r