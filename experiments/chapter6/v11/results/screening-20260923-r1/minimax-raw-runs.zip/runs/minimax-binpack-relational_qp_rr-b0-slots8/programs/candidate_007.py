def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    ff = min(max(fraction_fitting, 0.0), 1.0)
    inv_ff = 1.0 - ff
    loose_gate = max(0.0, 0.5 - ff)
    tight_gate = max(0.0, ff - 0.5)
    diff = gap - min_gap
    ratio_term = diff / max(gap, 1e-3)
    ratio_term = min(max(ratio_term, 0.0), 10.0)
    penalty = log1p(ratio_term)
    score = (-gap * (1.0 + 0.5 * inv_ff)
             + 0.5 * gap * tight_gate
             - 0.3 * penalty
             + 0.15 * item * loose_gate
             - 0.05 * position)
    return score