def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    item = f["item"]
    position = f["position"]
    fill = f["fill"]
    remaining = f["remaining"]
    safe_std = std_gap if std_gap > 0.001 else 0.001
    safe_frac = fraction_fitting if fraction_fitting > -0.999 else -0.999
    frac_clamped = safe_frac if safe_frac < 1.999 else 1.999
    tight_w = 1.0 - frac_clamped
    loose_w = 0.5 * frac_clamped
    deviation = abs(gap - mean_gap) / safe_std
    log_dev = log1p(deviation)
    inv_min = -0.1 / (1.0 + min_gap)
    item_term = 0.2 * item * (0.5 + 0.5 * frac_clamped)
    pos_term = -0.05 * position
    rem_term = 0.1 * remaining * frac_clamped
    fill_term = -0.1 * fill * (1.0 - frac_clamped)
    w_sum = tight_w + loose_w
    if w_sum < 0.01:
        w_sum = 0.01
    norm_gap = (tight_w * (-gap) + loose_w * gap) / w_sum
    score = norm_gap - 0.25 * log_dev + inv_min + item_term + pos_term + rem_term + fill_term
    return score