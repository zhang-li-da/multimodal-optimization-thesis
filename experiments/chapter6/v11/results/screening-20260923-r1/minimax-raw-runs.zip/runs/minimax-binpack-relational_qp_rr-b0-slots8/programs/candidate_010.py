def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    safe_std = std_gap if std_gap > 0.001 else 0.001
    safe_frac = fraction_fitting if fraction_fitting > 0.0 else 0.0
    frac_clamped = safe_frac if safe_frac < 1.0 else 1.0
    deviation = abs(gap - mean_gap) / safe_std
    awkward = 0.0
    if gap > min_gap:
        awkward = 0.15 * (gap - min_gap) * frac_clamped
    outlier = 0.0
    if deviation > 1.0:
        outlier = 0.10 * (deviation - 1.0) * frac_clamped
    pos_term = -0.05 * position
    score = -gap - awkward - outlier + pos_term
    return score