def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    safe_std = std_gap if std_gap > 0.001 else 0.001
    safe_frac = fraction_fitting if fraction_fitting > 0.0 else 0.0
    frac_clamped = safe_frac if safe_frac < 1.0 else 1.0
    deviation = abs(gap - mean_gap) / safe_std
    penalty = 0.20 * deviation * frac_clamped
    spread = 0.05 * (gap - min_gap) if gap > min_gap else 0.0
    pos_term = -0.05 * position
    score = -gap - penalty + spread + pos_term
    return score