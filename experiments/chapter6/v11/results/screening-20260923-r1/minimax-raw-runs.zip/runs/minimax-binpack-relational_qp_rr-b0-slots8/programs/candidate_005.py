def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    min_gap = f["min_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    s = max(std_gap, 1e-3)
    return -gap + 0.5 * item - abs(gap - mean_gap) / s - 0.25 * min_gap + 0.1 * fraction_fitting - 0.05 * position
