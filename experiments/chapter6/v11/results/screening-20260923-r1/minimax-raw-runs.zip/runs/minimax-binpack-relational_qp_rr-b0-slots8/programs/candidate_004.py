def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fill = f['fill']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    denom_remain = max(1.0 - remaining, 1e-9)
    denom_gap = max(abs(gap), 1e-9)
    log_fraction = log(max(fraction_fitting, 1e-9))
    dev = (gap - mean_gap) / max(abs(mean_gap), 1e-9)
    std_term = std_gap / denom_gap
    spread = -dev - 0.5 * std_term
    tightness = -gap / denom_remain
    item_weight = item * gap
    pos_penalty = -position
    frac_term = -log_fraction * gap
    score = spread + tightness + 0.5 * item_weight + 0.25 * frac_term + 0.1 * pos_penalty
    return score