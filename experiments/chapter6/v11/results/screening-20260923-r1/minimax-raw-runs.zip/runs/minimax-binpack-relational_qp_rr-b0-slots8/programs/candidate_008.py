def priority(f):
    eps = 0.001
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom = std_gap + eps
    deviation = abs(gap - mean_gap) / denom
    suppress = 1.0 - fraction_fitting
    score = -gap - 0.3 * deviation * suppress - 0.1 * fill + 0.05 * min_gap - 0.05 * position
    return score
