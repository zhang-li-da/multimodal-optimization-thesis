def priority(f):
    g = f["gap"]
    m = f["mean_gap"]
    s = f["std_gap"]
    lo = f["min_gap"]
    r = f["remaining"]
    frac = f["fraction_fitting"]
    pos = f["position"]
    fill = f["fill"]
    eps = 1e-9
    tightness = 1.0 / (lo + eps)
    balance = -abs(g - m)
    variance_pen = -0.3 * s
    slack_pen = -0.5 * g
    fill_bonus = 0.1 * (1.0 if g < 1e-6 else 0.0)
    remaining_pen = -0.2 * r
    fill_aff = 0.05 * fill
    frac_aff = 0.05 * frac
    pos_tie = -0.001 * pos
    return (balance + variance_pen + slack_pen + fill_bonus
            + remaining_pen + fill_aff + frac_aff + pos_tie
            + 0.001 * tightness)
