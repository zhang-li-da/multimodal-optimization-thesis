def priority(f):
    gap = f['gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    fill = f['fill']
    remaining = f['remaining']
    item = f['item']
    mean_gap = f['mean_gap']
    score = -gap + 0.5 * (gap - min_gap) - 0.25 * std_gap
    if abs(fill - 1.0) < 1e-9:
        score = score + 1.0
    score = score - 0.1 * position
    score = score - 0.05 * mean_gap
    return score