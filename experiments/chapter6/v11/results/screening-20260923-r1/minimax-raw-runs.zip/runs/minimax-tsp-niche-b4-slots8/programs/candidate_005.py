def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    rg = f["regret"]
    return -d + 0.15 * rd + 0.18 * rg