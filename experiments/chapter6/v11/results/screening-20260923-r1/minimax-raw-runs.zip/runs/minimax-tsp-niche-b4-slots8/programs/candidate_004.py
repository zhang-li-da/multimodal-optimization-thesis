def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    rg = f["regret"]
    return -d + 0.25 * rd + 0.10 * rg