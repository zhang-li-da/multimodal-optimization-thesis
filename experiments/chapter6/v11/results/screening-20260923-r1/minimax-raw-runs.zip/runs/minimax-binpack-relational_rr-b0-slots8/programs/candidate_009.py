def priority(f):
    gap = f["gap"]
    item = f["item"]
    std_gap = f["std_gap"]
    position = f["position"]
    g = gap + 1e-9
    tight = max(0, 0.15 - gap) * g
    loose = max(0, gap - 0.35) * g
    sweet = exp(-((gap - 0.25) ** 2) / (2 * 0.08 ** 2)) * gap
    return -gap - 0.30 * tight - 0.20 * loose + 0.08 * sweet - 0.05 * std_gap / g - 0.02 * item * g + 1e-6 * position
