def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    one = 1.0
    ep = 1e-9
    mp = one - p
    early = 0.40 * cd * exp(-2.0 * p)
    sp_p = log1p(exp(3.0 * p - 1.5))
    mid = 0.20 * log(one + max(nr, 0.0))
    rg_term = 0.15 * rg / (one + mr + ep)
    late = 0.35 * rd * sp_p
    close = 0.10 * rd * mp
    sp_pen = -0.05 * sp
    return -d + early + late + mid + rg_term + close + sp_pen
