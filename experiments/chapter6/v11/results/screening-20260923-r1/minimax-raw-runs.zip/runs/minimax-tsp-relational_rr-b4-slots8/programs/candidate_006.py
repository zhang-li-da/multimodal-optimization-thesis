def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    one = 1.0
    ep = 1e-9
    earg = -2.0 * p
    eg = exp(earg)
    arg = 3.0 * p - 1.5
    sp_max = 20.0
    arg_c = min(arg, sp_max)
    arg_f = max(arg_c, -sp_max)
    soft = log(one + exp(arg_f))
    log_term = log(one + max(nr, 0.0))
    inv_mr = one / (one + mr + ep)
    reg_b = 0.15 * rg * inv_mr
    score = -d + 0.40 * cd * eg + 0.35 * rd * soft + 0.20 * log_term + reg_b - 0.05 * sp
    return score