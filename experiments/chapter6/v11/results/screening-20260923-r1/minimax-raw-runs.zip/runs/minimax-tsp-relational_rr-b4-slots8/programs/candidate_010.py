def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    rg = f["regret"]
    nr_s = max(nr, 1e-9)
    return -d + 0.25 * rd + 0.30 * cd * (1.0 - p) + 0.10 * log(1.0 + nr_s) - 0.05 * sp + 0.20 * rg / (1.0 + nr_s)
