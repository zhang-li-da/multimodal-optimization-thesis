def priority(f):
    g = f['gap']
    mg = f['mean_gap']
    mn = f['min_gap']
    return -g - 2.0 * abs(g - mg) + 0.5 * (g - mn)
