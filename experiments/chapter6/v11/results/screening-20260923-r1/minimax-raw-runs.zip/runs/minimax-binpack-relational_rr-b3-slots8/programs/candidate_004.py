def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    diff = gap - mean_gap
    eps = 1e-9
    zsq = (diff * diff) / (std_gap + eps)
    spread = (min_gap - gap)
    score = zsq + 0.5 * diff - 0.3 * fill + 0.1 * spread
    penalty = score * score
    return -score - 0.05 * penalty
