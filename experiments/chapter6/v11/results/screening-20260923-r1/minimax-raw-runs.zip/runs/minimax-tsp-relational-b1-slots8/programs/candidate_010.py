def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    s = f["spread"]
    inv = 1.0 - p
    return -d + (0.20 + 0.55 * inv * inv) * r + (0.10 + 0.45 * p) * g - 0.04 * s
