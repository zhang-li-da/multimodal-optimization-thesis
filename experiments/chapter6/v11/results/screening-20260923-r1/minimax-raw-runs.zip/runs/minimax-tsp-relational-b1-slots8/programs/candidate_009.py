def priority(f):
    d = f['distance']
    g = f['regret']
    p = f['progress']
    c = f['cluster_density']
    s = f['spread']
    w = 0.20 + 0.45 * p / (1.0 + 0.5 * p)
    score = -d + w * g + 0.10 * c - 0.03 * s
    return score