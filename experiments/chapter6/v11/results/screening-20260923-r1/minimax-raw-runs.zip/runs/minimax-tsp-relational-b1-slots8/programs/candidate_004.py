def priority(f):
    e = 1e-9
    p = f["progress"]
    decay = 1.0 - p
    return -f["distance"] + 0.30 * f["regret"] + decay * 0.20 * f["return_distance"] + 0.40 * f["cluster_density"] - 0.20 * f["spread"]
