def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    w = 1.0 / (1.0 + 3.0 * pr)
    return -d + w * 0.30 * rd + (1.0 - w) * (0.40 * rg - 0.08 * nr) - 0.05 * (1.0 - cd) * rd
