def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    return -d + 0.30 * g + (1.0 - p) * 0.20 * r
