def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    return -d + (1 - p) * 0.30 * r + p * (0.35 * g - 0.10 * n) - 0.05 * (1 - c) * r
