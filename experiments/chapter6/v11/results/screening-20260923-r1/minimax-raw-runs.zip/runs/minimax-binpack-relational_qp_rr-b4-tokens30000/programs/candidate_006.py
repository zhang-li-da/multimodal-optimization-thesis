def priority(f):
    item = f['item']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    remaining = f['remaining']
    eps = 1e-9
    safe_item = item if item > eps else eps
    safe_gap = gap if gap > eps else eps
    inv_item = 1.0 / safe_item
    base = gap * gap * inv_item
    exact_bonus = 2.0 if gap < eps else 0.0
    fit_penalty = 0.3 * fill
    crowd_penalty = 0.15 * (1.0 - fraction_fitting)
    pos_penalty = 0.05 * position
    denom = max(abs(min_gap), eps)
    balance_penalty = 0.1 * ((mean_gap - gap) / denom + std_gap)
    score = base - exact_bonus + fit_penalty + crowd_penalty + pos_penalty + balance_penalty
    return score