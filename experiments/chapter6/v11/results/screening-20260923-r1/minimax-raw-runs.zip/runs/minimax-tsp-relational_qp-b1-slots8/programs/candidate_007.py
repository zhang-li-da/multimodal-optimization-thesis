def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    reg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    safe_m = m + 1e-9
    return (-1.0 * d + 0.35 * c - 0.15 * s - 0.25 * n + 0.15 * p + 0.45 * p * r - 0.10 * (1.0 - p) * reg) / (1.0 + 0.1 * safe_m)
