def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    denom = 1e-9
    safe_d = d / (mr + denom) if (mr + denom) > 0 else d
    log_rg = rg / (1.0 + rg) if (1.0 + rg) > 0 else 0.0
    return -1.0 * d + 0.20 * rg + 0.25 * cd - 0.15 * sp - 0.05 * nr + (0.10 + 0.30 * p) * r + 0.05 * safe_d + 0.02 * log_rg