def priority(f):
    d = f["distance"]
    r = f["regret"]
    rb = f["return_distance"]
    n = f["nearest_remaining"]
    return -d + 0.35 * r + 0.20 * rb - 0.10 * n
