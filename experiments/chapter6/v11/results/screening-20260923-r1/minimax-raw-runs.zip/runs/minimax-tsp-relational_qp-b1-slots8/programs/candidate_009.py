def priority(f):
    d = f["distance"]
    r = f["regret"]
    rb = f["return_distance"]
    n = f["nearest_remaining"]
    c = f["cluster_density"]
    s = f["spread"]
    p = f["progress"]
    return -1.0 * d + 0.45 * r + 0.25 * c - 0.20 * s - 0.10 * n + 0.30 * p * rb