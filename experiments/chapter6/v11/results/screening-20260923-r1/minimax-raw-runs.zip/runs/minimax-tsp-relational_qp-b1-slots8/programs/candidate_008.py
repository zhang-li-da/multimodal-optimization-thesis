def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    reg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    ep = 1e-9
    return (-1.0 * d - 0.40 * log1p(2.0 * n) + 0.30 * c - 0.10 * s + 0.10 * reg + (0.20 + 0.50 * p) * log1p(max(r, 0.0)) - 0.05 * p * s - 0.10 * p * reg - 0.05 * p * (m / (m + ep)))
