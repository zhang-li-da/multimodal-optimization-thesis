def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    eps = 1e-9
    safe_n = max(abs(n), eps)
    safe_m = max(abs(m), eps)
    safe_s = max(abs(s), eps)
    rel_d = d / safe_n
    inv_d = -rel_d
    return_w = 0.35 * r / safe_n
    regret_w = 0.15 * rg / safe_n
    progress_term = 0.10 * p * c
    mean_term = 0.08 * m / safe_n
    spread_term = -0.04 * s / safe_n
    score = inv_d + return_w + regret_w + progress_term + mean_term + spread_term
    if p > 0.4 and c > 0.4:
        score = score + 0.08 * (c - 0.4)
    return score
