def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    p = f["progress"]
    s = f["spread"]
    eps = 1e-9
    safe_n = max(abs(n), eps)
    safe_m = max(abs(m), eps)
    safe_s = max(abs(s), eps)
    rel_d = d / safe_n
    rel_r = r / safe_n
    rel_m = m / safe_m
    rel_s = s / safe_s
    return_w = (0.25 + 0.20 * p) * rel_r
    mean_term = 0.05 * rel_m
    spread_term = -0.02 * rel_s
    score = -rel_d + return_w + mean_term + spread_term
    return score
