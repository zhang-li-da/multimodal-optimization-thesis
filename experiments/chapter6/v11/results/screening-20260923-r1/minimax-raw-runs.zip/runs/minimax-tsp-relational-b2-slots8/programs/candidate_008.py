def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    eps = 1e-9
    safe_n = max(abs(n), eps)
    safe_m = max(abs(m), eps)
    safe_s = max(abs(s), eps)
    rel_d = d / safe_n
    inv_d = -rel_d
    return_w = 0.45 * r / safe_n
    regret_w = 0.25 * rg / safe_n
    progress_term = 0.15 * p * c
    mean_term = 0.1 * m / safe_n
    spread_term = -0.05 * s / safe_n
    score = inv_d + return_w + regret_w + progress_term + mean_term + spread_term
    if p > 0.5 and c > 0.5:
        score = score + 0.1 * (c - 0.5)
    return score
