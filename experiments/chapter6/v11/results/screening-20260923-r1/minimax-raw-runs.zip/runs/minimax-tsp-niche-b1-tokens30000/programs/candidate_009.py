def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    align = 1.0 / (1.0 + abs(d - nr))
    mr_term = 0.0
    if mr > 1e-9:
        mr_term = d / mr
    s_term = 0.0
    if s > 1e-9:
        s_term = 1.0 / (1.0 + s)
    score = -d + 0.18 * r + 0.18 * g + 0.10 * p * r + 0.18 * p * (c - 0.5) + 0.08 * align - 0.04 * mr_term + 0.05 * s_term
    return score