def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    return -d + 0.35 * r + 0.35 * g + 0.20 * p * r - 0.10 * (c - 0.5)