def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    return -d + 0.20 * r + 0.20 * g + 0.10 * p * r + 0.15 * p * (c - 0.5)