def priority(f):
    d = f['distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    rd = f['return_distance']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    safe_mr = mr + 1e-9
    safe_sp = sp + 1e-9
    penalty = abs(pr - 0.5)
    alignment = 1.0 / (1.0 + abs(cd - 0.5))
    look = 1.0 / (1.0 + abs(nr - d))
    score = -d - 0.35 * nr + 0.20 * rg - 0.15 * pr * rd + 0.20 * pr * (cd - 0.5) + 0.10 * look + 0.10 * alignment - 0.10 * penalty * (mr - d) / safe_mr - 0.05 * sp / safe_sp
    return score
