def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    pr = p * r
    pc = p * (c - 0.5)
    align = 1.0 / (1.0 + abs(d - nr))
    return -d + 0.25 * r + 0.25 * g + 0.20 * pr + 0.15 * pc + 0.10 * align