def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    cd = f['cluster_density']
    sp = f['spread']
    pr = f['progress']
    safe_mr = mr + 1e-9
    norm_d = d / safe_mr
    return_pen = rd / safe_mr
    density_term = 0.20 * cd * (1.0 - pr)
    progress_term = 0.30 * return_pen * (0.2 + pr)
    lookahead = 0.55 * nr * (1.0 - 0.4 * sp / (sp + safe_mr))
    regret_term = 0.10 * rg / safe_mr
    final = -norm_d - lookahead + progress_term + density_term + regret_term
    if pr > 0.65:
        final = final - 0.35 * return_pen
    if cd > 0.55:
        final = final + 0.08 * log(abs(nr) + 1.0)
    return final