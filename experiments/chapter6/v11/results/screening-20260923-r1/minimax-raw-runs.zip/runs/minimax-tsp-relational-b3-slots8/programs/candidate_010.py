def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    denom_r = 1e-9 + mr
    denom_nr = 1e-9 + nr
    score = -1.0 * d
    score = score + (0.10 + 0.20 * pr) * r
    score = score + (0.15 + 0.35 * pr) * cd
    score = score + 0.10 * rg * (1.0 - cd)
    score = score - 0.05 * sp
    score = score + 0.05 * (d / denom_nr)
    score = score + 0.05 * pr * (r / denom_r)
    return score