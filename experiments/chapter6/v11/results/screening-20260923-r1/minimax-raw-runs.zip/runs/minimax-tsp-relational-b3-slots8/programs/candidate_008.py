def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    pr = max(0.0, min(1.0, pr))
    cd = max(0.0, min(1.0, cd))
    cd_p = cd * cd * cd
    cd_p = max(0.0, min(1.0, cd_p))
    rg = max(0.0, rg)
    sp = max(0.0, sp)
    r_w = 0.30 - 0.25 * pr
    nr_s = nr / (mr + 1e-9)
    nr_t = nr_s / (1.0 + nr_s)
    score = -1.0 * d + r_w * r + 0.35 * cd_p + 0.10 * rg * rg * (1.0 - cd) - 0.05 * sp + 0.05 * pr * nr_t
    return score
