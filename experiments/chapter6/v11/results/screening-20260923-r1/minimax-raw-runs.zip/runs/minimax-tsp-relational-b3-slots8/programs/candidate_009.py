def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    score = -1.0 * d
    score = score + (0.30 - 0.20 * pr) * r
    score = score + (0.05 + 0.30 * pr) * cd
    score = score + 0.10 * rg
    score = score - 0.05 * sp
    score = score + 0.05 * pr * (nr / (mr + 1e-9))
    return score