def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    return -1.0 * d + 0.45 * r + 0.08 * nr + 0.03 * rg + 0.15 * cd - 0.05 * sp - 0.02 * mr + 0.02 * p
