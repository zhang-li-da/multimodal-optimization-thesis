def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    return_term = (0.05 + 0.25 * (1 - pr)) * r
    nr_term = 0.05 * pr * (nr / (1e-9 + mr))
    score = -1.0 * d + return_term + 0.35 * cd + 0.10 * rg + nr_term - 0.05 * sp
    return score