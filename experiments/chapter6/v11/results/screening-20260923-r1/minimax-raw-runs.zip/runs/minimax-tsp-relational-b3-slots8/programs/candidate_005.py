def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    score = -1.0 * d + 0.20 * r + 0.40 * cd + 0.10 * rg - 0.05 * sp
    denom = 1e-9 + nr
    score = score + 0.05 * (d / denom)
    score = score + 0.05 * pr * (r / (1e-9 + mr))
    return score