def priority(f):
    item = f["item"]
    gap = f["gap"]
    min_gap = f["min_gap"]
    position = f["position"]
    eps = 1e-9
    score = -gap + 0.10 * ((gap - min_gap) if (gap - min_gap) > 0 else 0) / (item + eps)
    score = score + (0.25 if gap < eps else 0) - 0.03 * position
    return score