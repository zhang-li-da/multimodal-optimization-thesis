def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    position = f["position"]
    eps = 1e-9
    score = -gap + 0.20 * (gap - min_gap) - 0.15 * (1.0 - mean_gap)
    if gap < eps:
        score = score + 0.25
    score = score - 0.03 * position
    return score
