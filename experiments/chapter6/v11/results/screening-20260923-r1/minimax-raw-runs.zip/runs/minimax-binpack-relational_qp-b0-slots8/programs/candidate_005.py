def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    eps = 1e-9
    safe_item = item + eps
    safe_mean = mean_gap + eps
    primary = - (gap / safe_item)
    above = (gap - mean_gap) / safe_mean
    adjust = (0 - 0.05) * (above if above > 0 else 0)
    frac_term = 0.1 * (1 - fraction_fitting)
    pos_term = (- 0.1) * position
    score = primary + adjust + frac_term + pos_term
    return score