def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fill = f['fill']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    denom = remaining + item + 1e-9
    main = -(gap * gap) / denom
    exact_bonus = 0.1 if gap < 1e-9 else 0.0
    gap_spread = 0.1 * (gap - min_gap)
    fill_pen = 0.05 * fill
    pos_pen = 0.01 * position
    frac_pen = 0.02 * (1.0 - fraction_fitting)
    std_pen = 0.001 * std_gap
    return main + exact_bonus + gap_spread - fill_pen - pos_pen - frac_pen - std_pen