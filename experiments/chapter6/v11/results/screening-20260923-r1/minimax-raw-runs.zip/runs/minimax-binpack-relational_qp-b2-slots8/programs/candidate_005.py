def priority(f):
    item = f["item"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    item_factor = 1.0 / (1.0 + 9.0 * item)
    tight_pen = (gap - min_gap) / (gap + std_gap + 1e-9)
    base = gap + 0.5 * item * gap
    adjust = 0.05 * fill + 0.1 * tight_pen + 0.2 * mean_gap * item_factor - 0.02 * fraction_fitting - 0.001 * position
    return -(base - adjust)
