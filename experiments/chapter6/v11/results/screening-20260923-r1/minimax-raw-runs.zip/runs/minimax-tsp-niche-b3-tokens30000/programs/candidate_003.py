def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    return -d + 0.15 * r + 0.15 * g