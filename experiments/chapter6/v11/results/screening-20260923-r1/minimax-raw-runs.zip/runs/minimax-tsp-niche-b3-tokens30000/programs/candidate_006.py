def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    w_rg = 0.25 + 0.45 * pr
    w_rd = 0.20 - 0.15 * pr
    term1 = -0.85 * d
    term2 = w_rg * rg
    term3 = -w_rd * rd
    term4 = 0.20 * cd
    term5 = -0.10 * sp
    p = term1 + term2 + term3 + term4 + term5
    return p
