def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    return -0.85 * d + (0.20 + 0.25 * pr) * rg - (0.25 - 0.15 * pr) * rd + 0.15 * cd - 0.05 * sp