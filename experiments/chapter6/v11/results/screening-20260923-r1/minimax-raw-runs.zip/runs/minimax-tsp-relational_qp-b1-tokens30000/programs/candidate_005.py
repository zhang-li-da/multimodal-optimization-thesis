def priority(f):
    d = f['distance']
    r = f['return_distance']
    c = f['cluster_density']
    s = f['spread']
    rg = f['regret']
    return -d + 0.25 * r + 0.15 * c - 0.05 * s + 0.10 * rg