def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    guard = 1.0 / (1.0 + 1e-9)
    base = -d + 0.2 * rd + 0.25 * rg - 0.05 * sp
    if base > 0:
        base = base * (1.0 + 0.1 * pr)
    else:
        base = base * (1.0 + 0.1 * pr)
    if cd > 0.5:
        base = base + 0.05 * (cd - 0.5)
    mr_safe = mr + eps
    nr_safe = nr + eps
    ratio = nr / mr_safe
    if ratio < 1.0:
        base = base + 0.02 * (1.0 - ratio)
    else:
        base = base - 0.02 * (ratio - 1.0)
    base = base * guard
    return base
