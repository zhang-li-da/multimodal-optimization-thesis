def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    guard = 1.0 / (1.0 + 1e-9)
    base = -d + 0.15 * rd + 0.15 * rg - 0.10 * sp
    base = base * (1.0 + 0.05 * pr)
    mr_safe = mr + eps
    nr_safe = nr + eps
    diff_pos = nr_safe - mr_safe
    if diff_pos < 0.0:
        base = base + 0.03 * (-diff_pos) / mr_safe
    else:
        base = base - 0.02 * diff_pos / mr_safe
    cd_center = cd - 0.5
    if cd_center > 0.0:
        base = base + 0.04 * cd_center
    base = base * guard
    return base
