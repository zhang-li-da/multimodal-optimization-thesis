def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    sp = f["spread"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    inv_spread = 1.0 / (1.0 + 9.0 * sp)
    base = -2.0 * d
    bonus = 0.35 * r + 0.15 * cd + 0.05 * nr
    penalty = 0.10 * mr + 0.05 * sp + 0.05 * d * sp
    score = base + bonus - penalty
    score = score + 0.10 * inv_spread
    return score
