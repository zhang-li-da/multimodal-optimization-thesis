def priority(f):
    eps = 1e-9
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    frac = f["fraction_fitting"]
    pos = f["position"]
    dev = gap - mean_gap
    base = -gap
    cluster = std_gap / (mean_gap + eps)
    gate = cluster if cluster < 1.0 else 1.0
    quad = 0.20 * (dev * dev) / (std_gap + eps) * gate
    loose = 0.15 * gap * frac
    pos_term = 0.10 * pos
    item_term = -0.05 * abs(gap - 0.5 * item)
    return base + quad + loose + pos_term + item_term
