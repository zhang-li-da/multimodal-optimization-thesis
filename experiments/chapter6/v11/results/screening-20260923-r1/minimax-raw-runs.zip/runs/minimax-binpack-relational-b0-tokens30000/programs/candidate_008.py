def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    min_gap = f['min_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    eps = 1e-9
    tightness = -gap
    cluster = std_gap / (mean_gap + eps)
    cluster_gate = 0.25 * min(1.0, cluster)
    residual = abs(gap - item)
    return (tightness
            + cluster_gate * residual
            + 0.10 * gap * fraction_fitting
            - 0.30 * residual
            - 0.05 * position)
