def priority(f):
    d = f["distance"]
    nr = f["nearest_remaining"]
    c = f["cluster_density"]
    r = f["return_distance"]
    p = f["progress"]
    s = f["spread"]
    early = 1.0 - p
    residual = nr - d
    dense_boost = 0.30 * c * early
    return_early = 0.15 * r * early
    spread_pen = 0.05 * s
    return -d + 0.20 * residual + dense_boost + return_early - spread_pen
