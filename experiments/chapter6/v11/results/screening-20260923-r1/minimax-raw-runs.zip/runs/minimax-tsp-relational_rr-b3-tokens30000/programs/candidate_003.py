def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    early = 1.0 - p
    rmix = 0.15 * g + 0.10 * r
    rd = 0.08 * s
    cc = 0.06 * (c - 0.5)
    nd = -d
    nr_term = 0.04 * (nr - mr)
    return nr_term + rmix + rd + cc + nd
