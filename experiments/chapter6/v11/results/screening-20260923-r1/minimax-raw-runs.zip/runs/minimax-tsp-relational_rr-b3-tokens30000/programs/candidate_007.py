def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    nr_term = nr - mr
    if nr_term > 0.5: nr_term = 0.5
    if nr_term < -0.5: nr_term = -0.5
    nr_term = 0.18 * nr_term
    cg = (0.15 + 0.20 * p) * g
    cc = (0.10 + 0.18 * p) * c
    cs = -0.06 * s
    cr = -0.05 * r * (1.0 - p)
    return -d + cg + nr_term + cc + cs + cr
