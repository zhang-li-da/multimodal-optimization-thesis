def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    p = f["progress"]
    return_term = 0.25 * r * (1.0 - 0.3 * p)
    residual = 0.15 * (nr - d)
    return -d + return_term + residual
