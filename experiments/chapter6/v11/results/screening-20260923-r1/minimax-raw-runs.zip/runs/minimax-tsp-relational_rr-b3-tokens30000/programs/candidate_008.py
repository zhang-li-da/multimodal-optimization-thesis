def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    early = 1.0 - p
    dist_pen = -d
    dist_quad = 0.04 * d * d * early
    reg_term = 0.10 * g + 0.15 * p * g
    ret_term = 0.10 * r * (1.0 - 0.6 * p)
    clu_term = 0.08 * c
    diff = nr - mr
    absdiff = abs(diff)
    cap = 0.5
    clipped = cap if diff > cap else (-cap if diff < -cap else diff)
    nr_term = 0.05 * clipped
    spr_term = -0.05 * s
    sig = 1.0 if d <= nr else -1.0
    sig_term = 0.06 * sig
    return dist_pen + dist_quad + reg_term + ret_term + clu_term + nr_term + spr_term + sig_term
