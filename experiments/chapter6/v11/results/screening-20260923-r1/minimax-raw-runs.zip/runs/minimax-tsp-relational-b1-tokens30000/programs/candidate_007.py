def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    denom = 1e-9 + mr
    sig = 1.0 / (1.0 + exp(-3.0 * (p - 0.3)))
    score = -d + 0.25 * r + 0.20 * nr - 0.15 * sp + 0.15 * cd - 0.20 * rd * sig - (0.3 + 0.7 * p * p) * d * p
    return score
