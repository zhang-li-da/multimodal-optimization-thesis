def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    denom = 1e-9 + mr
    nr_term = nr / denom
    sp_term = sp / denom
    rd_term = rd / denom
    return -d + 0.35 * r + 0.30 * nr_term - 0.10 * sp_term + 0.15 * cd - 0.15 * rd_term - 0.25 * p * d
