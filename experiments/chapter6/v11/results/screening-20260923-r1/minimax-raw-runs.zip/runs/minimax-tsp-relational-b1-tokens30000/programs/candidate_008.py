def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    late = max(0.0, 2.0 * p - 1.0)
    return -d + 0.30 * nr + 0.25 * cd - 0.15 * sp + 0.25 * r - 0.25 * rd * late - 0.50 * p * d
