def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    return -d + 0.35 * nr + 0.25 * cd - 0.20 * sp + 0.20 * r - 0.25 * rd - (0.4 + 0.6 * p) * (p * d)
