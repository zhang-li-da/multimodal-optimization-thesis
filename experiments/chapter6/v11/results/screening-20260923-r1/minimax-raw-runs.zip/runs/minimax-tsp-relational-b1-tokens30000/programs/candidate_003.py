def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    rg = f["regret"]
    return -d + 0.2 * r + 0.15 * rg
