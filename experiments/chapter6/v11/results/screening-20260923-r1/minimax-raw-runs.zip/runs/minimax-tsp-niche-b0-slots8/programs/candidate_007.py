def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pg = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    denom = 1e-9 + (1.0 - pg)
    p = -d + 0.30 * rd + 0.20 * rg + 0.35 * cd * pg + 0.05 * cd * denom - 0.08 * sp * denom - 0.04 * nr - 0.04 * mr - 0.10 * pg
    return p
