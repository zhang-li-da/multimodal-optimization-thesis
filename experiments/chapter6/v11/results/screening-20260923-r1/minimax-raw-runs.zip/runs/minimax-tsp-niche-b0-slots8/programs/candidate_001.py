def priority(f):
    return -f["distance"] + 0.25 * f["return_distance"]
