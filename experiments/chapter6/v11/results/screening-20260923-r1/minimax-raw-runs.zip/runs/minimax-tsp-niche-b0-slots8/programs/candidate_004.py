def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pg = f["progress"]
    eps = 1e-9
    p = -d + 0.35 * rd - 0.15 * nr - 0.10 * mr + 0.20 * rg - 0.20 * pg
    return p
