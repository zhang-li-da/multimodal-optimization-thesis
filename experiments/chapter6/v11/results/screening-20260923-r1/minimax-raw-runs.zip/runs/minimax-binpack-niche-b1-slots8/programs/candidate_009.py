def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    min_gap = f['min_gap']
    position = f['position']
    fraction_fitting = f['fraction_fitting']
    s = 1e-9
    safe_std = std_gap + s
    ratio = (gap - mean_gap) / safe_std
    item_ratio = gap / (item + s)
    residual = item / (remaining + s)
    base = -gap + 0.08 * ratio + 0.08 * item_ratio - 0.05 * position + 0.25 * residual - 0.15 * residual * residual
    bonus = 0.0
    if gap <= min_gap + s:
        bonus = bonus + 0.05
    if fraction_fitting < 0.25:
        bonus = bonus + 0.03 * ratio
    return base + bonus
