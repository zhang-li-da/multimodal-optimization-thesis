def priority(f):
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    position = f["position"]
    item = f["item"]
    fill = f["fill"]
    remaining = f["remaining"]
    fraction_fitting = f["fraction_fitting"]
    denom = 1e-9 + abs(mean_gap) + std_gap
    rel = (gap - mean_gap) / denom
    score = -gap + 0.10 * rel - 0.05 * position
    score = score - 0.25 * fill
    score = score + 0.05 * (1.0 - fraction_fitting)
    score = score - 0.02 * (remaining - item)
    if gap < 0.05:
        score = score + 0.50
    if gap < item * 0.25:
        score = score - 0.20
    return score