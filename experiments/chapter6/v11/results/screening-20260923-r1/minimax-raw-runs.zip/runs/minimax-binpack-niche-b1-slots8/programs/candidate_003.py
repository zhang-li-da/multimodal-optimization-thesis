def priority(f):
    gap = f["gap"]
    remaining = f["remaining"]
    item = f["item"]
    fill = f["fill"]
    min_gap = f["min_gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    safe_fraction = fraction_fitting if fraction_fitting > 1e-9 else 1e-9
    denom_std = std_gap if std_gap > 1e-9 else 1e-9
    base = -gap
    tight_penalty = 0.15 * (gap - min_gap)
    fill_penalty = -0.25 * (fill * gap)
    frac_bonus = 0.05 * ((1.0 - safe_fraction) - 0.5)
    pos_bonus = -0.02 * position
    mean_adj = 0.02 * (gap - mean_gap) / denom_std
    return base + tight_penalty + fill_penalty + frac_bonus + pos_bonus + mean_adj
