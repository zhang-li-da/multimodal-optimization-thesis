def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    min_gap = f['min_gap']
    fill = f['fill']
    position = f['position']
    frac = f['fraction_fitting']
    s = 1e-9
    safe_std = std_gap + s
    ratio = (gap - mean_gap) / safe_std
    item_ratio = gap / (item + s)
    pos_term = position
    base = -gap + 0.08 * ratio + 0.05 * item_ratio - 0.04 * pos_term
    density = fill
    bonus = 0.0
    if remaining <= item + s:
        bonus = 1.0
    if item_ratio < 0.2:
        bonus = bonus + 0.02
    if gap <= min_gap + s:
        bonus = bonus + 0.03
    if frac < 0.25:
        bonus = bonus + 0.05 * (gap - mean_gap) / safe_std
    penalty = 0.0
    if position > 0.6:
        penalty = (position - 0.6) * 0.05
    if gap > mean_gap + safe_std:
        penalty = penalty + 0.01 * ratio
    score = base + bonus - penalty
    return score
