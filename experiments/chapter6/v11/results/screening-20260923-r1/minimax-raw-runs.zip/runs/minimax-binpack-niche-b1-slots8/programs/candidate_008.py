def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    min_gap = f['min_gap']
    fill = f['fill']
    position = f['position']
    s = 1e-9
    safe_std = std_gap + s
    ratio = (gap - mean_gap) / safe_std
    item_ratio = gap / (item + s)
    base = -gap + 0.08 * ratio + 0.05 * item_ratio - 0.04 * position + 0.30 * (item / (remaining + s))
    bonus = 0.0
    if remaining <= item + s:
        bonus = 0.04
    if item_ratio > 0.6:
        bonus = bonus - 0.02 * item_ratio
    if gap <= min_gap + s:
        bonus = bonus + 0.04
    score = base + bonus
    return score