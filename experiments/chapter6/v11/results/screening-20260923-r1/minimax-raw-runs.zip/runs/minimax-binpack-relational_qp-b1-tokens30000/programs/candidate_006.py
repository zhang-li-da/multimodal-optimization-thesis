def priority(f):
    item = f["item"]
    gap = f["gap"]
    pos = f["position"]
    fit = f["fraction_fitting"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    sg = item + 1e-3
    sd = 0.35 * item + 0.05
    bonus = exp(-((gap - item) ** 2) / (2.0 * sd * sd))
    loose = max(0.0, gap - item)
    penalty = 0.25 * loose * loose / sg
    dev = gap - mean_gap
    sgain = max(0.0, min_gap - gap)
    return -gap + bonus - penalty + 0.1 * dev + 0.05 * sgain - 0.001 * pos + 0.05 * fit
