def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    std_gap = f["std_gap"]
    position = f["position"]
    fill = f["fill"]
    remaining = f["remaining"]
    min_gap = f["min_gap"]
    fraction_fitting = f["fraction_fitting"]
    denom = max(std_gap * std_gap, 1e-4)
    bal = -((gap - mean_gap) ** 2) / denom
    exact = -0.05 * ((gap - 2.0 * item) ** 2)
    tight = -2.0 * abs(gap - item)
    pos = -0.001 * position
    ff = -0.01 * (1.0 - fraction_fitting)
    bonus = 0.0
    if gap <= item + 1e-9:
        bonus = 1.0
    return bal + exact + tight + pos + ff + bonus
