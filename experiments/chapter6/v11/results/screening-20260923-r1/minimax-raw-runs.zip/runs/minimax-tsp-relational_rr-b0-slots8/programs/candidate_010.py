def priority(f):
    d = f['distance']
    rd = f['return_distance']
    pr = f['progress']
    pr2 = pr * pr
    p = -d + 0.20 * rd + 0.40 * pr2 * rd
    return p