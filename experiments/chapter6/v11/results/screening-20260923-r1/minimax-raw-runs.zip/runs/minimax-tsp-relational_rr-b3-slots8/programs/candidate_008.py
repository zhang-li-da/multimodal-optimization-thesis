def priority(f):
    d = f['distance']
    r = f['return_distance']
    p = f['progress']
    g = f['regret']
    s = f['spread']
    ratio = r / (d + 1e-9)
    close_w = 0.15 + 0.35 * p
    close_term = close_w * r * ratio
    regret_term = 0.10 * g / (s + 1e-9)
    return -d + close_term - regret_term
