def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    e = 1e-9
    nm = n / (m + e)
    rsp = rg / (sp + e)
    w = 0.10 + 0.45 * p
    local = -d + w * r
    closure = (0.20 + 0.30 * p) * (r / (d + e))
    anti = 0.15 * nm - 0.10 * rsp
    bias = 0.05 * cd - 0.05 * p * sp
    return local + closure + anti + bias