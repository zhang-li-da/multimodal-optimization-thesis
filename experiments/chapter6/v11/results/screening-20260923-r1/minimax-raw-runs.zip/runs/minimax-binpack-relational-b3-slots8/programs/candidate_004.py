def priority(f):
    item = f["item"]
    remaining = f["remaining"]
    gap = f["gap"]
    fill = f["fill"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom = std_gap + 0.05
    deviation = abs(mean_gap - gap) / denom
    base = -deviation + 0.05 * gap + 0.5 * fraction_fitting
    tie = 0.001 * position + 1e-4 * gap
    return base + tie