def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    denom = std_gap + 0.05
    target = item * 0.5 * (1.0 - fraction_fitting) + min_gap * fraction_fitting
    sq = (gap - target) * (gap - target)
    main = -sq / denom + 0.08 * gap * fraction_fitting + 0.5 * mean_gap / denom
    main = main + 0.001 * position
    return main