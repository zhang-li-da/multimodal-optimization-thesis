def priority(f):
    item = f["item"]
    gap = f["gap"]
    mean_gap = f["mean_gap"]
    min_gap = f["min_gap"]
    std_gap = f["std_gap"]
    fraction_fitting = f["fraction_fitting"]
    position = f["position"]
    target_residual = item * 0.5
    diff = gap - target_residual
    norm_std = std_gap + 0.05
    tight_score = -(diff * diff) / norm_std
    weight = 1.0 + 1.0 * item
    tight_score = tight_score * weight
    spread = 0.1 * gap * (1.0 - fraction_fitting) * (0.5 + 0.5 * item)
    score = tight_score + spread + 1e-3 * position
    return score