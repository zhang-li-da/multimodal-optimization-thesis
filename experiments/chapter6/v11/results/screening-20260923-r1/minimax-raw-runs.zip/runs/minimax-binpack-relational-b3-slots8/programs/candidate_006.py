def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    std_gap = f['std_gap']
    fraction_fitting = f['fraction_fitting']
    position = f['position']
    dev = gap - mean_gap
    weight = 1 + 2 * item * item
    balance = -(dev * dev) / (std_gap + 0.05) * weight
    spread = 0.15 * gap * (1 - fraction_fitting)
    tie = 1e-3 * position
    score = balance + spread + tie
    return score
