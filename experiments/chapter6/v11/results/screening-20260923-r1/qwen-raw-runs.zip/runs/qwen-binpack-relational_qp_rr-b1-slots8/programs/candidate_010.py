def priority(f):
    item = f['item']
    gap = f['gap']
    ratio = gap / (item + 1e-9)
    return -abs(ratio - 0.5)