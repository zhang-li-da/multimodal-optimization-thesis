def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    denom = 0.1 + cd
    if denom < 1e-9:
        denom = 1e-9
    score = -d + 0.5 * r / denom
    return score