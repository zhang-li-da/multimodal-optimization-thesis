def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    cd = f["cluster_density"]
    w_return = 0.25 * (1.5 - cd)
    if w_return < 0.05:
        w_return = 0.05
    elif w_return > 0.5:
        w_return = 0.5
    return -d + w_return * rd