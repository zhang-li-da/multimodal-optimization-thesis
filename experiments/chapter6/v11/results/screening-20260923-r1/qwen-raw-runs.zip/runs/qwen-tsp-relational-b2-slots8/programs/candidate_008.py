def priority(f):
    d = f["distance"]
    r_dist = f["return_distance"]
    cd = f["cluster_density"]
    penalty_factor = 1.0 - 0.2 * cd
    score = -d * penalty_factor + 0.3 * r_dist
    return score