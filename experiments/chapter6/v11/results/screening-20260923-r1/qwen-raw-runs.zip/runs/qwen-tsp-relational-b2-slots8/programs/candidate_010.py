def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    cd = f['cluster_density']
    denom = 0.1 + cd
    if denom < 1e-9:
        denom = 1e-9
    w = 0.3 / denom
    if w > 0.8:
        w = 0.8
    return -d + w * (rd + r)