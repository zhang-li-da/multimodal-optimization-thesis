def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + (0.2 + 0.8 * p) * r