def priority(f):
    gap = f["gap"]
    position = f["position"]
    fraction_fitting = f["fraction_fitting"]
    weight = 0.1 * (1.0 - fraction_fitting)
    return -gap - weight * position