def priority(f):
    g = f["gap"]
    penalty = 1000.0 if (g > 1e-9 and g < 0.05) else 0.0
    return -g - penalty