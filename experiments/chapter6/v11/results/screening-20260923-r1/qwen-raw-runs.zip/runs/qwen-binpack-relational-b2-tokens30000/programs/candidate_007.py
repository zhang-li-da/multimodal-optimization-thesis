def priority(f):
    gap = f['gap']
    item = f['item']
    fill_after = 1.0 - gap
    threshold = item * 0.1
    fragmentation_penalty = 0.0 if gap > threshold else (threshold - gap) * 10
    return fill_after - fragmentation_penalty