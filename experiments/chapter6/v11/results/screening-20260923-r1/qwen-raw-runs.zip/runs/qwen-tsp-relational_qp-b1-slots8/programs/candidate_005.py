def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.25 * r + 0.4 * cd