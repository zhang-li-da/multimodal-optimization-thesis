def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    w_ret = 0.1 + 0.4 * p
    return -d + 0.2 * r + w_ret * rd