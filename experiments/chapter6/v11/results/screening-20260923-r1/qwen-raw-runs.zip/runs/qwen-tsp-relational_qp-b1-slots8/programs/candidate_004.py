def priority(f):
    return -f["distance"] + 0.2 * f["regret"] + 0.3 * f["return_distance"]