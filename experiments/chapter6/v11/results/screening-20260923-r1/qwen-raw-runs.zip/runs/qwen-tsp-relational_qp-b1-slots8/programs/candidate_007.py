def priority(f):
    d = f['distance']
    r = f['regret']
    p = f['progress']
    w_r = 0.2 + 0.3 * p
    return -d + w_r * r