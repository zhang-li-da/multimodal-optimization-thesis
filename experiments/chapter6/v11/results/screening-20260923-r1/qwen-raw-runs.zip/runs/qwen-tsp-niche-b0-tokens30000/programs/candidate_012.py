def priority(f):
    d = f['distance']
    r = f['return_distance']
    reg = f['regret']
    score = -d + 0.15 * reg + 0.35 * r
    return score