def priority(f):
    item = f['item']
    gap = f['gap']
    mean_gap = f['mean_gap']
    fraction_fitting = f['fraction_fitting']
    safe_frac = max(fraction_fitting, 1e-9)
    deviation = abs(gap - mean_gap)
    penalty = (1.0 / safe_frac) * deviation
    return -gap - penalty