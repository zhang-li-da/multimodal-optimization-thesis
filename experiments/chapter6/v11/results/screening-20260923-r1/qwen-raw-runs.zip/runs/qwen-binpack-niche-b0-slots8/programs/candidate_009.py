def priority(f):
    gap = f['gap']
    item = f['item']
    frac = max(f['fraction_fitting'], 1e-9)
    ratio = gap / max(item, 1e-9)
    penalty = (ratio - 0.5)**2 * frac
    return -gap - penalty