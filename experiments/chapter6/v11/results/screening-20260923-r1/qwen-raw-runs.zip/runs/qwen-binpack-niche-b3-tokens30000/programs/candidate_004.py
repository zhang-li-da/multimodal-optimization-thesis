def priority(f):
    g = f["gap"]
    m = f["mean_gap"]
    penalty = 0.0
    if m > 1e-9 and g < m * 0.5:
        penalty = 0.05 / (g + 1e-9)
    return -g - penalty