def priority(f):
    g = f['gap']
    m = f['mean_gap']
    s = f['std_gap']
    p = 0.0
    if s > 1e-9 and g < m - s:
        p = 0.2 / (g + 1e-9)
    elif g < 0.01:
        p = 0.5 / (g + 1e-9)
    return -g - p