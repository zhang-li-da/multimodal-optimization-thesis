def priority(f):
    g = f["gap"]
    m = f["mean_gap"]
    s = f["std_gap"]
    p = 0.0
    if g < m - s:
        p = 0.1 / (g + 1e-9)
    return -g - p