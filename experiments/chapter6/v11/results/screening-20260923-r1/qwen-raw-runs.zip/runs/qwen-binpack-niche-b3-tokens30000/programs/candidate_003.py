def priority(f):
    g = f["gap"]
    penalty = 0.0
    if g < 0.05:
        penalty = 0.1 / (g + 1e-9)
    return -g - penalty