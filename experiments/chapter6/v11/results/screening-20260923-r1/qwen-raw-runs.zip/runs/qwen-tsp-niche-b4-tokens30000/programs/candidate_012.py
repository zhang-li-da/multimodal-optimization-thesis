def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    reg = f["regret"]
    p = f["progress"]
    scale = 0.1 + 0.5 * p ** 2
    return -d + 0.1 * reg + scale * r