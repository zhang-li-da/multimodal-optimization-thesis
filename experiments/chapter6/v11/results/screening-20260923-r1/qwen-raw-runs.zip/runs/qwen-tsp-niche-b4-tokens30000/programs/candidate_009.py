def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    safe_r = r + 1e-9
    log_term = log(1 + safe_r)
    return -d + 0.5 * (rd ** 2) + 0.1 * log_term