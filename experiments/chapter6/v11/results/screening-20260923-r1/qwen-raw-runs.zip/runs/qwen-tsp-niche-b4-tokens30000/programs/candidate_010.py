def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    p = f["progress"]
    w_rd = 0.2 + 0.4 * p
    return -d + 0.15 * r + 0.1 * cd + w_rd * rd