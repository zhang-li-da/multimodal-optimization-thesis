def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    cd = f["cluster_density"]
    return cd - d + (0.1 + 2.0 * p) * r