def priority(f):
    return -f["distance"] + 0.3 * f["return_distance"] + 0.1 * f["regret"]