def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    p = f["progress"]
    r = f["regret"]
    return -d + 0.25 * rd + p * r