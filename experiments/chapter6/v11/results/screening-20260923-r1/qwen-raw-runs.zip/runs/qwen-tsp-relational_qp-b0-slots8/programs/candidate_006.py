def priority(f):
    d = f["distance"]
    p = f["progress"]
    r = f["regret"]
    decay = (1.0 - p) ** 2
    return -d + decay * r