def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    p = f["progress"]
    cd = f["cluster_density"]
    return -d + p * rd + (1.0 - p) * cd