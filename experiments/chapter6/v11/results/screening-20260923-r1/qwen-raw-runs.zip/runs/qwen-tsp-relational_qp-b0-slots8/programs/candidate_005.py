def priority(f):
    d = f["distance"]
    p = f["progress"]
    r = f["regret"]
    return -d + p * r