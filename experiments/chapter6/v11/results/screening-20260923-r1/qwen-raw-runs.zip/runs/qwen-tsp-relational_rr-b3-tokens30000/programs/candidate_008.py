def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    w = 0.5 * (1.0 - p) ** 2
    return -d + w * r