def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    mr = f["mean_remaining"]
    return -d + 0.15 * rd - 0.1 * mr