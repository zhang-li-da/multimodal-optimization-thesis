def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    return -d + 0.15 * r + 0.15 * rd