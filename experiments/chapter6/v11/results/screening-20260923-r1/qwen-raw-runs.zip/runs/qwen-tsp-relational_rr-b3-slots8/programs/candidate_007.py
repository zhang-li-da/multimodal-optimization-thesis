def priority(f):
    p = f['progress']
    reg = f['regret']
    d = f['distance']
    return 2.0 * p + 0.5 * reg - 1.0 * d