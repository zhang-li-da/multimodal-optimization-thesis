def priority(f):
    d = f['distance']
    reg = f['regret']
    mr = f['mean_remaining']
    return -d + 0.4 * reg - 0.3 * mr