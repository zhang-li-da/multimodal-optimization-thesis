def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    return -d + 0.2 * g + 0.3 * r