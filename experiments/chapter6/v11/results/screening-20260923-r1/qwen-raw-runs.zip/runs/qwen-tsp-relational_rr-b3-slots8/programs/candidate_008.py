def priority(f):
    p = f['progress']
    reg = f['regret']
    d = f['distance']
    return (p ** 2) * 3.0 + 0.4 * reg - 1.0 * d