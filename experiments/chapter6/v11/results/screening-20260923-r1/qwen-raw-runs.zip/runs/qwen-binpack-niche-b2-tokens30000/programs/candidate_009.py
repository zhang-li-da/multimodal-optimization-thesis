def priority(f):
    g = f['gap']
    ff = f['fraction_fitting']
    mg = f['mean_gap']
    d = 1e-9
    t1 = -(g * g) * (1.0 - ff)
    diff = g - mg
    t2 = -(diff * diff) * ff
    return t1 + t2