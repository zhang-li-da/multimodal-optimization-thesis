def priority(f):
    g = f['gap']
    mg = f['mean_gap']
    ff = f['fraction_fitting']
    d = g - mg
    return -g * (1.0 - ff) - d * d * ff