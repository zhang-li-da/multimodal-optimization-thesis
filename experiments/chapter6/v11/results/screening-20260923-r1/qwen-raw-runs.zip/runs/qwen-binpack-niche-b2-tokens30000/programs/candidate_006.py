def priority(f):
    g = f['gap']
    mg = f['mean_gap']
    return -(g - mg) ** 2