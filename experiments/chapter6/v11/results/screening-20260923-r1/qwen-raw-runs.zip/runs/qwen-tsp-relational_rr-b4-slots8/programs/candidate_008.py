def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    return -d + 0.2 * rd + r * (1.0 + 2.0 * p**2)