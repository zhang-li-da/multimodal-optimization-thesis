def priority(f):
    g = f['gap']
    p = f['position']
    return -(g + p * 0.05)