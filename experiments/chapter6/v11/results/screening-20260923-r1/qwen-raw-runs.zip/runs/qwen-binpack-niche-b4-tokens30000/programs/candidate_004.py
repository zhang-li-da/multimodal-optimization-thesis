def priority(f):
    g = f["gap"]
    p = f["position"]
    return -(g ** 2) - (p * 0.01)