def priority(f):
    d = f['distance']
    r = f['regret']
    s = f['spread']
    p = -d + 0.25 * r + 0.15 * s
    return p