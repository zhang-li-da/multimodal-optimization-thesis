def priority(f):
    d = f['distance']
    r = f['return_distance']
    return -(d ** 2) + 0.3 * r