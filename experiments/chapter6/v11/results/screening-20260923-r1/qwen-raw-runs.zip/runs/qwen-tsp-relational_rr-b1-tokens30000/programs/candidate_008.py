def priority(f):
    d = f["distance"]
    r = f["regret"]
    if d < 1e-9:
        return 1e6
    return -d + 0.5 * (r / d)