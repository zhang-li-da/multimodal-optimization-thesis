def priority(f):
    d = f["distance"]
    r = f["regret"]
    s = f["spread"]
    return -d + 0.2 * r - 0.1 * s