def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    w_d = 0.5 + 0.5 * p
    w_r = 1.0 - 0.5 * p
    return -d * w_d + r * w_r