def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    return -d + 0.4 * r + 0.2 * rd