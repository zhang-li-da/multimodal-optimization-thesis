def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = max(0.0, f["regret"])
    cd = max(0.0, f["cluster_density"])
    return -d + 0.2 * rd + 0.4 * sqrt(r) + 0.3 * sqrt(cd)