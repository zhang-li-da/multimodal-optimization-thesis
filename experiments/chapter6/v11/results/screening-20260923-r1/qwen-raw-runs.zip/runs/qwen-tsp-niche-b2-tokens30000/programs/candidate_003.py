def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    p = f["progress"]
    w_ret = 0.2 * (1.0 - p)
    w_reg = 0.3 * p
    return -d + w_ret * rd + w_reg * reg