def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    psq = p * p
    w_r = 0.4 * (1.0 - psq)
    w_rd = 0.2 + 0.4 * psq
    return -d + w_r * r + w_rd * rd