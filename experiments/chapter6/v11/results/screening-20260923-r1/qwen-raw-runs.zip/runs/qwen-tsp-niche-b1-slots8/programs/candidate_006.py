def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.2 * reg + 0.15 * cd - 0.1 * rd