def priority(f):
    return -f["distance"] + f["progress"] * f["regret"]