def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    regret_weight = 0.5 * (1 - p)
    return -d + regret_weight * r