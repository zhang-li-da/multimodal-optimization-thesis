def priority(f):
    d = f["distance"]
    r = f["regret"]
    mr = f["mean_remaining"]
    return -d + 0.4 * r + 0.2 * mr