def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    return -d + 0.3 * r + 0.2 * rd