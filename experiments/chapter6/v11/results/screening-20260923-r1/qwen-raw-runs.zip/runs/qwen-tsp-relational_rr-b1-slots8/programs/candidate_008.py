def priority(f):
    d = f["distance"]
    r = f["regret"]
    safe_r = max(r, 0.0)
    return -d + 0.5 * sqrt(safe_r)