def priority(f):
    mean_gap = f['mean_gap']
    gap = f['gap']
    return -abs(gap - mean_gap)