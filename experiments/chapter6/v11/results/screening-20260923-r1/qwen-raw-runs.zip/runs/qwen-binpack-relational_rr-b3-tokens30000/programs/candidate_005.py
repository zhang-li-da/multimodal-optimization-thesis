def priority(f):
    g = f['gap']
    r = f['remaining']
    s = f['item']
    return -g - 0.5 * s / (r + 1e-9)