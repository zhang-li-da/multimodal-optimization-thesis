def priority(f):
    g = f["gap"]
    mg = f["mean_gap"]
    safe_g = g + 1e-9
    penalty = (1.0 / safe_g) * 0.1 * mg
    return -g - penalty