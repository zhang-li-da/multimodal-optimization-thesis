def priority(f):
    gap = f['gap']
    remaining = f['remaining']
    if gap < 0.01:
        return -1000
    if remaining > 1e-9:
        return -(gap / remaining)
    else:
        return 0