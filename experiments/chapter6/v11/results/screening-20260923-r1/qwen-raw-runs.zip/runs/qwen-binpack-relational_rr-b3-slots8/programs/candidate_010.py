def priority(f):
    item = f['item']
    remaining = f['remaining']
    gap = f['gap']
    fit_ratio = item / (remaining + 1e-9)
    penalty = 0.0
    if gap > 0 and gap < 0.05:
        penalty = 10.0
    return fit_ratio - penalty