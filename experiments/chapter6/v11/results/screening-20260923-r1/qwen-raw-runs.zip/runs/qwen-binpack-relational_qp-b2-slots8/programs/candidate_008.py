def priority(f):
    g = f['gap']
    ff = f['fraction_fitting']
    base = -g
    adapt = 1.0 + log(1e-9 + ff)
    return base * adapt