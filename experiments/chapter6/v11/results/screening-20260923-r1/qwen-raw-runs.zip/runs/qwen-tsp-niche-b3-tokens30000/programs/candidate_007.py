def priority(f):
    d = f["distance"]
    r = f["regret"]
    mr = f["mean_remaining"]
    score = -d + 0.2 * r - 0.15 * mr
    return score