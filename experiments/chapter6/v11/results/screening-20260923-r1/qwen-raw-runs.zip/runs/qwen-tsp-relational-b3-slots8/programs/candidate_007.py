def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    p = f["progress"]
    return -d + (1.0 - p) * 0.5 * rd