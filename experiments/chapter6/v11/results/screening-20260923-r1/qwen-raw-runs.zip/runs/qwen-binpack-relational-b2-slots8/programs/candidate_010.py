def priority(f):
    return -abs(f['gap'] - f['mean_gap'])