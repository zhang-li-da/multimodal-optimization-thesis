def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    safe_r = max(0.0, r)
    return -d + 0.1 * (rd ** 2) + 0.2 * sqrt(safe_r)