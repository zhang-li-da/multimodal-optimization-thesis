def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    val = -d + 0.1 * (1 - p) * cd + 0.2 * p * rd + 0.15 * r
    return val