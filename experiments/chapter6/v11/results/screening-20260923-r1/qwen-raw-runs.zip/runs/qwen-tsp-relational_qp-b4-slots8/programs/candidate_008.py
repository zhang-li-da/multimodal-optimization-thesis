def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    rd = f["return_distance"]
    return -d + 0.4 * p * (r + 0.5 * rd)