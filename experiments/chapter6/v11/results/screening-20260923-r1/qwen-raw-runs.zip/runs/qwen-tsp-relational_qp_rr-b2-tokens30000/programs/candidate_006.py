def priority(f):
    d = f['distance']
    r = f['regret']
    p = f['progress']
    w = 0.1 + 2.0 * p ** 2
    return -d + w * r