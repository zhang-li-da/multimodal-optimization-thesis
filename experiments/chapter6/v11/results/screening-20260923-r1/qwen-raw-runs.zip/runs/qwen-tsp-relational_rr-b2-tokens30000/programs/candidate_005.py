def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + p * r