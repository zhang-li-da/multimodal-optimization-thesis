def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    return -d + 0.1 * rd + r * (p ** 2)