def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    w = 0.1 + 0.5 * p
    return -d + w * r