def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    w_r = 0.2 + 0.3 * cd
    return -d + 0.15 * rd + w_r * r