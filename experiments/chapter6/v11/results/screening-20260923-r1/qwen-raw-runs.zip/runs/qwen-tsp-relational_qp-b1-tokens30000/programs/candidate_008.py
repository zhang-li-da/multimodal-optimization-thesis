def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    w = 0.1 + 0.4 * cd ** 2
    return -d + w * r