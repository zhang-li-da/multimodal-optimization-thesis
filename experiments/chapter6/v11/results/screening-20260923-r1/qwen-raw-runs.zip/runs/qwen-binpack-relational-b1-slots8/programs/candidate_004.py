def priority(f):
    g = f["gap"]
    mg = f["mean_gap"]
    return -abs(g - mg)