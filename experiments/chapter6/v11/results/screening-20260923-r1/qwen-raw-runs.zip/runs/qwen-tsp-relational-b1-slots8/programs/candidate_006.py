def priority(f):
    return -f["distance"] + 0.4 * f["regret"] + 0.2 * f["return_distance"] - 0.3 * f["mean_remaining"]