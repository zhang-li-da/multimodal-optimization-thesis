def priority(f):
    p = f["progress"]
    return -f["distance"] + (1.0 - p**3) * 0.7 * f["regret"] + p * 0.25 * f["return_distance"]