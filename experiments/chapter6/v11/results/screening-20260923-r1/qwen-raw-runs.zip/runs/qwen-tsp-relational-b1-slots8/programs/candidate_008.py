def priority(f):
    p = f["progress"]
    return -f["distance"] + (1.0 - p**2) * 0.6 * f["regret"] + p * 0.2 * f["return_distance"]