def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    return -d + (0.1 + 0.9 * (p ** 2)) * r