def priority(f):
    return -f["distance"] + 0.2 * f["regret"] + 0.15 * f["cluster_density"]