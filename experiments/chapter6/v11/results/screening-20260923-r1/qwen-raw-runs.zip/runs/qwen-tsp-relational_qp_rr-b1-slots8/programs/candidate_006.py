def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    mr = f["mean_remaining"]
    return -0.4 * d + 0.3 * r + 0.2 * cd - 0.1 * mr