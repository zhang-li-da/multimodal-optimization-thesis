def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    return -d + (0.2 + 0.8 * p) * r