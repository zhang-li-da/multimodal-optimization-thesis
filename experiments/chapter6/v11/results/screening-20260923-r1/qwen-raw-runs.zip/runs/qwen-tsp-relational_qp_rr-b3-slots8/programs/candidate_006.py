def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    mr = f["mean_remaining"]
    return -d + 0.2 * rd - 0.3 * mr