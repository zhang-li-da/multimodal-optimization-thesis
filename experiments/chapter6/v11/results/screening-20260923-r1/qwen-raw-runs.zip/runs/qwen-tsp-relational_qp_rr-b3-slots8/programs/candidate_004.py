def priority(f):
    return -f["distance"] + 0.4 * f["regret"] + 0.3 * f["return_distance"]