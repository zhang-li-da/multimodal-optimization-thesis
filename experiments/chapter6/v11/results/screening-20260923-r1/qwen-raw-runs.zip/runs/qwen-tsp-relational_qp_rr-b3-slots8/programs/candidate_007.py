def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    prog = f["progress"]
    w_reg = (1.0 - prog) * 0.5
    return -d + w_reg * reg + 0.1 * rd