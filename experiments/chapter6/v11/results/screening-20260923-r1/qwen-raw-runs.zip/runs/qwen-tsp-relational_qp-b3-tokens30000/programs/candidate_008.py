def priority(f):
    d = f['distance'] + 1e-9
    r = f['regret']
    return -sqrt(d) + 0.4 * r