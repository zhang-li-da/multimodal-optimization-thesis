def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    return p + 0.5 * r - 0.2 * d