def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    prog = f['progress']
    score = -d + 0.4 * reg * (1.0 - prog) + 0.15 * rd
    return score