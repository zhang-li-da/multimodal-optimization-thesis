def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.3 * r * cd + 0.1 * rd