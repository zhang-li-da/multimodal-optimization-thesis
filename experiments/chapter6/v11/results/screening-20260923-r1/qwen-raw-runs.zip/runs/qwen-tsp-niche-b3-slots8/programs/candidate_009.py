def priority(f):
    d = f['distance']
    cd = f['cluster_density']
    r = f['regret']
    return -d * (1.0 + 0.5 * cd) + 0.3 * r