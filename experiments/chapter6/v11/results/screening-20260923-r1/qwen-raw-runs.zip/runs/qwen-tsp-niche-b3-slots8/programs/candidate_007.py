def priority(f):
    d = f['distance']
    r = f['regret']
    s = f['spread']
    val = -d + 0.3 * r - 0.2 * s
    return val