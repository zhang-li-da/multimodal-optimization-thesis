def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    p = f["progress"]
    r = f["regret"]
    return -d + p * rd + 0.1 * r