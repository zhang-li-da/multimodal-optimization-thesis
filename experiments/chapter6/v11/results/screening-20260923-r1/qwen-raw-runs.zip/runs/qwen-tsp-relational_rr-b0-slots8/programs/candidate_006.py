def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    decay = 1.0 - p
    return -d * decay + 0.5 * r