def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    decay = (1.0 - p) ** 2
    return -d + decay * r