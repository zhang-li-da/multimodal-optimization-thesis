def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + (1.0 - p) * r