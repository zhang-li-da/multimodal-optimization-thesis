def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    p = f["progress"]
    decay = (1.0 - p) ** 2
    return -d + decay * r + p * rd