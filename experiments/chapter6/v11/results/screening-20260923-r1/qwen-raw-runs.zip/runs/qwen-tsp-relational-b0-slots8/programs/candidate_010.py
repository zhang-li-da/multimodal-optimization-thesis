def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    p = f["progress"]
    s = 1.0 / (1.0 + exp(10 * (p - 0.5)))
    return -d + s * r + p * rd