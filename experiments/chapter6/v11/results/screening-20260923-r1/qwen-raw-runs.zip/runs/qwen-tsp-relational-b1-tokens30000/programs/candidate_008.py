def priority(f):
    p = f["progress"]
    r = f["regret"]
    d = f["distance"]
    return 2.0 * p + 0.5 * r - 1.0 * d