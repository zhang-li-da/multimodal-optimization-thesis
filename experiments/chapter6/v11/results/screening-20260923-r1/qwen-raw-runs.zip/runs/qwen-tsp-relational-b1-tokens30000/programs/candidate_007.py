def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + 0.5 * (r ** 0.5) + 0.2 * p