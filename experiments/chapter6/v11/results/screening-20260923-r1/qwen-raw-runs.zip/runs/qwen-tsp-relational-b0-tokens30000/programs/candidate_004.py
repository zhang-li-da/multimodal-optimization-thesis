def priority(f):
    d = f["distance"]
    r = f["regret"]
    mr = f["mean_remaining"]
    return -d + 0.8 * r - 0.1 * mr