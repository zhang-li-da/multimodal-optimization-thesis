def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    p = f["progress"]
    return -d + p * rd