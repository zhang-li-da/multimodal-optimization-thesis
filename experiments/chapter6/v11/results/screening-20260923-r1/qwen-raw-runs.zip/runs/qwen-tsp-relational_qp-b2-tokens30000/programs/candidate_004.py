def priority(f):
    d = f["distance"]
    r = f["regret"]
    return -d + 0.4 * r