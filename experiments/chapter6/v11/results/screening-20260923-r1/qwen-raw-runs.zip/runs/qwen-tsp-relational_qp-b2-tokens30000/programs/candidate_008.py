def priority(f):
    d = f["distance"] + 1e-9
    rd = f["return_distance"] + 1e-9
    r = max(0.0, f["regret"])
    return -d + 0.5 * r * rd