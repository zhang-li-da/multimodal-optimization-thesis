def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    w = 0.1 + 0.4 * rd
    return -d + w * r