def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + (0.5 + 1.5 * p) * r