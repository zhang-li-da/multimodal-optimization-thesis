def priority(f):
    d = f["distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + (0.5 + 2.0 * p ** 2) * r