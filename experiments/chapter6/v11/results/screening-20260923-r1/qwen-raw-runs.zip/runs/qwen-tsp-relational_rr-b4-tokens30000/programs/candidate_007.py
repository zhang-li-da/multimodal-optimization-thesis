def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    w_r = 0.3 + 1.2 * p
    return -d + 0.2 * rd + w_r * r