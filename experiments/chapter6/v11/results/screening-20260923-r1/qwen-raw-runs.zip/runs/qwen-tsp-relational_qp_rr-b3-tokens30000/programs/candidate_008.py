def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.5 * (r ** 2) + 0.2 * cd