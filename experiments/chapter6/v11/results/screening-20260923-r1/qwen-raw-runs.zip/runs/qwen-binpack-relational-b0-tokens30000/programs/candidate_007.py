def priority(f):
    gap = f['gap']
    fill_after = f['fill'] + f['item']
    if gap < 0.05:
        return -fill_after * 0.9
    return -fill_after / (gap + 1e-9)