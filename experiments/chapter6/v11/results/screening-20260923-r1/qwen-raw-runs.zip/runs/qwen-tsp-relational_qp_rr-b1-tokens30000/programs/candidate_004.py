def priority(f):
    d = f["distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.2 * r + 0.15 * cd