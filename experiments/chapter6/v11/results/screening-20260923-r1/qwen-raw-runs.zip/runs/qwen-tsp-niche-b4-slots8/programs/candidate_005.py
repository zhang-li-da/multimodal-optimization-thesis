def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    w_rd = 0.1 + 0.4 * p
    w_r = 0.3 - 0.2 * p
    return -d + w_rd * rd + w_r * r