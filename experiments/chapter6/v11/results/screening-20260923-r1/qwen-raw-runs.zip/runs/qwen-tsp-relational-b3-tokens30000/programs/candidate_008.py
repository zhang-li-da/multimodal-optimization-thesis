def priority(f):
    d = f["distance"]
    reg = f["regret"]
    p = f["progress"]
    return -d + (1.0 - p) ** 2 * 0.6 * reg