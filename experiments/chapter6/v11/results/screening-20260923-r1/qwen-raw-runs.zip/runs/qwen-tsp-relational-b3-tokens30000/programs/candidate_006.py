def priority(f):
    d = f["distance"]
    reg = f["regret"]
    rd = f["return_distance"]
    return -d + 0.4 * reg + 0.1 * rd