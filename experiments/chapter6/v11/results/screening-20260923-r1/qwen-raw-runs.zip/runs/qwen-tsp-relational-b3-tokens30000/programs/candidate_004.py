def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    return -d + 0.1 * rd + 0.2 * reg