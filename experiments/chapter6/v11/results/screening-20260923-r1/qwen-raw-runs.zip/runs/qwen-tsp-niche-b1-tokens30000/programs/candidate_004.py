def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    return -d + 0.35 * rd + 0.1 * r