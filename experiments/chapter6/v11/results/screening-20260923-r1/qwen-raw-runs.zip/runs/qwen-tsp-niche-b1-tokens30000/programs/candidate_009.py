def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    sqrt_r = sqrt(max(0.0, r))
    w_rd = 0.1 + 0.4 * p ** 2
    return -d + 0.2 * sqrt_r + w_rd * rd