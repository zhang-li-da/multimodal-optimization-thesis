def priority(f):
    d = f['distance']
    r = f['regret']
    s = f['spread']
    val = -d + 0.2 * r + 0.15 * s
    return val