def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    cd = f['cluster_density']
    w_ret = 0.1 + 0.3 * p
    safe_r = max(0.0, r)
    sqrt_r = sqrt(safe_r)
    score = -d + w_ret * rd + 0.2 * cd + 0.1 * sqrt_r
    return score