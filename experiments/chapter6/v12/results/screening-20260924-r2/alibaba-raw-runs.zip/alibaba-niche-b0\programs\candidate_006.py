def priority(f):
    return -f["distance"] + 0.4 * f["return_distance"] + 0.25 * f["regret"] + 0.1 * f["cluster_density"]