def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    return -d + 0.15 * rd + 0.2 * reg - 0.3 * cd