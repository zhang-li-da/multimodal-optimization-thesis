def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    p = f["progress"]
    log_rd = log(1.0 + rd + 1e-9)
    regret_term = r * (p ** 2)
    return -d + 0.15 * log_rd + 0.25 * regret_term