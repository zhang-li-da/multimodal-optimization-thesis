def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    reg = f["regret"]
    return -d + 0.3 * reg + 0.15 * r