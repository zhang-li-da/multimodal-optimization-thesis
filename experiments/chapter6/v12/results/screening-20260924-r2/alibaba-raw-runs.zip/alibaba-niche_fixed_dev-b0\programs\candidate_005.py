def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    reg = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.3 * reg + 0.15 * r - 0.1 * cd