def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    safe_cd = max(0.0, cd)
    return -d + 0.1 * rd + 0.35 * reg - 0.2 * sqrt(safe_cd)