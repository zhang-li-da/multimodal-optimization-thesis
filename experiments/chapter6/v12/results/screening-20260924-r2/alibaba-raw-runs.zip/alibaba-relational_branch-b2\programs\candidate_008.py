def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    p = f['progress']
    w_rd = 0.1 + 0.2 * p
    w_reg = 0.3 - 0.2 * p
    return -d + w_rd * rd + w_reg * reg