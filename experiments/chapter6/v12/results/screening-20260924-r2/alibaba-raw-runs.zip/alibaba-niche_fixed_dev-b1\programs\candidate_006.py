def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    w = 0.3 + 0.4 * p
    return -d + w * rd * rd + 0.15 * r