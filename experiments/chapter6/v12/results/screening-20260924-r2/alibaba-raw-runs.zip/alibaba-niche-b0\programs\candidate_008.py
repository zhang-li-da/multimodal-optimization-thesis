def priority(f):
    p = f["progress"]
    w_ret = 0.2 + 0.3 * p
    w_clust = 0.15 * (1 - p)
    return -f["distance"] + w_ret * f["return_distance"] + w_clust * f["cluster_density"]