def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    p = f['progress']
    w1 = 0.5 * (1.0 - p)
    w2 = 0.2 * p
    return -d + w1 * reg + w2 * rd