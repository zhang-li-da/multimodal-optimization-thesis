def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    val = -d + 0.2 * rd + 0.3 * r
    return val