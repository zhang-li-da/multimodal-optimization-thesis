def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    val = -d + 0.3 * r + 0.15 * rd
    return val