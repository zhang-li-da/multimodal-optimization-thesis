def priority(f):
    p = f["progress"]
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    cd = f["cluster_density"]
    w_rd = 0.1 + 0.4 * p * p
    w_cd = 0.15 * (1 - p)
    return -d + w_rd * rd + 0.15 * reg - w_cd * cd