def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    cd = f['cluster_density']
    val = -d + 0.2 * rd + 0.3 * r + 0.15 * cd
    return val