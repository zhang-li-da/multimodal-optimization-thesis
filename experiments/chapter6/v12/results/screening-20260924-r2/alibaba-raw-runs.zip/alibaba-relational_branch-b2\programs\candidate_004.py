def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    cd = f["cluster_density"]
    score = -d + 0.15 * reg + 0.2 * rd + 0.3 * cd
    return score