def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    w = (1.0 - p) ** 2
    return -d + 0.3 * w * r + 0.25 * rd