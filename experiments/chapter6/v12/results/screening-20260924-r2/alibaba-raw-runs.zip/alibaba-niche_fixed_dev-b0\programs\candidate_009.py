def priority(f):
    d = f['distance']
    r = f['regret']
    cd = f['cluster_density']
    rd = f['return_distance']
    s_d = sqrt(d + 1e-9)
    return -s_d + 0.35 * r + 0.1 * rd - 0.15 * cd