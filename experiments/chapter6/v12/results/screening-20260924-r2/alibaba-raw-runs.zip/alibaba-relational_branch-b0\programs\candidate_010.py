def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    p = f['progress']
    w_reg = 0.2 + 0.3 * p
    w_cd = 0.2 * p
    return -d + 0.1 * rd + w_reg * reg - w_cd * cd