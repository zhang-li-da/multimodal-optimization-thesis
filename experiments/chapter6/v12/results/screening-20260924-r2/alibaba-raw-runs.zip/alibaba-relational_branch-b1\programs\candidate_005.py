def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    w_r = (1.0 - p) * 0.5
    val = -d + w_r * r + 0.1 * rd
    return val