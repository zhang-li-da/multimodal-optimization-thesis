def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    score = -sqrt(d + 1e-9) + 0.4 * reg + 0.3 * rd
    return score