def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    s_d = sqrt(d + 1e-9)
    return -s_d + 0.4 * r + 0.1 * rd