def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    return -d + 0.2 * rd + 0.15 * reg