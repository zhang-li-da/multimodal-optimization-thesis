def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    p = f["progress"]
    term3 = sqrt(max(0.0, rd * p) + 1e-9)
    return -d + 0.2 * r + 0.15 * term3