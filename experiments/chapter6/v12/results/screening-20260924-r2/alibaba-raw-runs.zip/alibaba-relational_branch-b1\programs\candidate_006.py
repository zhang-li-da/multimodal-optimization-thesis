def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    cd = f['cluster_density']
    val = -d + 0.25 * rd + 0.4 * (r ** 0.5) + 0.15 * (cd ** 0.5)
    return val