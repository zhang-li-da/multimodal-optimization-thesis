def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    val = -d + 0.1 * rd + 0.5 * r
    return val