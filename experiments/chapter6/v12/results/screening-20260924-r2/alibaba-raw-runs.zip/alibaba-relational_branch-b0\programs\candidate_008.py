def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    return -d + 0.15 * rd + 0.25 * reg - 0.25 * (cd ** 2)