def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    reg = f["regret"]
    cd = f["cluster_density"]
    score = -sqrt(d + 1e-9) + 0.3 * reg + 0.2 * rd + 0.15 * cd
    return score