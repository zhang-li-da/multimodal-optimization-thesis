def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    s = f['spread']
    p = f['progress']
    s_d = sqrt(d + 1e-9)
    return -s_d + 0.3 * r - 0.2 * s * (1 - p) + 0.3 * rd * p