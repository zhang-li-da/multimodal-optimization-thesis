def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    p = f['progress']
    w_reg = 0.2 + 0.1 * (1.0 - p)
    w_rd = 0.25 + 0.15 * p
    return -d + w_reg * reg + w_rd * rd