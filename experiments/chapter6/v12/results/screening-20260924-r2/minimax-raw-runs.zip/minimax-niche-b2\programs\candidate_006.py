def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    rg = f["regret"]
    return -d + 0.30 * r + 0.35 * rg + 0.10 * c
