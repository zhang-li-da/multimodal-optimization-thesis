def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    pr = f["progress"]
    regret = f["regret"]
    decay = 1.0 - pr
    return -d + (0.20 + 0.40 * decay) * rd + 0.30 * regret - 0.08 * pr * nr
