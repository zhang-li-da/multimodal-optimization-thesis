def priority(f):
    a = -f["distance"]
    b = 0.08 * f["return_distance"]
    c = 0.12 * f["regret"]
    d = -0.18 * f["cluster_density"]
    e = 0.02 * f["spread"]
    g = 0.05 * f["mean_remaining"]
    h = 0.04 * f["nearest_remaining"]
    p = f["progress"]
    q = -0.03 * p
    return a + b + c + d + e + g + h + q
