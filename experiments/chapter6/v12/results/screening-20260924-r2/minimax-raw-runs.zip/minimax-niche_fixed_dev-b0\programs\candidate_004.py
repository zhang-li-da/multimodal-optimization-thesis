def priority(f):
    d = f['distance']
    r = f['return_distance']
    g = f['regret']
    p = f['progress']
    return -d + 0.28 * r + 0.10 * g + 0.05 * p
