def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    regret = f["regret"]
    progress = f["progress"]
    density = f["cluster_density"]
    return -d + 0.30 * regret + (0.05 + 0.25 * progress) * rd - 0.10 * density
