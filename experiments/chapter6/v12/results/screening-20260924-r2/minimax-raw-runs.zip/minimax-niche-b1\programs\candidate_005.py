def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    inv_d = -d
    w_r = 0.20 * r
    w_rg = 0.35 * rg
    w_cd = 0.15 * cd
    w_sp = -0.05 * sp
    base = inv_d + w_r + w_rg + w_cd + w_sp
    rem = 1.0 - p
    if rem > 0.5:
        early_bonus = 0.10 * n
    else:
        early_bonus = 0.0
    late_penalty = 0.05 * m * p
    score = base + early_bonus - late_penalty
    return score