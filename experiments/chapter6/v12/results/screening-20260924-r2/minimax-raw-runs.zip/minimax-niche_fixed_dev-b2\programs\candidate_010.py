def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    term_rd = (0.18 + 0.35 * (1.0 - pr)) * rd
    denom = mr + 0.3 * sp + eps
    term_rg = (0.22 + 0.10 * pr) * rg / denom
    term_nr = 0.07 * pr * cd * nr
    term_sp = 0.03 * sp * (1.0 - pr)
    term_cd = 0.06 * (1.0 - pr) * cd
    return -d + term_rd + term_rg - term_nr - term_sp + term_cd