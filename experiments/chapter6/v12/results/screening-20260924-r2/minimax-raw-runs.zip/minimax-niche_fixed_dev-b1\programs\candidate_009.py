def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    safe_mr = mr + 1e-9
    decay_d = 1.0 - 0.6 * p
    decay_rd = 1.0 - 0.75 * p
    reg_weight = 0.30 + 0.35 * p
    spread_gate = 0.5 - sp / safe_mr
    if spread_gate < 0.0:
        gate = 0.0
    else:
        gate = spread_gate
    cluster_term = 0.06 * cd * (1.0 - p) * gate
    prox_raw = nr / safe_mr - 1.0
    if prox_raw < 0.0:
        prox_clamped = 0.0
    else:
        if prox_raw > 0.5:
            prox_clamped = 0.5
        else:
            prox_clamped = prox_raw
    prox_term = 0.03 * prox_clamped
    score = -d * decay_d + 0.18 * rd * decay_rd + reg_weight * r + cluster_term + prox_term
    return score