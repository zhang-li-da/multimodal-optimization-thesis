def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    c = f["cluster_density"]
    s = f["spread"]
    return -d + 0.12 * r + 0.12 * g - 0.13 * c + 0.04 * s
