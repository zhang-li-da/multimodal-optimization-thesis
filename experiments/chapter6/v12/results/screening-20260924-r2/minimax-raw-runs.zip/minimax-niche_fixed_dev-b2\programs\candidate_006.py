def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    pr = f["progress"]
    rg = f["regret"]
    cd = f["cluster_density"]
    return -d + (0.15 + 0.45 * (1 - pr)) * rd + (0.20 + 0.15 * pr) * rg - 0.10 * pr * nr + 0.05 * (1 - pr) * cd