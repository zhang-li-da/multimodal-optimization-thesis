def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    reg = f['regret']
    p = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    decay_d = 1.0 - 0.6 * p
    decay_rd = 1.0 - 0.75 * p
    sparsity_raw = nr / (mr + 1e-9) - 1.0
    sparsity = min(max(sparsity_raw, 0.0), 0.6)
    spread_gate_raw = 0.5 - sp / (mr + 1e-9)
    spread_gate = min(max(spread_gate_raw, 0.0), 1.0)
    cluster_term = 0.07 * cd * (1.0 - p) * spread_gate
    return -d * decay_d + 0.20 * rd * decay_rd + 0.55 * reg + 0.05 * sparsity + cluster_term
