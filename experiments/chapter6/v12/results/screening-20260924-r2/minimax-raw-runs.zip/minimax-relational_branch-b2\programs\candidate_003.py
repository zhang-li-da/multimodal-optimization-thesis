def priority(f):
    return -f["distance"] + 0.18 * f["return_distance"] + 0.15 * f["regret"]