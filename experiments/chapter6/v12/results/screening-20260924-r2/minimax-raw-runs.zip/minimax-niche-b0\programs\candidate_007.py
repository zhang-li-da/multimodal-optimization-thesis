def priority(f):
    d = f['distance']
    r = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    p = f['progress']
    den = f['cluster_density']
    sp = f['spread']
    b = max(0.0, 1.0 - p)
    term = (-1.10 * d + 0.15 * r + 0.15 * nr + 0.20 * den - 0.05 * sp) * (1.0 + 0.10 * p) + (0.05 + 0.25 * p) * b + 0.05 * rg - 0.10 * mr
    denom = 1e-9 + d + nr + mr + sp
    return term / denom
