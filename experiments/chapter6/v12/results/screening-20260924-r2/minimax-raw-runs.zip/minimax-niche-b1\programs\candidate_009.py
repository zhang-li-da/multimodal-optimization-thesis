def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    rem = 1.0 - p
    rem2 = rem * rem
    score = -d + 0.25 * r + 0.14 * rg * rem2 + 0.10 * cd * p - 0.03 * sp
    if p < 0.5:
        score = score + 0.10 * n
    score = score - 0.05 * m * p
    return score