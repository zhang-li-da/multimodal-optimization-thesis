def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    regret = f["regret"]
    spread = f["spread"]
    return -d + 0.20 * rd + 0.10 * regret - 0.05 * spread
