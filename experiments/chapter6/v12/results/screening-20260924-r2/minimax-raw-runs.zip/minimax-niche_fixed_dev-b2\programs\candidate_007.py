def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    safe_mr = mr if mr > 1e-9 else 1e-9
    denom = d + safe_mr
    look = rg / denom if denom > 1e-9 else rg
    ret_w = 0.20 + 0.45 * (1.0 - pr)
    clu_w = 0.25 + 0.20 * cd
    nr_w = 0.10 * pr
    score = -d + ret_w * rd + clu_w * look - nr_w * nr - 0.05 * sp
    return score
