def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    mr = f["mean_remaining"]
    safe_mr = mr + 1e-9
    decay_d = 1.0 - 0.55 * p
    decay_rd = 1.0 - 0.7 * p
    spread_gate = 0.5 - sp / safe_mr
    if spread_gate < 0.0:
        gate = 0.0
    else:
        gate = spread_gate
    cluster_term = 0.10 * cd * (1.0 - p) * gate
    score = -d * decay_d + 0.30 * rd * decay_rd + 0.45 * r + cluster_term
    return score