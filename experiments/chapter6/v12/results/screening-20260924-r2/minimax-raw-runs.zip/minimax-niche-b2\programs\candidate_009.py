def priority(f):
    d = f["distance"]
    rg = f["regret"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    pr = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    mrg = max(mr, eps)
    nd = max(nr, 0.0)
    log_term = log1p(nd / mrg)
    sp_safe = max(sp, eps)
    density_term = (nd / sp_safe) - 0.5
    return -d + 0.30 * rg + 0.10 * pr - 0.05 * cd + 0.10 * log_term - 0.02 * density_term
