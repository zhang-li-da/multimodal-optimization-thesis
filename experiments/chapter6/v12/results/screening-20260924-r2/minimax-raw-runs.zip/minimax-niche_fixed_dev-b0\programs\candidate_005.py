def priority(f):
    d = f['distance']
    r = f['return_distance']
    g = f['regret']
    p = f['progress']
    c = f['cluster_density']
    return -d + 0.22 * r + 0.18 * (g / (1.0 + d)) + 0.05 * p - 0.10 * c