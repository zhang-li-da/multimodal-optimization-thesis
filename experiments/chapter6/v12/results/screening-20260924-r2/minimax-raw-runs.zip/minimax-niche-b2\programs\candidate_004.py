def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    rg = f["regret"]
    return -d + 0.25 * r + 0.15 * rg - 0.05 * c
