def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    eps = 1e-9
    safe_mr = mr if mr > eps else eps
    denom = mr + 0.5 * nr
    denom_g = denom if denom > eps else eps
    look = rg / denom_g
    decay = 1.0 - pr
    ret_w = 0.20 + 0.40 * decay
    clu_w = 0.25 + 0.15 * cd
    gate = clu_w * look
    late_nr = 0.08 * pr * cd * nr
    spread_term = 0.04 * sp * decay
    score = -d + ret_w * rd + gate + 0.10 * decay * cd - late_nr - spread_term
    return score
