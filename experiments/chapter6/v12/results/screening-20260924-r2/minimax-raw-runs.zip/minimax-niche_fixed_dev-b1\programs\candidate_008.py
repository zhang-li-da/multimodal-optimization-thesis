def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr + 1e-9
    one_mp = 1.0 - 0.7 * p
    rd_weight = 0.18 * (1.0 - 0.8 * p)
    score = -d * one_mp + rd_weight * rd + 0.45 * r
    prox = nr / safe_mr
    cluster_gate = max(0.0, 0.5 - sp / safe_mr)
    cluster_term = 0.06 * cd * (1.0 - p) * cluster_gate
    spread_pen = -0.03 * (sp / safe_mr) * (1.0 - p)
    refine = cluster_term + spread_pen + 0.04 * (prox - 0.5)
    return score + refine