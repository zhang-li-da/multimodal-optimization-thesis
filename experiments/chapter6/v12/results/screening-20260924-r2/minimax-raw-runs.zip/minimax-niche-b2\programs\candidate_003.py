def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    return -d + 0.25 * r - 0.1 * c
