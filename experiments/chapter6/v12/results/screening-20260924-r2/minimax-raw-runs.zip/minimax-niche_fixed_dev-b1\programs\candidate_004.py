def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    smr = mr + 1e-9
    base = -d + 0.20 * rd * (1.0 - 0.5 * p) + 0.08 * r * (nr / smr - 1.0)
    cluster_term = (1.0 - p) * (-d) * (0.6 + 0.4 * cd)
    spread_term = -0.05 * (sp / smr) * (1.0 - p) * d
    proximity_bonus = 0.04 * (1.0 - p) * (nr / smr - 1.0)
    return base + cluster_term + spread_term + proximity_bonus