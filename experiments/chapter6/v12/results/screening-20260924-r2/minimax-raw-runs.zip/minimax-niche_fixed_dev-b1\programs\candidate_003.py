def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr + 1e-9
    base = -d + 0.25 * rd + 0.10 * r
    prox = nr / safe_mr
    dweight = (1.0 - p)
    cluster_term = dweight * cd * (-d)
    spread_term = (sp / safe_mr) * 0.05 * dweight
    refine = cluster_term + spread_term + 0.03 * (prox - 0.5)
    return base + refine