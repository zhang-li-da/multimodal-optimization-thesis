def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr + 1e-9
    decay_d = 1.0 - 0.55 * p
    rd_w = 0.10 * (1.0 - 0.85 * p)
    ratio = nr / safe_mr - 1.0
    if ratio < 0.0:
        prox = 0.0
    else:
        if ratio > 0.5:
            prox = 0.5
        else:
            prox = ratio
    reg_w = 0.30 + 0.45 * p + 0.06 * prox
    gate = 0.5 - sp / safe_mr
    if gate < 0.0:
        gate = 0.0
    cluster = 0.07 * cd * (1.0 - p) * gate
    score = -d * decay_d + rd_w * rd + reg_w * r + cluster
    return score