def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    regret = f["regret"]
    spread = f["spread"]
    pr = f["progress"]
    decay = 1.0 - pr
    eps = 1e-9
    return -d + (0.20 + 0.40 * decay) * rd + (0.25 + 0.15 * pr) * regret / (mr + eps) - 0.08 * pr * nr - 0.04 * spread
