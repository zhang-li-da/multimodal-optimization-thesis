def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    pr = f["progress"]
    return -d + (0.25 + 0.5 * (1 - pr)) * rd - 0.1 * pr * nr
