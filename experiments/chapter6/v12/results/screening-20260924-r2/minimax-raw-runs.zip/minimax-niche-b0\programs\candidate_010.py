def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    regret = f["regret"]
    progress = f["progress"]
    density = f["cluster_density"]
    spread = f["spread"]
    guard = 1e-9
    safe_d = max(d, guard)
    base_damp = max(0.0, 0.6 - d)
    safe_reg = max(regret, 0.0)
    reg_term = 0.25 * safe_reg * (1.0 - 0.5 * base_damp)
    ret_term = (0.05 + 0.25 * progress) * max(rd, 0.0)
    den_term = 0.08 * max(min(density, 1.0), 0.0)
    spr_term = 0.05 * max(spread, 0.0)
    nr_term = 0.05 * (nr - mr) / (mr + guard)
    return -safe_d + reg_term + ret_term - den_term + spr_term + nr_term
