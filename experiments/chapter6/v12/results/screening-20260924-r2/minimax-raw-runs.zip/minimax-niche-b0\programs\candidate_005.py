def priority(f):
    d = f["distance"]
    r = f["regret"]
    b = f["return_distance"]
    p = f["progress"]
    density = f["cluster_density"]
    return -1.10 * d + 0.20 * r + (0.05 + 0.20 * p) * b + 0.15 * density
