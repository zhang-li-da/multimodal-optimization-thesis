def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    g = f["regret"]
    c = f["cluster_density"]
    s = f["spread"]
    g_term = 0.18 * (g / max(nr, 1e-9))
    return -1.10 * d + 0.18 * r + g_term - 0.08 * c + 0.03 * s
