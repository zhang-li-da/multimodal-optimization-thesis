def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    rg = f["regret"]
    pr = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    dm = d / (m + 1e-9)
    rn = r / (n + 1e-9)
    sn = s / (m + 1e-9)
    late = 1.0 - 0.5 * pr
    return -d + 0.20 * r + 0.20 * rg * late - 0.08 * c + 0.10 * pr - 0.05 * dm + 0.05 * rn - 0.03 * sn
