def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    rg = f["regret"]
    c = f["cluster_density"]
    return -d + 0.25 * r + 0.25 * rg - 0.05 * c
