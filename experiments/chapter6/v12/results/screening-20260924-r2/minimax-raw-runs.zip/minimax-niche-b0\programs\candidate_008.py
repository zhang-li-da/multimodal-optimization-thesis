def priority(f):
    d = f["distance"]
    r = f["regret"]
    b = f["return_distance"]
    p = f["progress"]
    density = f["cluster_density"]
    return -1.05 * d + 0.20 * r + (0.05 + 0.25 * p) * b + 0.10 * density
