def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    rg = f["regret"]
    g = f["cluster_density"]
    p = f["progress"]
    return -d + 0.20 * rd + 0.05 * rg - 0.15 * g * p
