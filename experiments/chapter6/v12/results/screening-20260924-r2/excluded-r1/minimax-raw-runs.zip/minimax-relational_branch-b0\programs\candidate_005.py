def priority(f):
    d = f['distance']
    r = f['return_distance']
    n = f['nearest_remaining']
    m = f['mean_remaining']
    g = f['regret']
    p = f['progress']
    c = f['cluster_density']
    s = f['spread']
    base = -d + 0.20 * r + 0.25 * g
    pen = 0.15 * c * (m - d)
    spr = -0.10 * s
    nr = -0.05 * n
    pr = 0.08 * p * (n - d)
    return base + pen + spr + nr + pr