def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    safe_mr = mr + eps
    base = -d + 0.2 * r + 0.2 * rd
    norm_r = r / (safe_mr + eps)
    norm_rd = rd / (safe_mr + eps)
    density_bonus = cd * (0.15 + 0.1 * p)
    rel_return_gap = rd - mr
    penalty = rel_return_gap / (mr + eps) if rel_return_gap > 0 else 0.0
    spread_penalty = sp / safe_mr
    final_score = base + 0.05 * norm_r + 0.05 * norm_rd + density_bonus - 0.15 * penalty - 0.1 * spread_penalty
    return final_score