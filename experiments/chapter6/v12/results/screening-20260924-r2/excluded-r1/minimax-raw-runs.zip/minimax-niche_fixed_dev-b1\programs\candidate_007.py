def priority(f):
    d = f['distance']
    rt = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    p = f['progress']
    c = f['cluster_density']
    s = f['spread']
    eps = 1e-9
    safe_mr = mr if mr > eps else eps
    term_d = -(d / (1.0 + 0.30 * d)) * (1.0 + 0.20 * p)
    reg_pos = rg if rg > 0.0 else 0.0
    cluster = c / (1.0 + 0.40 * safe_mr)
    score = term_d + 0.22 * rt + 0.22 * reg_pos - 0.07 * cluster - 0.02 * s * (1.0 - p)
    return score
