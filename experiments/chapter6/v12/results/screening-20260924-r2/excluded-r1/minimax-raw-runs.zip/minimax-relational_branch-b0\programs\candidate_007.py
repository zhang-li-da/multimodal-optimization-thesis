def priority(f):
    d = f["distance"]
    r = f["regret"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    g = f["return_distance"]
    c = f["cluster_density"]
    s = f["spread"]
    p = f["progress"]
    nm = n - m
    nd = n - d
    safe_nd = nd
    val = -1.0 * d + 0.25 * r + 0.35 * g + 0.15 * nm - 0.20 * c * d - 0.03 * s + 0.05 * p * safe_nd
    return val