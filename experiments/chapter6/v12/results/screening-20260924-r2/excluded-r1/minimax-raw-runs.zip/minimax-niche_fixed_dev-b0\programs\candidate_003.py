def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    return -d + 0.30 * g + 0.10 * r
