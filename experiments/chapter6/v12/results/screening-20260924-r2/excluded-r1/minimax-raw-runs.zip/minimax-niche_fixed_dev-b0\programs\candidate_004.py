def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    s = f["spread"]
    return -d + 0.30 * g + (0.10 * p) * r + 0.05 * (1.0 - s)
