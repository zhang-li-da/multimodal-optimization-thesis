def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    s = f["spread"]
    m = f["mean_remaining"]
    p = f["progress"]
    comp = 1.0 - 0.15 * p
    if comp < 0.5:
        comp = 0.5
    cluster = c + 0.1 * m
    denom = 1.0 + 0.25 * d
    score = -d / denom * comp - 0.10 * cluster - 0.05 * s + 0.22 * r
    return score
