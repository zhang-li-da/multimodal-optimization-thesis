def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    rg = f["regret"]
    cd = f["cluster_density"]
    pr = f["progress"]
    rgn = rg / (1.0 + abs(rg))
    return -d + 0.30 * rd + 0.10 * rgn - 0.05 * cd + 0.05 * pr
