def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    eps = 1e-9
    sig_gr = 1.0 / (1.0 + exp(6.0 * (p - 0.6)))
    sig_rg = 1.0 / (1.0 + exp(5.0 * (p - 0.5)))
    g_w = 0.05 + 0.25 * sig_gr
    r_w = 0.05 + 0.22 * sig_rg
    g_term = g / (1.0 + p + eps)
    sp_pen = 0.03 * max(0.0, 1.0 - s)
    nr_nudge = 0.04 * nr * (1.0 - p)
    score = -d + g_w * g_term + r_w * r + 0.08 * c + sp_pen + nr_nudge
    if score > 0:
        score = score + 0.05 * (1.0 - p) * c
    else:
        score = score - 0.05 * p * (1.0 - c)
    mr_term = mr - nr
    if mr_term > 0:
        score = score + 0.02 * mr_term * (1.0 - p)
    return score
