def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    p = f["progress"]
    score = -d + 0.25 * rd + (0.15 + 0.15 * p) * (r + 0.5 * cd * r) - 0.05 * d * rd + 0.10 * rd * p
    return score