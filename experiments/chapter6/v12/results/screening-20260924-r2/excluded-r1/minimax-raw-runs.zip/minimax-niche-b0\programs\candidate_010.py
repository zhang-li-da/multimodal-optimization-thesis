def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    inv = 1.0 / (mr + 1e-9)
    soft = -d * inv
    soft = -4.0 if soft < -4.0 else (4.0 if soft > 4.0 else soft)
    rg = r * inv
    rg = 2.0 if rg > 2.0 else rg
    rg_term = rg * (0.10 + 0.15 * p) * cd
    rd_term = rd * inv
    rd_term = 0.30 if rd_term > 2.0 else rd_term * (0.05 + 0.15 * p)
    cd_clip = 1.0 if cd > 1.0 else cd
    cd_term = 0.12 * cd_clip * (1.0 - 0.5 * p)
    sp_term = sp * inv
    sp_term = 1.5 if sp_term > 1.5 else sp_term
    sp_term = 0.04 * sp_term
    final = soft + 0.20 * rg_term + rd_term + cd_term - sp_term
    return final