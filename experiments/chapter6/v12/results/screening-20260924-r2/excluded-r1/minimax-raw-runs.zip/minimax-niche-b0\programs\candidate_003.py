def priority(f):
    d = f["distance"]
    r = f["regret"]
    rd = f["return_distance"]
    p = f["progress"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    cd = f["cluster_density"]
    sp = f["spread"]
    safe_mr = mr + 1e-9
    base = -d + 0.2 * r + 0.15 * rd
    norm_r = r / (safe_mr + 1e-9)
    norm_rd = rd / (safe_mr + 1e-9)
    progress_pressure = (p * nr) / (safe_mr + 1e-9)
    density_bonus = cd * (0.05 + 0.05 * p)
    spread_penalty = sp / (safe_mr + 1e-9)
    final_score = base + 0.1 * norm_r + 0.05 * norm_rd - 0.1 * progress_pressure + density_bonus - 0.05 * spread_penalty
    return final_score