def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    eps = 1e-9
    one_minus_p = 1.0 - p
    g_weight = 0.30 * (one_minus_p ** 2) + 0.05
    r_weight = 0.05 + 0.20 * (p ** 2)
    g_term = g / (1.0 + p + eps)
    s_part = 1.0 - s
    if s_part < 0.0:
        s_part = 0.0
    score = -d + g_weight * g_term + r_weight * r + 0.08 * c + 0.03 * s_part
    if score > 0.0:
        score = score + 0.05 * one_minus_p * c
    else:
        score = score - 0.05 * p * (1.0 - c)
    return score
