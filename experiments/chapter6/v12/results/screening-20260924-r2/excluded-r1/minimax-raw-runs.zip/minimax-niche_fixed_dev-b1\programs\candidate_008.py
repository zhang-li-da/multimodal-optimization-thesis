def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    rg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    mr = f["mean_remaining"]
    s = f["spread"]
    eps = 1e-9
    denom = 1.0 + 0.30 * d
    if denom < eps:
        denom = eps
    dist_term = -(d / denom) * (1.0 - 0.20 * p)
    if rg < 0.0:
        rg = -rg
    if mr < eps:
        mr = eps
    cluster_pen = c / (1.0 + 0.50 * mr)
    if rg > 0.0:
        regret_term = 0.20 * rg
    else:
        regret_term = 0.0
    score = dist_term + 0.24 * r + regret_term - 0.06 * cluster_pen - 0.03 * s * (1.0 - p)
    return score