def priority(f):
    d = f['distance']
    rd = f['return_distance']
    nr = f['nearest_remaining']
    mr = f['mean_remaining']
    rg = f['regret']
    pr = f['progress']
    cd = f['cluster_density']
    sp = f['spread']
    blend = 0.30 * (d if d < rd else rd)
    regret_term = 0.20 * (rg / (1.0 + rg))
    spread_term = -0.04 * sp
    progress_term = 0.03 * pr
    cluster_term = -0.10 * cd if nr < mr else 0.05 * cd
    return -d + blend + regret_term + spread_term + progress_term + cluster_term
