def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    c = f["cluster_density"]
    s = f["spread"]
    m = f["mean_remaining"]
    p = f["progress"]
    denom = 1.0 + 0.30 * d
    if denom < 1e-9:
        denom = 1e-9
    cluster = c + 0.10 * m
    score = -(d / denom) * (1.0 - 0.20 * p) + 0.26 * r - 0.12 * cluster - 0.04 * s * (1.0 - p)
    return score