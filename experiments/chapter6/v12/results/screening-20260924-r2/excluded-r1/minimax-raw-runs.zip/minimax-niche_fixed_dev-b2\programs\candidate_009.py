def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    base = -d + 0.25 * rd / (1.0 + 0.5 * rd)
    regret_term = (0.08 + 0.22 * p) * r
    spread_pen = 0.03 * sp / (1.0 + sp) * (1.0 - p)
    prox_bias = 0.05 * (nr - mr) * p
    cluster_term = 0.015 * cd * (1.0 - p) * (1.0 - rd / (1.0 + rd))
    return base + regret_term - spread_pen + prox_bias + cluster_term
