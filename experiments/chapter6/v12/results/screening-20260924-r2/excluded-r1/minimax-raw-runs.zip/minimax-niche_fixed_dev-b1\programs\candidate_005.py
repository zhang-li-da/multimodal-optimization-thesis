def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    rg = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    s = f["spread"]
    eps = 1e-9
    denom = 1.0 + 0.30 * d
    if denom < eps:
        denom = eps
    dist_term = -(d / denom) * (1.0 - 0.20 * p)
    if nr < eps:
        nr = eps
    if mr < eps:
        mr = eps
    if nr > mr:
        ratio = mr / nr
    else:
        ratio = nr / mr
    dist_grad = 1.0 - ratio
    if dist_grad < 0.0:
        dist_grad = -dist_grad
    if rg < 0.0:
        rg = -rg
    cluster_pen = c * (0.5 + 0.5 * s)
    score = dist_term * (1.0 + 0.10 * dist_grad) + 0.24 * r + 0.20 * rg - 0.08 * cluster_pen - 0.03 * s * (1.0 - p)
    return score