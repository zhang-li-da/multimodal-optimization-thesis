def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    c = f["cluster_density"]
    s = f["spread"]
    p = f["progress"]
    return -d + 0.25 * r + 0.20 * g + 0.10 * (m - n) - 0.30 * c * d - 0.05 * s + 0.10 * p * (n - d)
