def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    n = f["nearest_remaining"]
    m = f["mean_remaining"]
    c = f["cluster_density"]
    s = f["spread"]
    p = f["progress"]
    cd = c * d
    pnd = p * (n - d)
    return -1.0 * d + 0.35 * r + (0.32 + 0.10 * (1.0 - c)) * g + 0.12 * (m - n) - 0.25 * cd - 0.015 * s + 0.02 * pnd
