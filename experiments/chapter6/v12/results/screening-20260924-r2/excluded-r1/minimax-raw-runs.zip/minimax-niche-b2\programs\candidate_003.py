def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    cd = f["cluster_density"]
    nr = f["nearest_remaining"]
    return -d + 0.25 * rd - 0.10 * cd + 0.02 * nr
