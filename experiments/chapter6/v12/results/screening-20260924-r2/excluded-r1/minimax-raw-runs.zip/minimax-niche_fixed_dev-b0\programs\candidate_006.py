def priority(f):
    d = f["distance"]
    r = f["return_distance"]
    g = f["regret"]
    p = f["progress"]
    c = f["cluster_density"]
    eps = 1e-9
    p_c = 0.30 - 0.15 * p
    r_c = 0.10 + 0.15 * p
    g_term = g / (1.0 + p + eps)
    s = -d + p_c * g_term + r_c * r + 0.10 * c
    if s > 0:
        s = s + 0.05 * (1.0 - p) * c
    else:
        s = s - 0.05 * p * (1.0 - c)
    return s
