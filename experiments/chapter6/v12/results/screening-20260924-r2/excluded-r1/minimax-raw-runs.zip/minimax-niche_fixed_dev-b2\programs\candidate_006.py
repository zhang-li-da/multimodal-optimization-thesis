def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    nr = f["nearest_remaining"]
    mr = f["mean_remaining"]
    r = f["regret"]
    p = f["progress"]
    cd = f["cluster_density"]
    sp = f["spread"]
    eps = 1e-9
    safe_rd = rd / (1.0 + rd + eps)
    safe_sp = sp / (1.0 + sp + eps)
    cd_eff = cd / (1.0 + cd + eps)
    rg = (0.18 + 0.12 * p) * (r + 0.30 * cd_eff * r)
    base = -d + 0.22 * safe_rd * (1.0 + 0.20 * p) + rg + 0.07 * safe_rd * p - 0.05 * safe_sp * (1.0 - p)
    mr_bias = 0.04 * (nr - mr) * p
    return base + mr_bias
