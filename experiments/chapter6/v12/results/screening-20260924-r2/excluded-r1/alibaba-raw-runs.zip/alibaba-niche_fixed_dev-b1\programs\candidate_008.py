def priority(f):
    d = f['distance']
    rd = f['return_distance']
    p = f['progress']
    w_rd = 0.1 + 0.4 * p
    return -d + w_rd * rd