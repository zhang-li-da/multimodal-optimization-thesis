def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    safe_rd = rd + 1e-9
    sqrt_rd = sqrt(safe_rd)
    return -d + 0.3 * r + 0.5 * sqrt_rd