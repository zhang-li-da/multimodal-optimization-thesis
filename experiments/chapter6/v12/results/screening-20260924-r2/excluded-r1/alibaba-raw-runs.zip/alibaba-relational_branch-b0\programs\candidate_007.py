def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    w = 0.1 + 0.4 * p
    return -d + w * rd + 0.2 * r