def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + r * (0.1 + 0.5 * p) + 0.15 * rd