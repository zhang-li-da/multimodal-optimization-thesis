def priority(f):
    d = f['distance']
    rd = f['return_distance']
    cd = f['cluster_density']
    w_rd = 0.5 * (1 - cd)
    return -d + w_rd * rd