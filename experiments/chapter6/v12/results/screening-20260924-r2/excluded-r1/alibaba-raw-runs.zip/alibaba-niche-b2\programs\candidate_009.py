def priority(f):
    d = f['distance']
    rd = f['return_distance']
    reg = f['regret']
    prog = f['progress']
    cd = f['cluster_density']
    eps = 1e-9
    safe_cd = max(0.0, cd)
    sqrt_cd = sqrt(safe_cd)
    regret_term = reg * (0.2 + 0.4 * prog)
    cluster_penalty = 0.1 * sqrt_cd
    return_dist_term = 0.1 * rd
    return -d + regret_term - cluster_penalty + return_dist_term