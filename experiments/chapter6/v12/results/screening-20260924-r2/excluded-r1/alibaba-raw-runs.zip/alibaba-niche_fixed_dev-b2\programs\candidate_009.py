def priority(f):
    d = f['distance']
    r = f['return_distance']
    reg = f['regret']
    cd = f['cluster_density']
    p = f['progress']
    eps = 1e-9
    term1 = -d
    term2 = 0.2 * reg / (1.0 + cd + eps)
    term3 = 0.15 * r / (1.0 + 0.5 * p + eps)
    return term1 + term2 + term3