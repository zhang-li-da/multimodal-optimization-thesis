def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    cd = f['cluster_density']
    w = 0.1 + 0.2 * (1 - cd)
    return -d + w * r + 0.1 * rd