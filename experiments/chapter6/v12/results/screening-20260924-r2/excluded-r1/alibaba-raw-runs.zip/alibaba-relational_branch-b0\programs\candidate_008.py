def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    cd = f["cluster_density"]
    p = f["progress"]
    w_return = 0.1 + 0.4 * p
    return -d + w_return * rd + 0.2 * cd