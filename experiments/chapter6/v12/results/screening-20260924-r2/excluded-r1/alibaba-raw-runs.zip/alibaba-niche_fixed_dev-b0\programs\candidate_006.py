def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    w_r = 0.4 * (1.0 - p**2)
    w_rd = 0.1 + 0.5 * p**2
    return -d + w_r * r + w_rd * rd