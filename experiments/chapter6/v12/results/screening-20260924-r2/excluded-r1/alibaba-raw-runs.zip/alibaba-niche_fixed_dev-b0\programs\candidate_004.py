def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    return -d + 0.2 * rd + 0.3 * r + 0.15 * cd