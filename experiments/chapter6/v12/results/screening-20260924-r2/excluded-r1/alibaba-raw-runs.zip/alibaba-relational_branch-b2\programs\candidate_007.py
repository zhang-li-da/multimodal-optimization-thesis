def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    p = f['progress']
    w = 0.5 - 0.3 * p
    return -d + w * r + 0.2 * rd