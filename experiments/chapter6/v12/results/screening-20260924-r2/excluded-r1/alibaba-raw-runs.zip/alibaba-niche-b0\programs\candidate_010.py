def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    cd = f['cluster_density']
    return -d + 0.2 * r + 0.15 * cd + (0.1 + 0.3 * p) * rd