def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    cd = f["cluster_density"]
    safe_cd = max(0.0, cd)
    return -d + 0.4 * (r ** 2) + 0.2 * sqrt(safe_cd) + 0.1 * rd