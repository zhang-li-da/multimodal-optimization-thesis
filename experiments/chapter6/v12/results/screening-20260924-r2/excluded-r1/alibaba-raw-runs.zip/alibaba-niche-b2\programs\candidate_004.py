def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    return -d + 0.2 * r + (0.1 + 0.4 * p) * rd