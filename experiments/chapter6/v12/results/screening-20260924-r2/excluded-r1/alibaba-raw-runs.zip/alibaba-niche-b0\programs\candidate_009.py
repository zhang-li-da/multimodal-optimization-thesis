def priority(f):
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    p = f["progress"]
    penalty = 0.1 + 0.5 * (p ** 2)
    return -d + 0.3 * r + penalty * rd