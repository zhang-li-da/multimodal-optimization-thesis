def priority(f):
    p = f["progress"]
    d = f["distance"]
    rd = f["return_distance"]
    r = f["regret"]
    w_rd = 0.1 + 0.6 * p
    w_r = 0.4 * (1 - p)
    return -d + w_rd * rd + w_r * r