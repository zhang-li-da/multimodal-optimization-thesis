def priority(f):
    d = f['distance']
    rd = f['return_distance']
    r = f['regret']
    p = f['progress']
    return -d + 0.4 * r * (1.0 - p) + 0.1 * rd