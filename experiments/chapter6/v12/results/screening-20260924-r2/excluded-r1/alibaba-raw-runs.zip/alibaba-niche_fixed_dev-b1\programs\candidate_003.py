def priority(f):
    return -f["distance"] + 0.5 * f["return_distance"]