def priority(f):
    d = f['distance']
    r = f['regret']
    rd = f['return_distance']
    cd = f['cluster_density']
    p = f['progress']
    w_cd = 0.3 * (1.0 - p)
    w_r = 0.2 * (1.0 - p)
    w_rd = 0.1 + 0.3 * p
    return -d + w_cd * cd + w_r * r + w_rd * rd