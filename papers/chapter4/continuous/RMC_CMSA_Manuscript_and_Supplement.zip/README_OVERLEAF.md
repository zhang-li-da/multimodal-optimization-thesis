# RMC-CMSA Overleaf package

This directory is a clean manuscript bundle for Overleaf. It contains the
main article, supplementary material, bibliography, local IEEE style files,
all manuscript tables, and the final PDF figures used by the two TeX files.
Compiled auxiliary files, experiment data, local code, and temporary figure
variants are intentionally excluded.

## Upload and compile

1. Upload all files and folders in this directory to a new Overleaf project.
2. Set `edc_cmsa_main.tex` as the main document and compile with pdfLaTeX.
3. To compile the supplement, select `edc_cmsa_supplement.tex` as the main
   document and compile it separately.

The supplement imports `sections/microgrid_application_supp.tex`, the tables
from `tables_edc/`, and the figures from `figs_edc/`. The main article uses the
same relative paths, so no path changes are required after upload.

The current Fig. 4 is `figs_edc/rmc_mechanism.pdf`, and the current sensitivity
figure is `figs_edc/cec2026_sensitivity_d20.pdf`.
